import { useState, useEffect, useCallback } from "react";
import { useAuth } from "./hooks/useAuth";
import { AuthPage } from "./pages/Auth";
import { OnboardingPage } from "./pages/Onboarding";
import { LanguageProvider } from "./context/LanguageContext";
import { StudentProvider } from "./context/StudentContext";
import { OfflineProvider, useOfflineStatus } from "./context/OfflineContext";
import { Header } from "./components/Header";
import { BottomNav } from "./components/BottomNav";
import { OfflineBanner } from "./components/OfflineBanner";
import { ChatBot } from "./components/ChatBot";
import { HomePage } from "./pages/Home";
import { LearnPage } from "./pages/Learn";
import { BadgesPage } from "./pages/Badges";
import { ProfilePage } from "./pages/Profile";
import { TeacherPage } from "./pages/Teacher";
import { QuestsPage } from "./pages/Quests";
import { PracticePage } from "./pages/Practice";
import { BattlePage } from "./pages/Battle";
import { RankingPage } from "./pages/Ranking";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { supabase } from "@/integrations/supabase/client";

const AppContent = () => {
  const [activeTab, setActiveTab] = useState("home");
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [isTeacher, setIsTeacher] = useState(false);
  const { isOnline, syncStatus } = useOfflineStatus();

  useEffect(() => {
    const checkTeacherRole = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase.rpc('has_role', { _user_id: user.id, _role: 'teacher' });
      setIsTeacher(!!data);
    };
    checkTeacherRole();
  }, []);

  const handleSubjectSelect = (subjectId: string) => {
    setSelectedSubjectId(subjectId);
    setActiveTab("learn");
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab !== "learn") setSelectedSubjectId(null);
  };

  const handleBackFromLearn = () => { setSelectedSubjectId(null); setActiveTab("home"); };
  const handleBackToHome = () => { setActiveTab("home"); };

  const renderContent = () => {
    switch (activeTab) {
      case "home": return <HomePage onSubjectSelect={handleSubjectSelect} onNavigate={handleTabChange} />;
      case "learn": return <LearnPage initialSubjectId={selectedSubjectId} onBack={handleBackFromLearn} />;
      case "badges": return <BadgesPage />;
      case "profile": return <ProfilePage />;
      case "teacher": return <TeacherPage />;
      case "quests": return <QuestsPage onBack={handleBackToHome} />;
      case "practice": return <PracticePage onBack={handleBackToHome} />;
      case "battle": return <BattlePage onBack={handleBackToHome} />;
      case "ranking": return <RankingPage onBack={handleBackToHome} />;
      default: return <HomePage onSubjectSelect={handleSubjectSelect} onNavigate={handleTabChange} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <OfflineBanner isOnline={isOnline} isSyncing={syncStatus.isSyncing} lastSynced={syncStatus.lastSynced} />
      <main className={`pb-20 ${!isOnline || syncStatus.isSyncing ? 'pt-10' : ''}`}>
        {renderContent()}
      </main>
      <BottomNav activeTab={activeTab} onTabChange={handleTabChange} isTeacher={isTeacher} />
      <ChatBot />
      <Toaster />
      <Sonner />
    </div>
  );
};

const AuthGate = () => {
  const { user, loading } = useAuth();
  const [needsOnboarding, setNeedsOnboarding] = useState<boolean | null>(null);

  const checkProfile = useCallback(async (userId: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("hunter_name")
      .eq("user_id", userId)
      .maybeSingle();

    setNeedsOnboarding(!data?.hunter_name);
  }, []);

  useEffect(() => {
    if (user) {
      checkProfile(user.id);
    } else {
      setNeedsOnboarding(null);
    }
  }, [user, checkProfile]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="text-5xl animate-pulse">⚔️</div>
          <p className="neon-text text-lg">Loading System...</p>
        </div>
      </div>
    );
  }

  if (!user) return <AuthPage />;

  // Still checking profile
  if (needsOnboarding === null) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="text-5xl animate-pulse">⚔️</div>
          <p className="neon-text text-lg">Loading System...</p>
        </div>
      </div>
    );
  }

  if (needsOnboarding) {
    return (
      <OnboardingPage
        userId={user.id}
        onComplete={() => setNeedsOnboarding(false)}
      />
    );
  }

  return (
    <StudentProvider>
      <OfflineProvider>
        <AppContent />
      </OfflineProvider>
    </StudentProvider>
  );
};

const App = () => {
  return (
    <LanguageProvider>
      <Toaster />
      <Sonner />
      <AuthGate />
    </LanguageProvider>
  );
};

export default App;
