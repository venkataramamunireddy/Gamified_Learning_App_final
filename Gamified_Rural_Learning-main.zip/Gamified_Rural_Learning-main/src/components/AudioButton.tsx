import { Volume2, VolumeX, Loader2 } from 'lucide-react';
import { useSpeech } from '../hooks/useSpeech';

interface AudioButtonProps {
  text: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const AudioButton = ({ text, className = '', size = 'md' }: AudioButtonProps) => {
  const { speak, stop, isSpeaking, isSupported, hasVoiceForLanguage } = useSpeech();

  if (!isSupported) return null;

  // Show disabled state if no voice available for current language
  const isDisabled = !hasVoiceForLanguage;

  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12'
  };

  const iconSizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  const handleClick = () => {
    if (isSpeaking) {
      stop();
    } else {
      speak(text);
    }
  };

  return (
    <button
      onClick={handleClick}
      disabled={isDisabled}
      className={`${sizeClasses[size]} rounded-full flex items-center justify-center transition-all duration-200 ${
        isDisabled
          ? 'bg-muted text-muted-foreground cursor-not-allowed opacity-50'
          : isSpeaking 
            ? 'bg-primary text-primary-foreground animate-pulse' 
            : 'bg-primary/10 text-primary hover:bg-primary/20'
      } ${className}`}
      aria-label={isDisabled ? 'Voice not available for this language' : isSpeaking ? 'Stop audio' : 'Play audio'}
      title={isDisabled ? 'Voice not available for this language on your device' : undefined}
    >
      {isSpeaking ? (
        <VolumeX className={iconSizes[size]} />
      ) : (
        <Volume2 className={iconSizes[size]} />
      )}
    </button>
  );
};
