import { Home, BookOpen, Award, User, Users } from "lucide-react";
import { useLang } from "../context/LanguageContext";

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  isTeacher?: boolean;
}

export const BottomNav = ({ activeTab, onTabChange, isTeacher = false }: BottomNavProps) => {
  const { t } = useLang();

  const tabs = [
    { id: 'home', icon: Home, label: t('Home', 'होम', 'హోమ్') },
    { id: 'learn', icon: BookOpen, label: t('Learn', 'पढ़ें', 'నేర్చుకో') },
    { id: 'badges', icon: Award, label: t('Badges', 'बैज', 'బ్యాడ్జ్‌లు') },
    { id: 'profile', icon: User, label: t('Profile', 'प्रोफ़ाइल', 'ప్రొఫైల్') },
    ...(isTeacher ? [{ id: 'teacher', icon: Users, label: t('Class', 'कक्षा', 'తరగతి') }] : []),
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 bg-card border-t border-border shadow-neon safe-area-bottom z-50">
      <div className="flex justify-around items-center py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded transition-all duration-200 ${
                isActive 
                  ? 'text-primary' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className={`p-2 rounded transition-all ${isActive ? 'bg-primary/10 border border-primary/30' : ''}`}>
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
              </div>
              <span className={`text-xs font-semibold ${isActive ? 'text-primary neon-text' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
