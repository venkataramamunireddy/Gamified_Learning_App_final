import { Flame, Target } from "lucide-react";
import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";

export const DailyGoal = () => {
  const { t } = useLang();
  const { student } = useStudent();
  
  const dailyProgress = Math.min((student.lessonsCompleted % 5) * 20, 100);

  return (
    <div className="system-window neon-border p-5 mx-4 mt-4 animate-slide-up">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-foreground">{t('Daily Quest', 'दैनिक क्वेस्ट', 'రోజువారీ క్వెస్ట్')} 🎯</h3>
        </div>
        <div className="flex items-center gap-1 text-accent font-bold text-sm border border-accent/30 bg-accent/10 px-2 py-0.5 rounded">
          <Flame className="w-4 h-4" />
          <span>{student.streak} {t('days', 'दिन', 'రోజులు')}</span>
        </div>
      </div>
      
      <div className="w-full bg-muted rounded h-3 overflow-hidden border border-border">
        <div 
          className="bg-gradient-to-r from-primary to-accent h-3 transition-all duration-700 ease-out"
          style={{ width: `${dailyProgress}%` }}
        />
      </div>
      
      <div className="flex justify-between mt-2 text-sm">
        <span className="text-muted-foreground font-medium">
          {Math.floor(dailyProgress / 20)}/5 {t('lessons', 'पाठ', 'పాఠాలు')}
        </span>
        <span className="text-primary font-bold">
          {student.streak} {t('day streak', 'दिन की लकीर', 'రోజుల స్ట్రీక్')} 🔥
        </span>
      </div>
    </div>
  );
};
