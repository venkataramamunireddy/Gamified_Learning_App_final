import { Flame } from "lucide-react";
import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { useOfflineStatus } from "../context/OfflineContext";
import { SyncIndicator } from "./OfflineBanner";

export const Header = () => {
  const { lang, setLang, t } = useLang();
  const { student } = useStudent();
  const { isOnline, syncStatus } = useOfflineStatus();

  const cycleLang = () => {
    if (lang === "en") setLang("hi");
    else if (lang === "hi") setLang("te");
    else setLang("en");
  };

  const getLangLabel = () => {
    if (lang === "en") return "हिंदी";
    if (lang === "hi") return "తెలుగు";
    return "EN";
  };

  return (
    <header className="sticky top-0 z-50 gradient-header border-b border-border shadow-neon">
      <div className="flex justify-between items-center px-4 py-3">
        <div className="flex flex-col">
          <h1 className="font-extrabold text-xl flex items-center gap-2 text-primary neon-text">
            ⚔️ {t('SYSTEM', 'सिस्टम', 'సిస్టమ్')}
          </h1>
          <SyncIndicator isOnline={isOnline} isSyncing={syncStatus.isSyncing} />
        </div>
        <div className="flex gap-3 items-center">
          <div className="flex items-center gap-1 border border-primary/40 bg-primary/10 px-3 py-1.5 rounded font-bold text-sm text-primary">
            <Flame className="w-4 h-4 animate-pulse-glow" />
            <span>{student.xp} XP</span>
          </div>
          <button
            onClick={cycleLang}
            className="border border-border bg-muted hover:bg-muted/80 px-3 py-1.5 rounded font-bold text-sm text-foreground transition-all active:scale-95"
          >
            {getLangLabel()}
          </button>
        </div>
      </div>
    </header>
  );
};
