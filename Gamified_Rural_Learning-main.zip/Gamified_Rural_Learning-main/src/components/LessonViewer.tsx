import { useState } from 'react';
import { useLang } from '../context/LanguageContext';
import { Lesson } from '../data/lessons';
import { CheckCircle2, XCircle, BookOpen, Lightbulb, HelpCircle } from 'lucide-react';
import { AudioButton } from './AudioButton';

interface LessonViewerProps {
  lesson: Lesson;
  onComplete: () => void;
}

export const LessonViewer = ({ lesson, onComplete }: LessonViewerProps) => {
  const { t, lang } = useLang();
  const [stage, setStage] = useState<'learn' | 'practice' | 'done'>('learn');
  const [practiceAnswer, setPracticeAnswer] = useState<number | null>(null);
  const [showPracticeResult, setShowPracticeResult] = useState(false);

  const getTitle = () => {
    if (lang === 'te') return lesson.titleTe;
    if (lang === 'hi') return lesson.titleHi;
    return lesson.title;
  };

  const getContent = () => {
    if (lang === 'te') return lesson.contentTe;
    if (lang === 'hi') return lesson.contentHi;
    return lesson.content;
  };

  const getExampleTitle = (example: typeof lesson.examples[0]) => {
    if (lang === 'te') return example.titleTe;
    if (lang === 'hi') return example.titleHi;
    return example.title;
  };

  const getExampleContent = (example: typeof lesson.examples[0]) => {
    if (lang === 'te') return example.contentTe;
    if (lang === 'hi') return example.contentHi;
    return example.content;
  };

  const getPracticeQuestion = () => {
    if (lang === 'te') return lesson.practiceQuestion.questionTe;
    if (lang === 'hi') return lesson.practiceQuestion.questionHi;
    return lesson.practiceQuestion.question;
  };

  const getPracticeOptions = () => {
    if (lang === 'te') return lesson.practiceQuestion.optionsTe;
    if (lang === 'hi') return lesson.practiceQuestion.optionsHi;
    return lesson.practiceQuestion.options;
  };

  const handlePracticeAnswer = (index: number) => {
    if (showPracticeResult) return;
    setPracticeAnswer(index);
    setShowPracticeResult(true);
  };

  const handlePracticeRetry = () => {
    setPracticeAnswer(null);
    setShowPracticeResult(false);
  };

  const handlePracticeContinue = () => {
    setStage('done');
  };

  // Learning Stage
  if (stage === 'learn') {
    return (
      <div className="p-4 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-secondary/20 flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-secondary" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground font-medium">
              {t('Lesson', 'पाठ', 'పాఠం')}
            </p>
            <h2 className="text-xl font-extrabold text-foreground">{getTitle()}</h2>
          </div>
        </div>

        {/* Explanation */}
        <div className="bg-card rounded-3xl p-5 shadow-soft mb-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-primary" />
              <h3 className="font-bold text-foreground">
                {t('Explanation', 'व्याख्या', 'వివరణ')}
              </h3>
            </div>
            <AudioButton text={getContent()} size="sm" />
          </div>
          <p className="text-foreground leading-relaxed whitespace-pre-line">
            {getContent()}
          </p>
        </div>

        {/* Examples */}
        <div className="mb-6">
          <h3 className="font-bold text-foreground mb-3 flex items-center gap-2">
            📝 {t('Examples', 'उदाहरण', 'ఉదాహరణలు')}
          </h3>
          <div className="space-y-3">
            {lesson.examples.map((example, index) => (
              <div
                key={index}
                className="bg-muted rounded-2xl p-4 border-2 border-border"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{example.emoji}</span>
                    <h4 className="font-bold text-foreground">{getExampleTitle(example)}</h4>
                  </div>
                  <AudioButton 
                    text={`${getExampleTitle(example)}. ${getExampleContent(example)}`} 
                    size="sm" 
                  />
                </div>
                <p className="text-foreground whitespace-pre-line leading-relaxed">
                  {getExampleContent(example)}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Continue Button */}
        <button
          onClick={() => setStage('practice')}
          className="w-full gradient-header text-primary-foreground p-4 rounded-2xl font-bold text-lg shadow-button hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          {t('I Understand, Continue', 'मैं समझ गया / गई', 'నాకు అర్థమైంది, కొనసాగించు')} ✨
        </button>
      </div>
    );
  }

  // Practice Stage
  if (stage === 'practice') {
    const options = getPracticeOptions();
    const isCorrect = practiceAnswer === lesson.practiceQuestion.correctAnswer;

    return (
      <div className="p-4 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-accent/20 flex items-center justify-center">
            <HelpCircle className="w-6 h-6 text-accent" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground font-medium">
              {t('Practice', 'अभ्यास', 'అభ్యాసం')}
            </p>
            <h2 className="text-xl font-extrabold text-foreground">
              {t('No XP • No Wrong Answer', 'कोई XP नहीं • कोई गलत जवाब नहीं', 'XP లేదు • తప్పు సమాధానం లేదు')}
            </h2>
          </div>
        </div>

        {/* Practice Info Banner */}
        <div className="bg-secondary/10 border-2 border-secondary/30 rounded-2xl p-4 mb-6">
          <p className="text-sm text-secondary font-medium text-center">
            {t(
              '😊 This is just for practice. You can try again freely!',
              '😊 यह सिर्फ अभ्यास के लिए है। आप फिर से कोशिश कर सकते हैं!',
              '😊 ఇది అభ్యాసం కోసం మాత్రమే. మీరు మళ్ళీ ప్రయత్నించవచ్చు!'
            )}
          </p>
        </div>

        {/* Question */}
        <div className="bg-card rounded-3xl p-5 shadow-soft mb-6">
          <div className="flex items-start justify-between gap-3">
            <p className="text-lg font-bold text-foreground whitespace-pre-line leading-relaxed flex-1">
              {getPracticeQuestion()}
            </p>
            <AudioButton text={getPracticeQuestion()} size="md" />
          </div>
        </div>

        {/* Options */}
        <div className="grid gap-3 mb-6">
          {options.map((option, index) => {
            let buttonClass = "p-4 rounded-2xl border-2 text-left font-semibold transition-all duration-200 ";

            if (showPracticeResult) {
              if (index === lesson.practiceQuestion.correctAnswer) {
                buttonClass += "bg-secondary/20 border-secondary text-foreground";
              } else if (index === practiceAnswer && index !== lesson.practiceQuestion.correctAnswer) {
                buttonClass += "bg-amber-500/20 border-amber-500 text-foreground";
              } else {
                buttonClass += "bg-muted border-border text-muted-foreground opacity-60";
              }
            } else {
              buttonClass += "bg-card border-border hover:border-accent hover:bg-accent/5 text-foreground active:scale-[0.98]";
            }

            return (
              <button
                key={index}
                onClick={() => handlePracticeAnswer(index)}
                disabled={showPracticeResult}
                className={buttonClass}
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-bold">
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="flex-1">{option}</span>
                  {showPracticeResult && index === lesson.practiceQuestion.correctAnswer && (
                    <CheckCircle2 className="w-6 h-6 text-secondary" />
                  )}
                  {showPracticeResult && index === practiceAnswer && index !== lesson.practiceQuestion.correctAnswer && (
                    <XCircle className="w-6 h-6 text-amber-500" />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Result Feedback */}
        {showPracticeResult && (
          <div className={`rounded-2xl p-4 mb-6 text-center ${isCorrect ? 'bg-secondary/20' : 'bg-amber-500/20'}`}>
            <p className={`font-bold text-lg ${isCorrect ? 'text-secondary' : 'text-amber-600'}`}>
              {isCorrect
                ? t('✅ Good job! You are learning!', '✅ शाबाश! आप सीख रहे हैं!', '✅ బాగుంది! మీరు నేర్చుకుంటున్నారు!')
                : t("😊 It's okay. Try again!", '😊 कोई बात नहीं। फिर से कोशिश करें!', '😊 పరవాలేదు. మళ్ళీ ప్రయత్నించండి!')
              }
            </p>
          </div>
        )}

        {/* Action Buttons */}
        {showPracticeResult && (
          <div className="flex gap-3">
            {!isCorrect && (
              <button
                onClick={handlePracticeRetry}
                className="flex-1 bg-muted text-foreground p-4 rounded-2xl font-bold hover:bg-muted/80 transition-all"
              >
                {t('Try Again', 'फिर से कोशिश करें', 'మళ్ళీ ప్రయత్నించు')} 🔄
              </button>
            )}
            <button
              onClick={handlePracticeContinue}
              className={`${isCorrect ? 'w-full' : 'flex-1'} gradient-header text-primary-foreground p-4 rounded-2xl font-bold shadow-button hover:scale-[1.02] active:scale-[0.98] transition-all`}
            >
              {t('Continue', 'जारी रखें', 'కొనసాగించు')} ➡️
            </button>
          </div>
        )}
      </div>
    );
  }

  // Done Stage - Ready for Quiz
  return (
    <div className="p-6 text-center animate-fade-in">
      <div className="text-7xl mb-4 animate-bounce-gentle">🎯</div>
      <h2 className="text-2xl font-extrabold text-foreground mb-2">
        {t('Lesson Complete!', 'पाठ पूरा हुआ!', 'పాఠం పూర్తయింది!')}
      </h2>
      <p className="text-muted-foreground mb-6">
        {t(
          'You understood the lesson. Now you are ready for the quiz!',
          'आपने पाठ समझ लिया। अब आप क्विज़ के लिए तैयार हैं!',
          'మీరు పాఠం అర్థం చేసుకున్నారు. ఇప్పుడు మీరు క్విజ్‌కు సిద్ధంగా ఉన్నారు!'
        )}
      </p>

      <button
        onClick={onComplete}
        className="w-full gradient-header text-primary-foreground p-4 rounded-2xl font-bold text-lg shadow-button hover:scale-[1.02] active:scale-[0.98] transition-all"
      >
        {t('Start Quiz', 'क्विज़ शुरू करें', 'క్విజ్ ప్రారంభించండి')} 🚀
      </button>
    </div>
  );
};
