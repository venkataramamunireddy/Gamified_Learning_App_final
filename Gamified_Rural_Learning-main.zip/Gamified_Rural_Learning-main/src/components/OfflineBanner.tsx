import { Wifi, WifiOff, RefreshCw, Check } from 'lucide-react';
import { useLang } from '../context/LanguageContext';

interface OfflineBannerProps {
  isOnline: boolean;
  isSyncing: boolean;
  lastSynced: Date | null;
}

export const OfflineBanner = ({ isOnline, isSyncing, lastSynced }: OfflineBannerProps) => {
  const { t } = useLang();

  if (isOnline && !isSyncing) return null;

  return (
    <div
      className={`fixed top-[60px] left-0 right-0 z-40 px-4 py-2 text-center text-sm font-semibold transition-all duration-300 ${
        isOnline
          ? 'bg-secondary text-secondary-foreground'
          : 'bg-amber-500 text-white'
      }`}
    >
      <div className="flex items-center justify-center gap-2">
        {isOnline ? (
          <>
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>{t('Syncing...', 'सिंक हो रहा है...', 'సమకాలీకరించబడుతోంది...')}</span>
          </>
        ) : (
          <>
            <WifiOff className="w-4 h-4" />
            <span>{t('Offline Mode - Progress saved locally', 'ऑफ़लाइन मोड - प्रगति स्थानीय रूप से सहेजी गई', 'ఆఫ్‌లైన్ మోడ్ - పురోగతి స్థానికంగా సేవ్ చేయబడింది')}</span>
          </>
        )}
      </div>
    </div>
  );
};

export const SyncIndicator = ({ isOnline, isSyncing }: { isOnline: boolean; isSyncing: boolean }) => {
  const { t } = useLang();

  return (
    <div className="flex items-center gap-1.5 text-xs">
      {isOnline ? (
        isSyncing ? (
          <>
            <RefreshCw className="w-3 h-3 animate-spin text-secondary" />
            <span className="text-muted-foreground">{t('Syncing', 'सिंक', 'సమకాలీకరణ')}</span>
          </>
        ) : (
          <>
            <Check className="w-3 h-3 text-secondary" />
            <span className="text-muted-foreground">{t('Synced', 'सिंक्ड', 'సమకాలీకరించబడింది')}</span>
          </>
        )
      ) : (
        <>
          <WifiOff className="w-3 h-3 text-amber-500" />
          <span className="text-amber-600">{t('Offline', 'ऑफ़लाइन', 'ఆఫ్‌లైన్')}</span>
        </>
      )}
    </div>
  );
};
