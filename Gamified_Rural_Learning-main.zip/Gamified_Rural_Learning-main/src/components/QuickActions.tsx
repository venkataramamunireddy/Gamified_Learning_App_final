import { useLang } from "../context/LanguageContext";

interface QuickActionsProps {
  onNavigate: (tab: string) => void;
}

export const QuickActions = ({ onNavigate }: QuickActionsProps) => {
  const { t } = useLang();

  const actions = [
    { id: 'quests', icon: '🎯', label: t('Quests', 'क्वेस्ट', 'క్వెస్ట్స్'), tab: 'quests' },
    { id: 'battle', icon: '⚔️', label: t('Battle', 'बैटल', 'బ్యాటిల్'), tab: 'battle' },
    { id: 'practice', icon: '✏️', label: t('Practice', 'अभ्यास', 'ప్రాక్టీస్'), tab: 'practice' },
    { id: 'ranking', icon: '🏆', label: t('Ranking', 'रैंकिंग', 'ర్యాంకింగ్'), tab: 'ranking' },
  ];

  return (
    <div className="px-4 mt-4">
      <h2 className="text-sm font-bold text-primary mb-3 uppercase tracking-widest flex items-center gap-2">
        <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse-glow" />
        {t('Quick Actions', 'त्वरित कार्य', 'త్వరిత చర్యలు')}
      </h2>
      <div className="grid grid-cols-4 gap-3">
        {actions.map((action) => (
          <button
            key={action.id}
            onClick={() => onNavigate(action.tab)}
            className="flex flex-col items-center gap-2 p-4 system-window hover:border-primary/60 hover:shadow-neon transition-all active:scale-95"
          >
            <span className="text-2xl">{action.icon}</span>
            <span className="text-xs font-semibold text-foreground">{action.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
