import { useState, useEffect } from "react";
import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { Question } from "../data/questions";
import { CheckCircle2, XCircle, ArrowRight } from "lucide-react";
import confetti from "canvas-confetti";

interface QuizGameProps {
  questions: Question[];
  onComplete: () => void;
  subjectName: string;
  subjectNameHi: string;
  subjectNameTe?: string;
  isPracticeMode?: boolean;
}

export const QuizGame = ({ questions, onComplete, subjectName, subjectNameHi, subjectNameTe, isPracticeMode = false }: QuizGameProps) => {
  const { t, lang } = useLang();
  const { addXP, completeLesson, completeQuiz } = useStudent();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const currentQuestion = questions[currentIndex];

  const handleAnswer = (index: number) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(index);
    setShowResult(true);
    
    if (index === currentQuestion.correctAnswer) {
      setScore(score + 10);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setIsComplete(true);
      if (!isPracticeMode) {
        addXP(score);
        completeLesson();
        completeQuiz();
      }
      
      // Trigger confetti
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF6B35', '#2EC4B6', '#9B5DE5', '#FFD93D'],
      });
    }
  };

  useEffect(() => {
    if (isComplete) {
      const timer = setTimeout(() => {
        confetti({
          particleCount: 80,
          spread: 100,
          origin: { x: 0.2, y: 0.5 },
        });
        confetti({
          particleCount: 80,
          spread: 100,
          origin: { x: 0.8, y: 0.5 },
        });
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isComplete]);

  if (isComplete) {
    const percentage = Math.round((score / (questions.length * 10)) * 100);
    const localSubjectName = lang === 'te' ? (subjectNameTe || subjectName) : (lang === 'hi' ? subjectNameHi : subjectName);
    
    return (
      <div className="p-6 text-center animate-scale-in">
        <div className="text-7xl mb-4 animate-bounce-gentle">🎉</div>
        <h2 className="text-3xl font-extrabold text-foreground mb-2">
          {t('Congratulations!', 'बधाई हो!', 'అభినందనలు!')}
        </h2>
        <p className="text-xl text-muted-foreground mb-6">
          {t(`You completed ${subjectName}!`, `आपने ${subjectNameHi} पूरा किया!`, `మీరు ${subjectNameTe || subjectName} పూర్తి చేసారు!`)}
        </p>
        
        <div className="bg-card rounded-3xl p-6 shadow-card mb-6">
          <div className="text-5xl font-extrabold text-primary mb-2">
            +{score} XP
          </div>
          <p className="text-muted-foreground font-medium">
            {percentage}% {t('correct answers', 'सही जवाब', 'సరైన సమాధానాలు')}
          </p>
        </div>
        
        <button
          onClick={onComplete}
          className="gradient-header text-primary-foreground px-8 py-4 rounded-2xl font-bold text-lg shadow-button hover:scale-105 active:scale-95 transition-all"
        >
          {t('Continue Learning', 'पढ़ाई जारी रखें', 'నేర్చుకోవడం కొనసాగించండి')} 🚀
        </button>
      </div>
    );
  }

  const getOptions = () => {
    if (lang === 'te') return currentQuestion.optionsTe || currentQuestion.options;
    if (lang === 'hi') return currentQuestion.optionsHi;
    return currentQuestion.options;
  };

  const getQuestion = () => {
    if (lang === 'te') return currentQuestion.questionTe || currentQuestion.question;
    if (lang === 'hi') return currentQuestion.questionHi;
    return currentQuestion.question;
  };

  const options = getOptions();

  return (
    <div className="p-4 animate-fade-in">
      {/* Progress */}
      <div className="mb-6">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-muted-foreground font-medium">
            {t('Question', 'प्रश्न', 'ప్రశ్న')} {currentIndex + 1}/{questions.length}
          </span>
          <span className="text-primary font-bold">+{score} XP</span>
        </div>
        <div className="bg-muted rounded-full h-2">
          <div 
            className="gradient-header h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="bg-card rounded-3xl p-6 shadow-soft mb-6">
        <h3 className="text-xl font-bold text-foreground leading-relaxed">
          {getQuestion()}
        </h3>
      </div>

      {/* Options */}
      <div className="grid gap-3 mb-6">
        {options.map((option, index) => {
          let buttonClass = "p-4 rounded-2xl border-2 text-left font-semibold transition-all duration-200 ";
          
          if (showResult) {
            if (index === currentQuestion.correctAnswer) {
              buttonClass += "bg-secondary/20 border-secondary text-foreground";
            } else if (index === selectedAnswer && index !== currentQuestion.correctAnswer) {
              buttonClass += "bg-destructive/20 border-destructive text-foreground";
            } else {
              buttonClass += "bg-muted border-border text-muted-foreground opacity-60";
            }
          } else {
            buttonClass += "bg-card border-border hover:border-primary hover:bg-primary/5 text-foreground active:scale-[0.98]";
          }

          return (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={showResult}
              className={buttonClass}
            >
              <div className="flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-bold">
                  {String.fromCharCode(65 + index)}
                </span>
                <span className="flex-1">{option}</span>
                {showResult && index === currentQuestion.correctAnswer && (
                  <CheckCircle2 className="w-6 h-6 text-secondary" />
                )}
                {showResult && index === selectedAnswer && index !== currentQuestion.correctAnswer && (
                  <XCircle className="w-6 h-6 text-destructive" />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Next Button */}
      {showResult && (
        <button
          onClick={handleNext}
          className="w-full gradient-header text-primary-foreground p-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-button hover:scale-[1.02] active:scale-[0.98] transition-all animate-slide-up"
        >
          {currentIndex < questions.length - 1 ? (
            <>
              {t('Next Question', 'अगला प्रश्न', 'తదుపరి ప్రశ్న')}
              <ArrowRight className="w-5 h-5" />
            </>
          ) : (
            <>
              {t('See Results', 'नतीजे देखें', 'ఫలితాలు చూడండి')} 🎉
            </>
          )}
        </button>
      )}
    </div>
  );
};
