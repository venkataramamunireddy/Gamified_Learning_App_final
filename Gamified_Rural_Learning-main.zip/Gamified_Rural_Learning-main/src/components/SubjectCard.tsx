import { Subject } from "../data/subjects";
import { useLang } from "../context/LanguageContext";
import { ChevronRight } from "lucide-react";

interface SubjectCardProps {
  subject: Subject;
  onClick: () => void;
  delay?: number;
}

export const SubjectCard = ({ subject, onClick, delay = 0 }: SubjectCardProps) => {
  const { t } = useLang();

  return (
    <button
      onClick={onClick}
      className="system-window neon-border w-full text-left p-5 transition-all duration-300 hover:border-primary/60 hover:shadow-neon active:scale-[0.98] animate-slide-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-4xl">{subject.icon}</span>
          <div>
            <h3 className="font-bold text-lg text-foreground">{t(subject.name, subject.nameHi, subject.nameTe)}</h3>
            <p className="text-muted-foreground text-sm font-medium">
              {subject.lessons} {t('lessons', 'पाठ', 'పాఠాలు')}
            </p>
          </div>
        </div>
        <ChevronRight className="w-6 h-6 text-primary" />
      </div>
      
      <div className="mt-4 bg-muted rounded h-2.5 overflow-hidden border border-border">
        <div 
          className="bg-gradient-to-r from-primary to-accent h-2.5 transition-all duration-500"
          style={{ width: `${subject.progress}%` }}
        />
      </div>
      <p className="text-sm mt-1.5 text-muted-foreground font-medium">
        {subject.progress}% {t('complete', 'पूर्ण', 'పూర్తయింది')}
      </p>
    </button>
  );
};
