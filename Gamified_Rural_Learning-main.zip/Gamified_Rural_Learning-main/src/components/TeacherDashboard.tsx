import { useLang } from "../context/LanguageContext";
import { Users, TrendingUp, Award, BookOpen, Shield, Sword } from "lucide-react";

interface HunterData {
  name: string;
  nameHi: string;
  nameTe: string;
  rank: 'E' | 'D' | 'C' | 'B' | 'A' | 'S';
  level: number;
  xp: number;
  progress: number;
  avatar: string;
}

const mockHunters: HunterData[] = [
  { name: 'Shadow Blade', nameHi: 'शैडो ब्लेड', nameTe: 'షాడో బ్లేడ్', rank: 'B', level: 6, xp: 340, progress: 72, avatar: '🗡️' },
  { name: 'Iron Fist', nameHi: 'आयरन फिस्ट', nameTe: 'ఐరన్ ఫిస్ట్', rank: 'C', level: 5, xp: 280, progress: 65, avatar: '👊' },
  { name: 'Storm Walker', nameHi: 'स्टॉर्म वॉकर', nameTe: 'స్టార్మ్ వాకర్', rank: 'C', level: 4, xp: 210, progress: 58, avatar: '⚡' },
  { name: 'Healer', nameHi: 'हीलर', nameTe: 'హీలర్', rank: 'D', level: 3, xp: 150, progress: 45, avatar: '💚' },
  { name: 'Tank', nameHi: 'टैंक', nameTe: 'ట్యాంక్', rank: 'D', level: 3, xp: 120, progress: 40, avatar: '🛡️' },
];

const getRankStyle = (rank: string) => {
  switch (rank) {
    case 'S': return 'border-yellow-500/60 text-yellow-400 bg-yellow-500/10';
    case 'A': return 'border-red-500/60 text-red-400 bg-red-500/10';
    case 'B': return 'border-orange-500/60 text-orange-400 bg-orange-500/10';
    case 'C': return 'border-blue-400/60 text-blue-300 bg-blue-400/10';
    case 'D': return 'border-green-400/60 text-green-300 bg-green-400/10';
    default: return 'border-muted-foreground/60 text-muted-foreground bg-muted';
  }
};

export const TeacherDashboard = () => {
  const { t, lang } = useLang();

  const totalHunters = mockHunters.length;
  const avgProgress = Math.round(mockHunters.reduce((a, s) => a + s.progress, 0) / totalHunters);
  const totalXP = mockHunters.reduce((a, s) => a + s.xp, 0);

  const getHunterName = (hunter: HunterData) => {
    if (lang === 'te') return hunter.nameTe;
    if (lang === 'hi') return hunter.nameHi;
    return hunter.name;
  };

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-4 pt-4">
        <h2 className="text-sm font-bold text-primary mb-4 uppercase tracking-widest flex items-center gap-2 neon-text">
          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse-glow" />
          {t('Guild Overview', 'गिल्ड ओवरव्यू', 'గిల్డ్ ఓవర్‌వ్యూ')}
        </h2>
        
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="system-window neon-border p-4">
            <Users className="w-5 h-5 text-primary mb-2" />
            <p className="text-2xl font-extrabold text-foreground">{totalHunters}</p>
            <p className="text-xs text-muted-foreground font-medium">{t('Hunters', 'हंटर्स', 'హంటర్లు')}</p>
          </div>
          <div className="system-window neon-border p-4">
            <TrendingUp className="w-5 h-5 text-accent mb-2" />
            <p className="text-2xl font-extrabold text-foreground">{avgProgress}%</p>
            <p className="text-xs text-muted-foreground font-medium">{t('Avg Progress', 'औसत प्रगति', 'సగటు పురోగతి')}</p>
          </div>
          <div className="system-window neon-border p-4">
            <Award className="w-5 h-5 text-secondary mb-2" />
            <p className="text-2xl font-extrabold text-foreground">{totalXP}</p>
            <p className="text-xs text-muted-foreground font-medium">{t('Total XP', 'कुल XP', 'మొత్తం XP')}</p>
          </div>
          <div className="system-window neon-border p-4">
            <BookOpen className="w-5 h-5 text-foreground mb-2" />
            <p className="text-2xl font-extrabold text-foreground">5</p>
            <p className="text-xs text-muted-foreground font-medium">{t('Dungeons', 'डंजन्स', 'డంజియన్లు')}</p>
          </div>
        </div>
      </div>

      {/* Rank Tiers */}
      <div className="px-4 mb-6">
        <h3 className="text-sm font-bold text-primary mb-3 uppercase tracking-widest flex items-center gap-2">
          <Shield className="w-4 h-4" />
          {t('Rank Tiers', 'रैंक श्रेणियाँ', 'ర్యాంక్ స్థాయిలు')}
        </h3>
        <div className="flex gap-2">
          {['S', 'A', 'B', 'C', 'D', 'E'].map(rank => (
            <div key={rank} className={`flex-1 p-2 rounded-lg border text-center ${getRankStyle(rank)}`}>
              <p className="text-sm font-extrabold">{rank}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Hunter List */}
      <div className="px-4">
        <h3 className="text-sm font-bold text-primary mb-3 uppercase tracking-widest flex items-center gap-2">
          <Sword className="w-4 h-4" />
          {t('Guild Members', 'गिल्ड सदस्य', 'గిల్డ్ సభ్యులు')}
        </h3>
        <div className="space-y-3">
          {mockHunters.map((hunter, index) => (
            <div key={index} className="system-window neon-border p-4 animate-slide-up" style={{ animationDelay: `${index * 80}ms` }}>
              <div className="flex items-center gap-3">
                <div className="text-3xl">{hunter.avatar}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-foreground">{getHunterName(hunter)}</h4>
                    <span className={`px-1.5 py-0.5 rounded border text-xs font-bold ${getRankStyle(hunter.rank)}`}>
                      {hunter.rank}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Lv. {hunter.level} • {hunter.xp} XP
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-primary neon-text">{hunter.progress}%</p>
                </div>
              </div>
              <div className="mt-3 bg-muted rounded h-2 overflow-hidden border border-border">
                <div 
                  className="bg-gradient-to-r from-primary to-accent h-2 transition-all duration-500"
                  style={{ width: `${hunter.progress}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
