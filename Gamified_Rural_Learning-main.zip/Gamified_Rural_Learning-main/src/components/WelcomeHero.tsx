import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";

export const WelcomeHero = () => {
  const { t, lang } = useLang();
  const { student } = useStudent();

  const getHunterName = () => {
    if (lang === 'hi') return student.hunterNameHi;
    if (lang === 'te') return student.hunterNameTe;
    return student.hunterName;
  };

  const getRankColor = (rank: string) => {
    switch (rank) {
      case 'S': return 'border-yellow-500/60 text-yellow-400 bg-yellow-500/10';
      case 'A': return 'border-red-500/60 text-red-400 bg-red-500/10';
      case 'B': return 'border-orange-500/60 text-orange-400 bg-orange-500/10';
      case 'C': return 'border-yellow-400/60 text-yellow-300 bg-yellow-400/10';
      case 'D': return 'border-blue-400/60 text-blue-300 bg-blue-400/10';
      default: return 'border-green-500/60 text-green-400 bg-green-500/10';
    }
  };

  const xpPercentage = (student.xp / student.xpToNextLevel) * 100;

  return (
    <div className="system-window neon-border p-5 mx-4 mt-4 animate-scale-in">
      {/* System notification style header */}
      <div className="flex items-center gap-1 mb-3">
        <div className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" />
        <span className="text-xs font-bold text-primary uppercase tracking-widest">
          {t('Player Status', 'खिलाड़ी स्थिति', 'ప్లేయర్ స్థితి')}
        </span>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="text-5xl animate-bounce-gentle">{student.avatar}</div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-xl font-extrabold text-foreground neon-text">
              {getHunterName()}
            </h2>
            <span className={`px-2 py-0.5 rounded border text-xs font-bold ${getRankColor(student.rank)}`}>
              {student.rank}-{t('Rank', 'रैंक', 'ర్యాంక్')}
            </span>
          </div>
          <p className="text-muted-foreground font-semibold text-sm">
            {t('Lv.', 'लेवल', 'లెవల్')} {student.level} • {student.xp}/{student.xpToNextLevel} XP
          </p>
        </div>
      </div>

      <div className="mt-4 bg-muted rounded h-3 overflow-hidden border border-border">
        <div 
          className="bg-gradient-to-r from-primary to-accent h-3 transition-all duration-500"
          style={{ width: `${xpPercentage}%` }}
        />
      </div>
      <p className="text-xs mt-2 text-muted-foreground font-medium">
        {student.xpToNextLevel - student.xp} XP {t('to next level', 'अगले लेवल तक', 'తదుపరి లెవల్‌కు')} ⚔️
      </p>
    </div>
  );
};
