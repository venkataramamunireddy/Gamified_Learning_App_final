import { createContext, useContext, ReactNode } from 'react';
import { useOffline } from '../hooks/useOffline';

interface OfflineContextType {
  isOnline: boolean;
  syncStatus: {
    lastSynced: Date | null;
    isSyncing: boolean;
    pendingChanges: number;
  };
  syncData: () => Promise<void>;
  addPendingChange: () => void;
}

const OfflineContext = createContext<OfflineContextType | null>(null);

export const OfflineProvider = ({ children }: { children: ReactNode }) => {
  const offlineState = useOffline();

  return (
    <OfflineContext.Provider value={offlineState}>
      {children}
    </OfflineContext.Provider>
  );
};

export const useOfflineStatus = () => {
  const context = useContext(OfflineContext);
  if (!context) {
    throw new Error('useOfflineStatus must be used within an OfflineProvider');
  }
  return context;
};
