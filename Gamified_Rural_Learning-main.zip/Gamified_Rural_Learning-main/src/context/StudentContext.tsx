import { createContext, useContext, useState, ReactNode, useEffect } from "react";

export interface HunterStats {
  strength: number;
  intelligence: number;
  vitality: number;
  agility: number;
  sense: number;
}

export interface StudentProfile {
  id: string;
  hunterName: string;
  hunterNameHi: string;
  hunterNameTe: string;
  avatar: string;
  level: number;
  xp: number;
  xpToNextLevel: number;
  streak: number;
  lessonsCompleted: number;
  quizzesCompleted: number;
  battlesWon: number;
  rank: 'E' | 'D' | 'C' | 'B' | 'A' | 'S';
  stats: HunterStats;
}

const hunterNames = [
  { en: 'Shadow Hunter', hi: 'छाया शिकारी', te: 'షాడో హంటర్', avatar: '⚔️' },
  { en: 'Blazing Hunter', hi: 'ज्वलंत शिकारी', te: 'బ్లేజింగ్ హంటర్', avatar: '🔥' },
  { en: 'Storm Hunter', hi: 'तूफान शिकारी', te: 'స్టార్మ్ హంటర్', avatar: '⚡' },
  { en: 'Iron Hunter', hi: 'लौह शिकारी', te: 'ఐరన్ హంటర్', avatar: '🛡️' },
  { en: 'Frost Hunter', hi: 'हिम शिकारी', te: 'ఫ్రాస్ట్ హంటర్', avatar: '❄️' },
  { en: 'Phantom Hunter', hi: 'प्रेत शिकारी', te: 'ఫాంటమ్ హంటర్', avatar: '👻' },
  { en: 'Dragon Hunter', hi: 'ड्रैगन शिकारी', te: 'డ్రాగన్ హంటర్', avatar: '🐉' },
  { en: 'Celestial Hunter', hi: 'दिव्य शिकारी', te: 'సెలెస్టియల్ హంటర్', avatar: '✨' },
];

const getRankFromLevel = (level: number): 'E' | 'D' | 'C' | 'B' | 'A' | 'S' => {
  if (level >= 50) return 'S';
  if (level >= 40) return 'A';
  if (level >= 30) return 'B';
  if (level >= 20) return 'C';
  if (level >= 10) return 'D';
  return 'E';
};

const getXpToNextLevel = (level: number): number => {
  return Math.floor(100 * Math.pow(1.2, level - 1));
};

const generateHunterIdentity = (): Omit<StudentProfile, 'level' | 'xp' | 'xpToNextLevel' | 'streak' | 'lessonsCompleted' | 'quizzesCompleted' | 'battlesWon' | 'rank' | 'stats'> => {
  const hunter = hunterNames[Math.floor(Math.random() * hunterNames.length)];
  return {
    id: Math.random().toString(36).substring(2, 9),
    hunterName: hunter.en,
    hunterNameHi: hunter.hi,
    hunterNameTe: hunter.te,
    avatar: hunter.avatar,
  };
};

interface StudentContextType {
  student: StudentProfile;
  addXP: (amount: number) => void;
  completeLesson: () => void;
  completeQuiz: () => void;
  winBattle: () => void;
  addStats: (stats: Partial<HunterStats>) => void;
}

const StudentContext = createContext<StudentContextType | null>(null);

export const StudentProvider = ({ children }: { children: ReactNode }) => {
  const [student, setStudent] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('rurallearn-student');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Migrate old ant data to hunter data
      if (parsed.antName || !parsed.hunterName) {
        const identity = generateHunterIdentity();
        return {
          ...identity,
          level: parsed.level || 1,
          xp: parsed.xp || 0,
          xpToNextLevel: getXpToNextLevel(parsed.level || 1),
          streak: parsed.streak || 0,
          lessonsCompleted: parsed.lessonsCompleted || 0,
          quizzesCompleted: parsed.quizzesCompleted || 0,
          battlesWon: parsed.battlesWon || 0,
          rank: getRankFromLevel(parsed.level || 1),
          stats: parsed.stats || { strength: 10, intelligence: 10, vitality: 10, agility: 10, sense: 10 },
        };
      }
      // Ensure all new fields exist
      return {
        ...parsed,
        xpToNextLevel: parsed.xpToNextLevel || getXpToNextLevel(parsed.level || 1),
        quizzesCompleted: parsed.quizzesCompleted || 0,
        battlesWon: parsed.battlesWon || 0,
        rank: parsed.rank || getRankFromLevel(parsed.level || 1),
        stats: parsed.stats || { strength: 10, intelligence: 10, vitality: 10, agility: 10, sense: 10 },
      };
    }
    const identity = generateHunterIdentity();
    return {
      ...identity,
      level: 1,
      xp: 0,
      xpToNextLevel: 100,
      streak: 0,
      lessonsCompleted: 0,
      quizzesCompleted: 0,
      battlesWon: 0,
      rank: 'E' as const,
      stats: { strength: 10, intelligence: 10, vitality: 10, agility: 10, sense: 10 },
    };
  });

  useEffect(() => {
    localStorage.setItem('rurallearn-student', JSON.stringify(student));
  }, [student]);

  const addXP = (amount: number) => {
    setStudent(prev => {
      let newXP = prev.xp + amount;
      let newLevel = prev.level;
      let xpNeeded = prev.xpToNextLevel;
      let newStats = { ...prev.stats };

      // Level up logic
      while (newXP >= xpNeeded) {
        newXP -= xpNeeded;
        newLevel++;
        xpNeeded = getXpToNextLevel(newLevel);
        
        // Add stats on level up (Solo Leveling style)
        newStats = {
          strength: newStats.strength + 2,
          intelligence: newStats.intelligence + 2,
          vitality: newStats.vitality + 1,
          agility: newStats.agility + 1,
          sense: newStats.sense + 1,
        };
      }

      const newRank = getRankFromLevel(newLevel);

      return {
        ...prev,
        xp: newXP,
        level: newLevel,
        xpToNextLevel: xpNeeded,
        rank: newRank,
        stats: newStats,
      };
    });
  };

  const completeLesson = () => {
    setStudent(prev => ({ ...prev, lessonsCompleted: prev.lessonsCompleted + 1 }));
  };

  const completeQuiz = () => {
    setStudent(prev => ({ ...prev, quizzesCompleted: prev.quizzesCompleted + 1 }));
  };

  const winBattle = () => {
    setStudent(prev => ({ ...prev, battlesWon: prev.battlesWon + 1 }));
  };

  const addStats = (stats: Partial<HunterStats>) => {
    setStudent(prev => ({
      ...prev,
      stats: {
        strength: prev.stats.strength + (stats.strength || 0),
        intelligence: prev.stats.intelligence + (stats.intelligence || 0),
        vitality: prev.stats.vitality + (stats.vitality || 0),
        agility: prev.stats.agility + (stats.agility || 0),
        sense: prev.stats.sense + (stats.sense || 0),
      },
    }));
  };

  return (
    <StudentContext.Provider value={{ student, addXP, completeLesson, completeQuiz, winBattle, addStats }}>
      {children}
    </StudentContext.Provider>
  );
};

export const useStudent = () => {
  const context = useContext(StudentContext);
  if (!context) {
    throw new Error("useStudent must be used within a StudentProvider");
  }
  return context;
};
