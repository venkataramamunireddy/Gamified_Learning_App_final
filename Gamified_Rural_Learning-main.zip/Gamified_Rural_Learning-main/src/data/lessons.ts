export interface Lesson {
  id: string;
  subjectId: string;
  title: string;
  titleHi: string;
  titleTe: string;
  content: string;
  contentHi: string;
  contentTe: string;
  examples: {
    title: string;
    titleHi: string;
    titleTe: string;
    content: string;
    contentHi: string;
    contentTe: string;
    emoji: string;
  }[];
  practiceQuestion: {
    question: string;
    questionHi: string;
    questionTe: string;
    options: string[];
    optionsHi: string[];
    optionsTe: string[];
    correctAnswer: number;
  };
}

export const lessons: Lesson[] = [
  // ========================
  // MATHEMATICS - AP SCERT Class 6
  // ========================
  
  // 1. Knowing Our Numbers
  {
    id: 'math-numbers-1',
    subjectId: 'math',
    title: 'Knowing Our Numbers',
    titleHi: 'संख्याओं को जानना',
    titleTe: 'సంఖ్యలను తెలుసుకోవడం',
    content: 'We use numbers to count, measure, and compare.\n\nPlace value tells the value of a digit based on its position.\n\nEstimation helps us find an approximate value.',
    contentHi: 'हम गिनने, मापने और तुलना करने के लिए संख्याओं का उपयोग करते हैं।\n\nस्थान मान एक अंक का मूल्य उसकी स्थिति के आधार पर बताता है।\n\nअनुमान हमें एक सन्निकट मूल्य खोजने में मदद करता है।',
    contentTe: 'మేము లెక్కించడానికి, కొలవడానికి మరియు పోల్చడానికి సంఖ్యలను ఉపయోగిస్తాము.\n\nస్థాన విలువ అంకె యొక్క విలువను దాని స్థానం ఆధారంగా చెబుతుంది.\n\nఅంచనా మనకు సుమారు విలువను కనుగొనడంలో సహాయపడుతుంది.',
    examples: [
      {
        title: 'Place Value',
        titleHi: 'स्थान मान',
        titleTe: 'స్థాన విలువ',
        emoji: '🔢',
        content: '3,245 → 3 thousands, 2 hundreds, 4 tens, 5 ones.\n\nEach digit has a different value based on its place.',
        contentHi: '3,245 → 3 हज़ार, 2 सौ, 4 दहाई, 5 इकाई।\n\nहर अंक का मूल्य उसकी जगह पर निर्भर करता है।',
        contentTe: '3,245 → 3 వేలు, 2 వందలు, 4 పదులు, 5 ఒకట్లు.\n\nప్రతి అంకె యొక్క విలువ దాని స్థానం ఆధారంగా మారుతుంది.',
      },
      {
        title: 'Comparing Numbers',
        titleHi: 'संख्याओं की तुलना',
        titleTe: 'సంఖ్యలను పోల్చడం',
        emoji: '⚖️',
        content: '5,678 > 4,999\n\nWe compare from the leftmost digit.\n5 thousands is more than 4 thousands.',
        contentHi: '5,678 > 4,999\n\nहम बाएं से तुलना करते हैं।\n5 हज़ार, 4 हज़ार से ज्यादा है।',
        contentTe: '5,678 > 4,999\n\nమేము ఎడమ వైపు అంకె నుండి పోలుస్తాము.\n5 వేలు 4 వేల కంటే ఎక్కువ.',
      },
    ],
    practiceQuestion: {
      question: 'In the number 6,432, what is the place value of 4?',
      questionHi: '6,432 संख्या में 4 का स्थान मान क्या है?',
      questionTe: '6,432 సంఖ్యలో 4 యొక్క స్థాన విలువ ఏమిటి?',
      options: ['4', '40', '400', '4000'],
      optionsHi: ['4', '40', '400', '4000'],
      optionsTe: ['4', '40', '400', '4000'],
      correctAnswer: 2,
    },
  },

  // 2. Whole Numbers
  {
    id: 'math-whole-numbers',
    subjectId: 'math',
    title: 'Whole Numbers',
    titleHi: 'पूर्ण संख्याएं',
    titleTe: 'పూర్ణ సంఖ్యలు',
    content: 'Whole numbers start from 0, 1, 2, 3...\n\nNumber line helps us understand order.\n\nProperties: closure, commutative, associative.',
    contentHi: 'पूर्ण संख्याएं 0, 1, 2, 3... से शुरू होती हैं।\n\nसंख्या रेखा हमें क्रम समझने में मदद करती है।\n\nगुण: संवृत, क्रमविनिमेय, साहचर्य।',
    contentTe: 'పూర్ణ సంఖ్యలు 0, 1, 2, 3... నుండి ప్రారంభమవుతాయి.\n\nసంఖ్యా రేఖ క్రమాన్ని అర్థం చేసుకోవడంలో సహాయపడుతుంది.\n\nలక్షణాలు: సంవృతత్వం, వినిమయ, సహచర.',
    examples: [
      {
        title: 'Commutative Property',
        titleHi: 'क्रमविनिमेय गुण',
        titleTe: 'వినిమయ లక్షణం',
        emoji: '🔄',
        content: '5 + 3 = 3 + 5 = 8\n\nOrder does not matter in addition!',
        contentHi: '5 + 3 = 3 + 5 = 8\n\nजोड़ में क्रम से कोई फर्क नहीं पड़ता!',
        contentTe: '5 + 3 = 3 + 5 = 8\n\nకూడికలో క్రమం ముఖ్యం కాదు!',
      },
      {
        title: 'Number Line',
        titleHi: 'संख्या रेखा',
        titleTe: 'సంఖ్యా రేఖ',
        emoji: '📏',
        content: '0 ← 1 ← 2 ← 3 ← 4 ← 5\n\nNumbers increase as we move right.',
        contentHi: '0 ← 1 ← 2 ← 3 ← 4 ← 5\n\nदाएं जाने पर संख्याएं बढ़ती हैं।',
        contentTe: '0 ← 1 ← 2 ← 3 ← 4 ← 5\n\nకుడి వైపుకు వెళ్ళేకొద్దీ సంఖ్యలు పెరుగుతాయి.',
      },
    ],
    practiceQuestion: {
      question: 'Which is the smallest whole number?',
      questionHi: 'सबसे छोटी पूर्ण संख्या कौन सी है?',
      questionTe: 'అతి చిన్న పూర్ణ సంఖ్య ఏది?',
      options: ['1', '0', '-1', '10'],
      optionsHi: ['1', '0', '-1', '10'],
      optionsTe: ['1', '0', '-1', '10'],
      correctAnswer: 1,
    },
  },

  // 3. Playing with Numbers
  {
    id: 'math-playing-numbers',
    subjectId: 'math',
    title: 'Playing with Numbers',
    titleHi: 'संख्याओं के साथ खेल',
    titleTe: 'సంఖ్యలతో ఆట',
    content: 'Factors divide a number exactly.\n\nMultiples are products of a number.\n\nPrime numbers have only two factors: 1 and itself.',
    contentHi: 'गुणनखंड एक संख्या को पूरी तरह विभाजित करते हैं।\n\nगुणज एक संख्या के गुणनफल हैं।\n\nअभाज्य संख्याओं के केवल दो गुणनखंड होते हैं: 1 और वह संख्या।',
    contentTe: 'కారణాంకాలు సంఖ్యను సరిగ్గా భాగిస్తాయి.\n\nగుణిజాలు ఒక సంఖ్య యొక్క గుణాలు.\n\nప్రధాన సంఖ్యలకు రెండు కారణాంకాలు మాత్రమే ఉంటాయి: 1 మరియు అదే సంఖ్య.',
    examples: [
      {
        title: 'Factors of 6',
        titleHi: '6 के गुणनखंड',
        titleTe: '6 యొక్క కారణాంకాలు',
        emoji: '🧮',
        content: 'Factors of 6 → 1, 2, 3, 6\n\n6 ÷ 1 = 6 ✓\n6 ÷ 2 = 3 ✓\n6 ÷ 3 = 2 ✓',
        contentHi: '6 के गुणनखंड → 1, 2, 3, 6\n\n6 ÷ 1 = 6 ✓\n6 ÷ 2 = 3 ✓\n6 ÷ 3 = 2 ✓',
        contentTe: '6 యొక్క కారణాంకాలు → 1, 2, 3, 6\n\n6 ÷ 1 = 6 ✓\n6 ÷ 2 = 3 ✓\n6 ÷ 3 = 2 ✓',
      },
      {
        title: 'Prime Numbers',
        titleHi: 'अभाज्य संख्याएं',
        titleTe: 'ప్రధాన సంఖ్యలు',
        emoji: '⭐',
        content: '2, 3, 5, 7, 11, 13...\n\nThese can only be divided by 1 and themselves.',
        contentHi: '2, 3, 5, 7, 11, 13...\n\nये केवल 1 और खुद से विभाजित होती हैं।',
        contentTe: '2, 3, 5, 7, 11, 13...\n\nఇవి 1 మరియు తమ ద్వారా మాత్రమే భాగించబడతాయి.',
      },
    ],
    practiceQuestion: {
      question: 'Which of these is a prime number?',
      questionHi: 'इनमें से कौन सी अभाज्य संख्या है?',
      questionTe: 'వీటిలో ప్రధాన సంఖ్య ఏది?',
      options: ['4', '6', '7', '9'],
      optionsHi: ['4', '6', '7', '9'],
      optionsTe: ['4', '6', '7', '9'],
      correctAnswer: 2,
    },
  },

  // 4. Basic Geometrical Ideas
  {
    id: 'math-geometry-basic',
    subjectId: 'math',
    title: 'Basic Geometrical Ideas',
    titleHi: 'मूल ज्यामितीय विचार',
    titleTe: 'ప్రాథమిక రేఖాగణిత భావనలు',
    content: 'Point: has no size, just a location.\n\nLine: extends in both directions forever.\n\nAngle: formed by two rays with a common point.',
    contentHi: 'बिंदु: इसका कोई आकार नहीं, केवल स्थान।\n\nरेखा: दोनों दिशाओं में अनंत तक फैलती है।\n\nकोण: एक साझा बिंदु वाली दो किरणों से बनता है।',
    contentTe: 'బిందువు: పరిమాణం లేదు, స్థానం మాత్రమే.\n\nరేఖ: రెండు దిశలలో అనంతంగా విస్తరిస్తుంది.\n\nకోణం: ఉమ్మడి బిందువు ఉన్న రెండు కిరణాల ద్వారా ఏర్పడుతుంది.',
    examples: [
      {
        title: 'Right Angle',
        titleHi: 'समकोण',
        titleTe: 'లంబ కోణం',
        emoji: '📐',
        content: 'A door corner shows a right angle.\n\nA right angle = 90 degrees.',
        contentHi: 'दरवाज़े का कोना समकोण दिखाता है।\n\nसमकोण = 90 डिग्री।',
        contentTe: 'తలుపు మూల లంబ కోణాన్ని చూపిస్తుంది.\n\nలంబ కోణం = 90 డిగ్రీలు.',
      },
      {
        title: 'Line Segment',
        titleHi: 'रेखाखंड',
        titleTe: 'రేఖాఖండం',
        emoji: '📏',
        content: 'A line segment has two end points.\n\nExample: The edge of your book.',
        contentHi: 'रेखाखंड के दो अंतिम बिंदु होते हैं।\n\nउदाहरण: आपकी किताब का किनारा।',
        contentTe: 'రేఖాఖండంకు రెండు చివర బిందువులు ఉంటాయి.\n\nఉదాహరణ: మీ పుస్తకం అంచు.',
      },
    ],
    practiceQuestion: {
      question: 'How many degrees is a right angle?',
      questionHi: 'समकोण कितने डिग्री का होता है?',
      questionTe: 'లంబ కోణం ఎన్ని డిగ్రీలు?',
      options: ['45°', '60°', '90°', '180°'],
      optionsHi: ['45°', '60°', '90°', '180°'],
      optionsTe: ['45°', '60°', '90°', '180°'],
      correctAnswer: 2,
    },
  },

  // 5. Understanding Elementary Shapes
  {
    id: 'math-shapes',
    subjectId: 'math',
    title: 'Understanding Elementary Shapes',
    titleHi: 'प्रारंभिक आकृतियों को समझना',
    titleTe: 'ప్రాథమిక ఆకారాలను అర్థం చేసుకోవడం',
    content: 'Types of angles: acute (< 90°), right (90°), obtuse (> 90°).\n\nPolygons: triangle, quadrilateral, pentagon.\n\n3D shapes: cube, sphere, cylinder.',
    contentHi: 'कोण के प्रकार: न्यूनकोण (< 90°), समकोण (90°), अधिककोण (> 90°)।\n\nबहुभुज: त्रिभुज, चतुर्भुज, पंचभुज।\n\n3D आकृतियां: घन, गोला, बेलन।',
    contentTe: 'కోణ రకాలు: అల్ప కోణం (< 90°), లంబ కోణం (90°), అధిక కోణం (> 90°).\n\nబహుభుజాలు: త్రికోణం, చతుర్భుజం, పంచభుజం.\n\n3D ఆకారాలు: ఘనం, గోళం, స్తూపం.',
    examples: [
      {
        title: 'Dice = Cube',
        titleHi: 'पासा = घन',
        titleTe: 'పాచికలు = ఘనం',
        emoji: '🎲',
        content: 'A dice is a cube.\n\nIt has 6 faces, 12 edges, 8 corners.',
        contentHi: 'पासा एक घन है।\n\nइसके 6 फलक, 12 किनारे, 8 कोने हैं।',
        contentTe: 'పాచికలు ఘనం.\n\nదీనికి 6 ముఖాలు, 12 అంచులు, 8 మూలలు ఉన్నాయి.',
      },
      {
        title: 'Ball = Sphere',
        titleHi: 'गेंद = गोला',
        titleTe: 'బంతి = గోళం',
        emoji: '⚽',
        content: 'A ball is a sphere.\n\nIt has no edges, no corners.\n\nIt is perfectly round.',
        contentHi: 'गेंद एक गोला है।\n\nइसके कोई किनारे नहीं, कोई कोने नहीं।\n\nयह पूरी तरह गोल है।',
        contentTe: 'బంతి గోళం.\n\nదీనికి అంచులు లేవు, మూలలు లేవు.\n\nఇది సంపూర్ణంగా గుండ్రంగా ఉంటుంది.',
      },
    ],
    practiceQuestion: {
      question: 'An angle less than 90° is called?',
      questionHi: '90° से कम का कोण क्या कहलाता है?',
      questionTe: '90° కంటే తక్కువ కోణాన్ని ఏమంటారు?',
      options: ['Right angle', 'Obtuse angle', 'Acute angle', 'Straight angle'],
      optionsHi: ['समकोण', 'अधिककोण', 'न्यूनकोण', 'सरल कोण'],
      optionsTe: ['లంబ కోణం', 'అధిక కోణం', 'అల్ప కోణం', 'సరళ కోణం'],
      correctAnswer: 2,
    },
  },

  // 6. Integers
  {
    id: 'math-integers',
    subjectId: 'math',
    title: 'Integers',
    titleHi: 'पूर्णांक',
    titleTe: 'పూర్ణాంకాలు',
    content: 'Integers include negative numbers, zero, and positive numbers.\n\n... -3, -2, -1, 0, 1, 2, 3 ...\n\nUsed to show temperature, profit/loss, above/below sea level.',
    contentHi: 'पूर्णांक में ऋणात्मक संख्याएं, शून्य और धनात्मक संख्याएं शामिल हैं।\n\n... -3, -2, -1, 0, 1, 2, 3 ...\n\nतापमान, लाभ/हानि दिखाने के लिए उपयोग होता है।',
    contentTe: 'పూర్ణాంకాలలో ఋణ సంఖ్యలు, సున్న మరియు ధన సంఖ్యలు ఉంటాయి.\n\n... -3, -2, -1, 0, 1, 2, 3 ...\n\nఉష్ణోగ్రత, లాభం/నష్టం చూపించడానికి ఉపయోగిస్తారు.',
    examples: [
      {
        title: 'Temperature',
        titleHi: 'तापमान',
        titleTe: 'ఉష్ణోగ్రత',
        emoji: '🌡️',
        content: '–5°C is colder than 0°C.\n\n0°C is when water freezes.',
        contentHi: '–5°C, 0°C से ठंडा है।\n\n0°C पर पानी जमता है।',
        contentTe: '–5°C 0°C కంటే చల్లగా ఉంటుంది.\n\n0°C వద్ద నీరు గడ్డకడుతుంది.',
      },
      {
        title: 'Profit & Loss',
        titleHi: 'लाभ और हानि',
        titleTe: 'లాభం & నష్టం',
        emoji: '💰',
        content: 'Profit of ₹50 = +50\n\nLoss of ₹30 = –30',
        contentHi: '₹50 का लाभ = +50\n\n₹30 की हानि = –30',
        contentTe: '₹50 లాభం = +50\n\n₹30 నష్టం = –30',
      },
    ],
    practiceQuestion: {
      question: 'Which is colder: –10°C or –5°C?',
      questionHi: 'कौन सा ठंडा है: –10°C या –5°C?',
      questionTe: 'ఏది చల్లగా ఉంటుంది: –10°C లేదా –5°C?',
      options: ['–5°C', '–10°C', 'Both same', '0°C'],
      optionsHi: ['–5°C', '–10°C', 'दोनों समान', '0°C'],
      optionsTe: ['–5°C', '–10°C', 'రెండూ సమానం', '0°C'],
      correctAnswer: 1,
    },
  },

  // 7. Fractions
  {
    id: 'math-fractions-1',
    subjectId: 'math',
    title: 'What is a Fraction?',
    titleHi: 'भिन्न क्या है?',
    titleTe: 'భిన్నం అంటే ఏమిటి?',
    content: 'A fraction means a part of a whole.\n\nWhen we divide something into equal parts, each part is called a fraction.\n\nTypes: proper, improper, mixed.',
    contentHi: 'भिन्न का मतलब है किसी पूरी चीज़ का एक भाग।\n\nजब हम किसी चीज़ को बराबर भागों में बाँटते हैं, तो हर भाग को भिन्न कहते हैं।\n\nप्रकार: उचित, अनुचित, मिश्रित।',
    contentTe: 'భిన్నం అంటే ఒక సంపూర్ణ వస్తువులో ఒక భాగం.\n\nఏదైనా వస్తువును సమాన భాగాలుగా పంచితే, ప్రతి భాగాన్ని భిన్నం అంటారు.\n\nరకాలు: సరియైన, సరికాని, మిశ్రమ.',
    examples: [
      {
        title: 'Pizza Example',
        titleHi: 'पिज़्ज़ा उदाहरण',
        titleTe: 'పిజ్జా ఉదాహరణ',
        emoji: '🍕',
        content: 'A pizza is cut into 2 equal parts.\nYou eat 1 part.\n\nSo, you ate ½ (one-half).',
        contentHi: 'पिज़्ज़ा को 2 बराबर भागों में काटा गया।\nआपने 1 भाग खाया।\n\nतो आपने ½ (आधा) खाया।',
        contentTe: 'పిజ్జాను 2 సమాన భాగాలుగా కోసారు.\nమీరు 1 భాగం తిన్నారు.\n\nఅంటే మీరు ½ (సగం) తిన్నారు.',
      },
      {
        title: 'Roti Example',
        titleHi: 'रोटी उदाहरण',
        titleTe: 'రొట్టి ఉదాహరణ',
        emoji: '🫓',
        content: 'A roti is divided into 4 equal parts.\nYou eat 1 part.\n\nFraction eaten = ¼ (one-fourth)',
        contentHi: 'रोटी को 4 बराबर भागों में बाँटा गया।\nआपने 1 भाग खाया।\n\nखाया गया भिन्न = ¼ (एक-चौथाई)',
        contentTe: 'రొట్టిని 4 సమాన భాగాలుగా పంచారు.\nమీరు 1 భాగం తిన్నారు.\n\nతిన్న భిన్నం = ¼ (నాలుగో వంతు)',
      },
    ],
    practiceQuestion: {
      question: 'A roti is divided into 2 equal parts.\nYou eat 1 part.\n\nWhich fraction did you eat?',
      questionHi: 'रोटी को 2 बराबर भागों में बाँटा गया।\nआपने 1 भाग खाया।\n\nआपने कौन सा भिन्न खाया?',
      questionTe: 'రొట్టిని 2 సమాన భాగాలుగా పంచారు.\nమీరు 1 భాగం తిన్నారు.\n\nమీరు ఏ భిన్నం తిన్నారు?',
      options: ['½', '1', '2', '¼'],
      optionsHi: ['½', '1', '2', '¼'],
      optionsTe: ['½', '1', '2', '¼'],
      correctAnswer: 0,
    },
  },

  // 8. Decimals
  {
    id: 'math-decimals',
    subjectId: 'math',
    title: 'Decimals',
    titleHi: 'दशमलव',
    titleTe: 'దశాంశాలు',
    content: 'Decimals are fractions written using a point.\n\nUsed in money, measurements, and calculations.\n\nExample: 0.5 = ½',
    contentHi: 'दशमलव बिंदु का उपयोग करके लिखे गए भिन्न हैं।\n\nपैसे, माप और गणना में उपयोग होता है।\n\nउदाहरण: 0.5 = ½',
    contentTe: 'దశాంశాలు బిందువు ఉపయోగించి వ్రాసిన భిన్నాలు.\n\nడబ్బు, కొలతలు మరియు లెక్కలలో ఉపయోగిస్తారు.\n\nఉదాహరణ: 0.5 = ½',
    examples: [
      {
        title: 'Money',
        titleHi: 'पैसे',
        titleTe: 'డబ్బు',
        emoji: '💵',
        content: '₹5.50 means 5 rupees and 50 paise.\n\n₹10.25 means 10 rupees and 25 paise.',
        contentHi: '₹5.50 का मतलब 5 रुपये और 50 पैसे।\n\n₹10.25 का मतलब 10 रुपये और 25 पैसे।',
        contentTe: '₹5.50 అంటే 5 రూపాయలు మరియు 50 పైసలు.\n\n₹10.25 అంటే 10 రూపాయలు మరియు 25 పైసలు.',
      },
      {
        title: 'Length',
        titleHi: 'लंबाई',
        titleTe: 'పొడవు',
        emoji: '📏',
        content: '2.5 meters = 2 meters and 50 centimeters.\n\n1.75 m = 1 meter 75 cm.',
        contentHi: '2.5 मीटर = 2 मीटर और 50 सेंटीमीटर।\n\n1.75 मी = 1 मीटर 75 सेमी।',
        contentTe: '2.5 మీటర్లు = 2 మీటర్లు మరియు 50 సెంటీమీటర్లు.\n\n1.75 మీ = 1 మీటర్ 75 సెంమీ.',
      },
    ],
    practiceQuestion: {
      question: 'What does ₹7.50 mean?',
      questionHi: '₹7.50 का क्या मतलब है?',
      questionTe: '₹7.50 అంటే ఏమిటి?',
      options: ['7 rupees', '7 rupees 50 paise', '75 paise', '750 rupees'],
      optionsHi: ['7 रुपये', '7 रुपये 50 पैसे', '75 पैसे', '750 रुपये'],
      optionsTe: ['7 రూపాయలు', '7 రూపాయలు 50 పైసలు', '75 పైసలు', '750 రూపాయలు'],
      correctAnswer: 1,
    },
  },

  // 9. Data Handling
  {
    id: 'math-data-handling',
    subjectId: 'math',
    title: 'Data Handling',
    titleHi: 'आँकड़ों का प्रबंधन',
    titleTe: 'డేటా నిర్వహణ',
    content: 'Data means information collected for study.\n\nTally marks help in counting.\n\nBar graphs show data visually.',
    contentHi: 'डेटा का मतलब अध्ययन के लिए एकत्रित जानकारी।\n\nटैली चिह्न गिनती में मदद करते हैं।\n\nबार ग्राफ डेटा को दृश्य रूप में दिखाते हैं।',
    contentTe: 'డేటా అంటే అధ్యయనం కోసం సేకరించిన సమాచారం.\n\nట్యాలీ మార్కులు లెక్కించడంలో సహాయపడతాయి.\n\nబార్ గ్రాఫ్‌లు డేటాను దృశ్యంగా చూపిస్తాయి.',
    examples: [
      {
        title: 'Tally Marks',
        titleHi: 'टैली चिह्न',
        titleTe: 'ట్యాలీ మార్కులు',
        emoji: '📊',
        content: '|||| = 4\n|||| | = 6\n|||| |||| = 10',
        contentHi: '|||| = 4\n|||| | = 6\n|||| |||| = 10',
        contentTe: '|||| = 4\n|||| | = 6\n|||| |||| = 10',
      },
      {
        title: 'Favorite Fruits Survey',
        titleHi: 'पसंदीदा फल सर्वेक्षण',
        titleTe: 'ఇష్టమైన పండ్ల సర్వే',
        emoji: '🍎',
        content: 'Mango: 8 students\nBanana: 5 students\nApple: 3 students\n\nMango is most popular!',
        contentHi: 'आम: 8 छात्र\nकेला: 5 छात्र\nसेब: 3 छात्र\n\nआम सबसे लोकप्रिय है!',
        contentTe: 'మామిడి: 8 విద్యార్థులు\nఅరటి: 5 విద్యార్థులు\nఆపిల్: 3 విద్యార్థులు\n\nమామిడి అత్యంత ప్రసిద్ధం!',
      },
    ],
    practiceQuestion: {
      question: 'What does |||| || represent in tally marks?',
      questionHi: 'टैली चिह्नों में |||| || क्या दर्शाता है?',
      questionTe: 'ట్యాలీ మార్కులలో |||| || ఏమి సూచిస్తుంది?',
      options: ['5', '6', '7', '8'],
      optionsHi: ['5', '6', '7', '8'],
      optionsTe: ['5', '6', '7', '8'],
      correctAnswer: 2,
    },
  },

  // 10. Mensuration
  {
    id: 'math-mensuration',
    subjectId: 'math',
    title: 'Mensuration',
    titleHi: 'क्षेत्रमिति',
    titleTe: 'క్షేత్రమితి',
    content: 'Perimeter = total boundary length.\n\nArea = surface covered inside.\n\nThese help measure land, rooms, and shapes.',
    contentHi: 'परिमाप = कुल सीमा की लंबाई।\n\nक्षेत्रफल = अंदर ढकी सतह।\n\nये जमीन, कमरे और आकृतियों को मापने में मदद करते हैं।',
    contentTe: 'చుట్టుకొలత = మొత్తం సరిహద్దు పొడవు.\n\nవైశాల్యం = లోపల కప్పబడిన ఉపరితలం.\n\nఇవి భూమి, గదులు మరియు ఆకారాలను కొలవడంలో సహాయపడతాయి.',
    examples: [
      {
        title: 'Rectangle',
        titleHi: 'आयत',
        titleTe: 'దీర్ఘచతురస్రం',
        emoji: '📐',
        content: 'Length = 5 m, Breadth = 3 m\n\nPerimeter = 2 × (5 + 3) = 16 m\n\nArea = 5 × 3 = 15 sq m',
        contentHi: 'लंबाई = 5 मी, चौड़ाई = 3 मी\n\nपरिमाप = 2 × (5 + 3) = 16 मी\n\nक्षेत्रफल = 5 × 3 = 15 वर्ग मी',
        contentTe: 'పొడవు = 5 మీ, వెడల్పు = 3 మీ\n\nచుట్టుకొలత = 2 × (5 + 3) = 16 మీ\n\nవైశాల్యం = 5 × 3 = 15 చ.మీ',
      },
      {
        title: 'Square Field',
        titleHi: 'वर्गाकार मैदान',
        titleTe: 'చదరపు మైదానం',
        emoji: '🏟️',
        content: 'Side = 10 m\n\nPerimeter = 4 × 10 = 40 m\n\nArea = 10 × 10 = 100 sq m',
        contentHi: 'भुजा = 10 मी\n\nपरिमाप = 4 × 10 = 40 मी\n\nक्षेत्रफल = 10 × 10 = 100 वर्ग मी',
        contentTe: 'భుజం = 10 మీ\n\nచుట్టుకొలత = 4 × 10 = 40 మీ\n\nవైశాల్యం = 10 × 10 = 100 చ.మీ',
      },
    ],
    practiceQuestion: {
      question: 'What is the area of a rectangle with length 4 m and breadth 2 m?',
      questionHi: 'लंबाई 4 मी और चौड़ाई 2 मी वाले आयत का क्षेत्रफल क्या है?',
      questionTe: 'పొడవు 4 మీ మరియు వెడల్పు 2 మీ ఉన్న దీర్ఘచతురస్రం వైశాల్యం ఎంత?',
      options: ['6 sq m', '8 sq m', '12 sq m', '16 sq m'],
      optionsHi: ['6 वर्ग मी', '8 वर्ग मी', '12 वर्ग मी', '16 वर्ग मी'],
      optionsTe: ['6 చ.మీ', '8 చ.మీ', '12 చ.మీ', '16 చ.మీ'],
      correctAnswer: 1,
    },
  },

  // 11. Algebra
  {
    id: 'math-algebra',
    subjectId: 'math',
    title: 'Algebra',
    titleHi: 'बीजगणित',
    titleTe: 'బీజగణితం',
    content: 'Algebra uses letters to represent numbers.\n\nExpressions like x + 5 show unknown values.\n\nWe can solve to find the value of x.',
    contentHi: 'बीजगणित संख्याओं को दर्शाने के लिए अक्षरों का उपयोग करता है।\n\nx + 5 जैसे व्यंजक अज्ञात मान दिखाते हैं।\n\nहम x का मान ज्ञात करने के लिए हल कर सकते हैं।',
    contentTe: 'బీజగణితం సంఖ్యలను సూచించడానికి అక్షరాలను ఉపయోగిస్తుంది.\n\nx + 5 వంటి వ్యక్తీకరణలు తెలియని విలువలను చూపిస్తాయి.\n\nx విలువను కనుగొనడానికి మేము సాధించగలం.',
    examples: [
      {
        title: 'Simple Expression',
        titleHi: 'सरल व्यंजक',
        titleTe: 'సరళ వ్యక్తీకరణ',
        emoji: '🔤',
        content: 'If x = 2, then x + 5 = 7\n\nIf x = 10, then x + 5 = 15',
        contentHi: 'अगर x = 2, तो x + 5 = 7\n\nअगर x = 10, तो x + 5 = 15',
        contentTe: 'x = 2 అయితే, x + 5 = 7\n\nx = 10 అయితే, x + 5 = 15',
      },
      {
        title: 'Real Life Example',
        titleHi: 'वास्तविक उदाहरण',
        titleTe: 'నిజ జీవిత ఉదాహరణ',
        emoji: '🍬',
        content: 'You have some candies (x).\n\nYou get 3 more.\n\nNow you have x + 3 candies.',
        contentHi: 'आपके पास कुछ टॉफियां (x) हैं।\n\nआपको 3 और मिलती हैं।\n\nअब आपके पास x + 3 टॉफियां हैं।',
        contentTe: 'మీ వద్ద కొన్ని మిఠాయిలు (x) ఉన్నాయి.\n\nమీకు మరో 3 వచ్చాయి.\n\nఇప్పుడు మీ వద్ద x + 3 మిఠాయిలు ఉన్నాయి.',
      },
    ],
    practiceQuestion: {
      question: 'If x = 4, what is x + 6?',
      questionHi: 'अगर x = 4, तो x + 6 क्या है?',
      questionTe: 'x = 4 అయితే, x + 6 ఎంత?',
      options: ['8', '9', '10', '11'],
      optionsHi: ['8', '9', '10', '11'],
      optionsTe: ['8', '9', '10', '11'],
      correctAnswer: 2,
    },
  },

  // 12. Ratio and Proportion
  {
    id: 'math-ratio',
    subjectId: 'math',
    title: 'Ratio and Proportion',
    titleHi: 'अनुपात और समानुपात',
    titleTe: 'నిష్పత్తి మరియు అనుపాతం',
    content: 'Ratio compares two quantities.\n\nProportion shows equality of two ratios.\n\nWritten as a : b or a/b.',
    contentHi: 'अनुपात दो मात्राओं की तुलना करता है।\n\nसमानुपात दो अनुपातों की समानता दिखाता है।\n\na : b या a/b के रूप में लिखा जाता है।',
    contentTe: 'నిష్పత్తి రెండు పరిమాణాలను పోలుస్తుంది.\n\nఅనుపాతం రెండు నిష్పత్తుల సమానత్వాన్ని చూపిస్తుంది.\n\na : b లేదా a/b గా వ్రాస్తారు.',
    examples: [
      {
        title: 'Class Example',
        titleHi: 'कक्षा उदाहरण',
        titleTe: 'తరగతి ఉదాహరణ',
        emoji: '👦',
        content: '20 boys and 30 girls in class.\n\nBoys : Girls = 20 : 30 = 2 : 3',
        contentHi: 'कक्षा में 20 लड़के और 30 लड़कियां।\n\nलड़के : लड़कियां = 20 : 30 = 2 : 3',
        contentTe: 'తరగతిలో 20 మంది అబ్బాయిలు మరియు 30 మంది అమ్మాయిలు.\n\nఅబ్బాయిలు : అమ్మాయిలు = 20 : 30 = 2 : 3',
      },
      {
        title: 'Recipe Example',
        titleHi: 'रेसिपी उदाहरण',
        titleTe: 'వంటకం ఉదాహరణ',
        emoji: '🍰',
        content: 'For cake: 2 cups flour, 1 cup sugar.\n\nFlour : Sugar = 2 : 1',
        contentHi: 'केक के लिए: 2 कप आटा, 1 कप चीनी।\n\nआटा : चीनी = 2 : 1',
        contentTe: 'కేక్ కోసం: 2 కప్పులు పిండి, 1 కప్పు చక్కెర.\n\nపిండి : చక్కెర = 2 : 1',
      },
    ],
    practiceQuestion: {
      question: 'If there are 4 apples and 8 oranges, what is the ratio of apples to oranges?',
      questionHi: 'अगर 4 सेब और 8 संतरे हैं, तो सेब और संतरे का अनुपात क्या है?',
      questionTe: '4 ఆపిల్స్ మరియు 8 నారింజలు ఉంటే, ఆపిల్స్ మరియు నారింజల నిష్పత్తి ఏమిటి?',
      options: ['1:2', '2:1', '4:8', '8:4'],
      optionsHi: ['1:2', '2:1', '4:8', '8:4'],
      optionsTe: ['1:2', '2:1', '4:8', '8:4'],
      correctAnswer: 0,
    },
  },

  // ========================
  // SCIENCE - AP SCERT Class 6
  // ========================

  // 1. Food – Where Does It Come From?
  {
    id: 'science-food-source',
    subjectId: 'science',
    title: 'Food – Where Does It Come From?',
    titleHi: 'भोजन – यह कहाँ से आता है?',
    titleTe: 'ఆహారం – ఇది ఎక్కడి నుండి వస్తుంది?',
    content: 'Food comes from plants and animals.\n\nIngredients make food items.\n\nDifferent parts of plants give us food.',
    contentHi: 'भोजन पौधों और जानवरों से आता है।\n\nसामग्री खाद्य पदार्थ बनाती है।\n\nपौधों के विभिन्न भाग हमें भोजन देते हैं।',
    contentTe: 'ఆహారం మొక్కలు మరియు జంతువుల నుండి వస్తుంది.\n\nపదార్థాలు ఆహార వస్తువులను తయారు చేస్తాయి.\n\nమొక్కల వివిధ భాగాలు మనకు ఆహారం ఇస్తాయి.',
    examples: [
      {
        title: 'From Plants',
        titleHi: 'पौधों से',
        titleTe: 'మొక్కల నుండి',
        emoji: '🌾',
        content: 'Rice comes from paddy.\n\nWheat gives us flour (atta).\n\nVegetables come from different plant parts.',
        contentHi: 'चावल धान से आता है।\n\nगेहूं हमें आटा देता है।\n\nसब्जियां पौधों के विभिन्न भागों से आती हैं।',
        contentTe: 'బియ్యం వరి నుండి వస్తుంది.\n\nగోధుమ మనకు పిండి ఇస్తుంది.\n\nకూరగాయలు మొక్కల వివిధ భాగాల నుండి వస్తాయి.',
      },
      {
        title: 'From Animals',
        titleHi: 'जानवरों से',
        titleTe: 'జంతువుల నుండి',
        emoji: '🥛',
        content: 'Milk comes from cows and buffaloes.\n\nEggs come from hens.\n\nHoney comes from bees.',
        contentHi: 'दूध गाय और भैंस से आता है।\n\nअंडे मुर्गियों से आते हैं।\n\nशहद मधुमक्खियों से आता है।',
        contentTe: 'పాలు ఆవులు మరియు గేదెల నుండి వస్తాయి.\n\nగుడ్లు కోళ్ల నుండి వస్తాయి.\n\nతేనె తేనెటీగల నుండి వస్తుంది.',
      },
    ],
    practiceQuestion: {
      question: 'From which plant does rice come?',
      questionHi: 'चावल किस पौधे से आता है?',
      questionTe: 'బియ్యం ఏ మొక్క నుండి వస్తుంది?',
      options: ['Wheat', 'Paddy', 'Maize', 'Sugarcane'],
      optionsHi: ['गेहूं', 'धान', 'मक्का', 'गन्ना'],
      optionsTe: ['గోధుమ', 'వరి', 'మొక్కజొన్న', 'చెరకు'],
      correctAnswer: 1,
    },
  },

  // 2. Components of Food
  {
    id: 'science-food-components',
    subjectId: 'science',
    title: 'Components of Food',
    titleHi: 'भोजन के घटक',
    titleTe: 'ఆహార భాగాలు',
    content: 'Nutrients: carbohydrates, proteins, fats, vitamins, minerals.\n\nBalanced diet gives all nutrients.\n\nWater is also essential for our body.',
    contentHi: 'पोषक तत्व: कार्बोहाइड्रेट, प्रोटीन, वसा, विटामिन, खनिज।\n\nसंतुलित आहार सभी पोषक तत्व देता है।\n\nपानी भी हमारे शरीर के लिए आवश्यक है।',
    contentTe: 'పోషకాలు: కార్బోహైడ్రేట్లు, ప్రోటీన్లు, కొవ్వులు, విటమిన్లు, ఖనిజాలు.\n\nసమతుల్య ఆహారం అన్ని పోషకాలను ఇస్తుంది.\n\nనీరు కూడా మన శరీరానికి అవసరం.',
    examples: [
      {
        title: 'Protein Foods',
        titleHi: 'प्रोटीन वाले खाद्य',
        titleTe: 'ప్రోటీన్ ఆహారాలు',
        emoji: '🥚',
        content: 'Dal, eggs, milk, fish give protein.\n\nProtein helps our body grow.',
        contentHi: 'दाल, अंडे, दूध, मछली प्रोटीन देते हैं।\n\nप्रोटीन हमारे शरीर को बढ़ने में मदद करता है।',
        contentTe: 'పప్పు, గుడ్లు, పాలు, చేపలు ప్రోటీన్ ఇస్తాయి.\n\nప్రోటీన్ మన శరీరం పెరగడానికి సహాయపడుతుంది.',
      },
      {
        title: 'Energy Foods',
        titleHi: 'ऊर्जा वाले खाद्य',
        titleTe: 'శక్తి ఆహారాలు',
        emoji: '🍚',
        content: 'Rice, roti, potatoes give carbohydrates.\n\nCarbohydrates give us energy to work and play.',
        contentHi: 'चावल, रोटी, आलू कार्बोहाइड्रेट देते हैं।\n\nकार्बोहाइड्रेट हमें काम और खेलने की ऊर्जा देते हैं।',
        contentTe: 'అన్నం, రొట్టి, బంగాళాదుంపలు కార్బోహైడ్రేట్లు ఇస్తాయి.\n\nకార్బోహైడ్రేట్లు పని చేయడానికి మరియు ఆడడానికి శక్తిని ఇస్తాయి.',
      },
    ],
    practiceQuestion: {
      question: 'Which food gives us protein?',
      questionHi: 'कौन सा खाद्य हमें प्रोटीन देता है?',
      questionTe: 'ఏ ఆహారం మనకు ప్రోటీన్ ఇస్తుంది?',
      options: ['Rice', 'Dal', 'Oil', 'Sugar'],
      optionsHi: ['चावल', 'दाल', 'तेल', 'चीनी'],
      optionsTe: ['అన్నం', 'పప్పు', 'నూనె', 'చక్కెర'],
      correctAnswer: 1,
    },
  },

  // 3. Fibre to Fabric
  {
    id: 'science-fibre-fabric',
    subjectId: 'science',
    title: 'Fibre to Fabric',
    titleHi: 'रेशे से कपड़ा',
    titleTe: 'నారల నుండి వస్త్రం',
    content: 'Clothes are made from fibres.\n\nNatural fibres: cotton, wool, silk, jute.\n\nSynthetic fibres: nylon, polyester.',
    contentHi: 'कपड़े रेशों से बने होते हैं।\n\nप्राकृतिक रेशे: कपास, ऊन, रेशम, जूट।\n\nकृत्रिम रेशे: नायलॉन, पॉलिएस्टर।',
    contentTe: 'బట్టలు నారల నుండి తయారవుతాయి.\n\nసహజ నారలు: పత్తి, ఉన్ని, పట్టు, జనపనార.\n\nకృత్రిమ నారలు: నైలాన్, పాలిస్టర్.',
    examples: [
      {
        title: 'Cotton',
        titleHi: 'कपास',
        titleTe: 'పత్తి',
        emoji: '🌿',
        content: 'Cotton comes from cotton plants.\n\nIt is soft and good for summer clothes.',
        contentHi: 'कपास कपास के पौधों से आती है।\n\nयह नरम है और गर्मी के कपड़ों के लिए अच्छी है।',
        contentTe: 'పత్తి పత్తి మొక్కల నుండి వస్తుంది.\n\nఇది మృదువుగా ఉంటుంది మరియు వేసవి బట్టలకు మంచిది.',
      },
      {
        title: 'Wool',
        titleHi: 'ऊन',
        titleTe: 'ఉన్ని',
        emoji: '🐑',
        content: 'Wool comes from sheep.\n\nIt keeps us warm in winter.',
        contentHi: 'ऊन भेड़ से आती है।\n\nयह सर्दियों में हमें गर्म रखती है।',
        contentTe: 'ఉన్ని గొర్రెల నుండి వస్తుంది.\n\nఇది శీతాకాలంలో మనల్ని వెచ్చగా ఉంచుతుంది.',
      },
    ],
    practiceQuestion: {
      question: 'Which animal gives us wool?',
      questionHi: 'कौन सा जानवर हमें ऊन देता है?',
      questionTe: 'ఏ జంతువు మనకు ఉన్ని ఇస్తుంది?',
      options: ['Cow', 'Sheep', 'Goat', 'Buffalo'],
      optionsHi: ['गाय', 'भेड़', 'बकरी', 'भैंस'],
      optionsTe: ['ఆవు', 'గొర్రె', 'మేక', 'గేదె'],
      correctAnswer: 1,
    },
  },

  // 4. Sorting Materials
  {
    id: 'science-sorting-materials',
    subjectId: 'science',
    title: 'Sorting Materials',
    titleHi: 'सामग्रियों का वर्गीकरण',
    titleTe: 'పదార్థాల వర్గీకరణ',
    content: 'Objects are grouped by their properties.\n\nHard/soft, rough/smooth, soluble/insoluble.\n\nTransparent, translucent, opaque.',
    contentHi: 'वस्तुओं को उनके गुणों के आधार पर समूहित किया जाता है।\n\nकठोर/मुलायम, खुरदरा/चिकना, घुलनशील/अघुलनशील।\n\nपारदर्शी, पारभासी, अपारदर्शी।',
    contentTe: 'వస్తువులు వాటి లక్షణాల ఆధారంగా సమూహాలుగా విభజించబడతాయి.\n\nగట్టి/మృదువు, రఫ్/స్మూత్, కరిగేవి/కరగనివి.\n\nపారదర్శక, పారభాసక, అపారదర్శక.',
    examples: [
      {
        title: 'Transparency',
        titleHi: 'पारदर्शिता',
        titleTe: 'పారదర్శకత',
        emoji: '🪟',
        content: 'Glass = Transparent (we can see through)\n\nWood = Opaque (cannot see through)\n\nOiled paper = Translucent (some light passes)',
        contentHi: 'कांच = पारदर्शी (आर-पार देख सकते हैं)\n\nलकड़ी = अपारदर्शी (देख नहीं सकते)\n\nतेल लगा कागज़ = पारभासी (कुछ रोशनी जाती है)',
        contentTe: 'గాజు = పారదర్శకం (చూడగలం)\n\nకలప = అపారదర్శకం (చూడలేము)\n\nనూనె కాగితం = పారభాసకం (కొంత వెలుగు వెళ్తుంది)',
      },
      {
        title: 'Solubility',
        titleHi: 'घुलनशीलता',
        titleTe: 'కరిగే సామర్థ్యం',
        emoji: '🧂',
        content: 'Salt dissolves in water = Soluble.\n\nSand does not dissolve = Insoluble.',
        contentHi: 'नमक पानी में घुल जाता है = घुलनशील।\n\nरेत नहीं घुलती = अघुलनशील।',
        contentTe: 'ఉప్పు నీటిలో కరుగుతుంది = కరిగేది.\n\nఇసుక కరగదు = కరగనిది.',
      },
    ],
    practiceQuestion: {
      question: 'Which material is transparent?',
      questionHi: 'कौन सी सामग्री पारदर्शी है?',
      questionTe: 'ఏ పదార్థం పారదర్శకం?',
      options: ['Wood', 'Glass', 'Metal', 'Stone'],
      optionsHi: ['लकड़ी', 'कांच', 'धातु', 'पत्थर'],
      optionsTe: ['కలప', 'గాజు', 'లోహం', 'రాయి'],
      correctAnswer: 1,
    },
  },

  // 5. Separation of Substances
  {
    id: 'science-separation',
    subjectId: 'science',
    title: 'Separation of Substances',
    titleHi: 'पदार्थों का पृथक्करण',
    titleTe: 'పదార్థాల వేరుచేయడం',
    content: 'Methods: handpicking, winnowing, sieving, filtration.\n\nDifferent methods for different mixtures.\n\nWe separate to get pure substances.',
    contentHi: 'विधियाँ: हाथ से चुनना, फटकना, छानना, निस्यंदन।\n\nअलग-अलग मिश्रणों के लिए अलग-अलग विधियाँ।\n\nहम शुद्ध पदार्थ प्राप्त करने के लिए अलग करते हैं।',
    contentTe: 'పద్ధతులు: చేతితో ఏరడం, వెదజల్లడం, జల్లించడం, వడపోత.\n\nవేర్వేరు మిశ్రమాలకు వేర్వేరు పద్ధతులు.\n\nశుద్ధ పదార్థాలు పొందడానికి మేము వేరు చేస్తాము.',
    examples: [
      {
        title: 'Winnowing',
        titleHi: 'फटकना',
        titleTe: 'వెదజల్లడం',
        emoji: '🌾',
        content: 'Winnowing separates husk from grain.\n\nWind blows away the light husk.\n\nHeavy grains fall down.',
        contentHi: 'फटकने से भूसा अनाज से अलग होता है।\n\nहवा हल्के भूसे को उड़ा देती है।\n\nभारी दाने नीचे गिरते हैं।',
        contentTe: 'వెదజల్లడం పొట్టును ధాన్యం నుండి వేరు చేస్తుంది.\n\nగాలి తేలికైన పొట్టును ఎగరేస్తుంది.\n\nబరువైన గింజలు కింద పడతాయి.',
      },
      {
        title: 'Filtration',
        titleHi: 'छानना',
        titleTe: 'వడపోత',
        emoji: '💧',
        content: 'Used to separate sand from water.\n\nWater passes through filter.\n\nSand stays behind.',
        contentHi: 'रेत को पानी से अलग करने के लिए उपयोग।\n\nपानी फ़िल्टर से गुज़रता है।\n\nरेत पीछे रह जाती है।',
        contentTe: 'ఇసుకను నీటి నుండి వేరు చేయడానికి ఉపయోగిస్తారు.\n\nనీరు ఫిల్టర్ గుండా వెళ్తుంది.\n\nఇసుక వెనుక ఉంటుంది.',
      },
    ],
    practiceQuestion: {
      question: 'Which method separates husk from grain?',
      questionHi: 'कौन सी विधि भूसे को अनाज से अलग करती है?',
      questionTe: 'ఏ పద్ధతి పొట్టును ధాన్యం నుండి వేరు చేస్తుంది?',
      options: ['Filtration', 'Winnowing', 'Handpicking', 'Sieving'],
      optionsHi: ['निस्यंदन', 'फटकना', 'हाथ से चुनना', 'छानना'],
      optionsTe: ['వడపోత', 'వెదజల్లడం', 'చేతితో ఏరడం', 'జల్లించడం'],
      correctAnswer: 1,
    },
  },

  // 6. Changes Around Us
  {
    id: 'science-changes',
    subjectId: 'science',
    title: 'Changes Around Us',
    titleHi: 'हमारे आसपास के परिवर्तन',
    titleTe: 'మన చుట్టూ మార్పులు',
    content: 'Some changes are reversible (can go back).\n\nSome changes are irreversible (cannot go back).\n\nChanges happen around us every day.',
    contentHi: 'कुछ परिवर्तन उत्क्रमणीय हैं (वापस जा सकते हैं)।\n\nकुछ परिवर्तन अनुत्क्रमणीय हैं (वापस नहीं जा सकते)।\n\nहमारे आसपास हर दिन परिवर्तन होते हैं।',
    contentTe: 'కొన్ని మార్పులు రివర్సిబుల్ (తిరిగి వెళ్ళవచ్చు).\n\nకొన్ని మార్పులు ఇర్రివర్సిబుల్ (తిరిగి వెళ్ళలేము).\n\nమన చుట్టూ ప్రతిరోజు మార్పులు జరుగుతాయి.',
    examples: [
      {
        title: 'Reversible Change',
        titleHi: 'उत्क्रमणीय परिवर्तन',
        titleTe: 'రివర్సిబుల్ మార్పు',
        emoji: '🧊',
        content: 'Melting ice → Water → Ice again.\n\nThis change can be reversed.\n\nWe can get ice back!',
        contentHi: 'बर्फ पिघलना → पानी → फिर बर्फ।\n\nयह परिवर्तन उलटा जा सकता है।\n\nहम बर्फ वापस पा सकते हैं!',
        contentTe: 'మంచు కరగడం → నీరు → మళ్ళీ మంచు.\n\nఈ మార్పు తిరిగి వెళ్ళవచ్చు.\n\nమనం మంచు తిరిగి పొందవచ్చు!',
      },
      {
        title: 'Irreversible Change',
        titleHi: 'अनुत्क्रमणीय परिवर्तन',
        titleTe: 'ఇర్రివర్సిబుల్ మార్పు',
        emoji: '🔥',
        content: 'Burning paper → Ash.\n\nWe cannot get paper back from ash.\n\nThis change cannot be reversed.',
        contentHi: 'कागज जलाना → राख।\n\nहम राख से कागज वापस नहीं पा सकते।\n\nयह परिवर्तन उलटा नहीं जा सकता।',
        contentTe: 'కాగితం కాల్చడం → బూడిద.\n\nబూడిద నుండి కాగితం తిరిగి పొందలేము.\n\nఈ మార్పు తిరిగి వెళ్ళదు.',
      },
    ],
    practiceQuestion: {
      question: 'Which is a reversible change?',
      questionHi: 'कौन सा उत्क्रमणीय परिवर्तन है?',
      questionTe: 'ఏది రివర్సిబుల్ మార్పు?',
      options: ['Burning wood', 'Melting ice', 'Cooking egg', 'Cutting paper'],
      optionsHi: ['लकड़ी जलाना', 'बर्फ पिघलना', 'अंडा पकाना', 'कागज काटना'],
      optionsTe: ['కట్టెలు కాల్చడం', 'మంచు కరగడం', 'గుడ్డు వండటం', 'కాగితం కత్తిరించడం'],
      correctAnswer: 1,
    },
  },

  // 7. Getting to Know Plants
  {
    id: 'science-plants-1',
    subjectId: 'science',
    title: 'Getting to Know Plants',
    titleHi: 'पौधों को जानना',
    titleTe: 'మొక్కలను తెలుసుకోవడం',
    content: 'A plant has different parts. Each part does a special job.\n\nThe main parts are: Root, Stem, Leaf, Flower, and Fruit.\n\nPhotosynthesis makes food in leaves.',
    contentHi: 'एक पौधे के अलग-अलग भाग होते हैं। हर भाग एक खास काम करता है।\n\nमुख्य भाग हैं: जड़, तना, पत्ती, फूल और फल।\n\nप्रकाश संश्लेषण पत्तियों में भोजन बनाता है।',
    contentTe: 'మొక్కకు వివిధ భాగాలు ఉంటాయి. ప్రతి భాగం ఒక ప్రత్యేక పని చేస్తుంది.\n\nప్రధాన భాగాలు: వేరు, కాండం, ఆకు, పువ్వు మరియు పండు.\n\nకిరణజన్య సంయోగక్రియ ఆకులలో ఆహారం తయారు చేస్తుంది.',
    examples: [
      {
        title: 'Root',
        titleHi: 'जड़',
        titleTe: 'వేరు',
        emoji: '🌱',
        content: 'The root is under the ground.\n\nIt drinks water from the soil.\n\nIt holds the plant in place.',
        contentHi: 'जड़ ज़मीन के नीचे होती है।\n\nयह मिट्टी से पानी पीती है।\n\nयह पौधे को जगह पर रखती है।',
        contentTe: 'వేరు నేల క్రింద ఉంటుంది.\n\nఇది నేల నుండి నీటిని తాగుతుంది.\n\nఇది మొక్కను స్థిరంగా ఉంచుతుంది.',
      },
      {
        title: 'Leaf',
        titleHi: 'पत्ती',
        titleTe: 'ఆకు',
        emoji: '🍃',
        content: 'Leaves make food for the plant.\n\nThey use sunlight, water, and air.\n\nThis is called photosynthesis.',
        contentHi: 'पत्तियाँ पौधे के लिए भोजन बनाती हैं।\n\nवे सूरज की रोशनी, पानी और हवा का उपयोग करती हैं।\n\nइसे प्रकाश संश्लेषण कहते हैं।',
        contentTe: 'ఆకులు మొక్కకు ఆహారం తయారు చేస్తాయి.\n\nవి సూర్యరశ్మి, నీరు మరియు గాలిని ఉపయోగిస్తాయి.\n\nదీనిని కిరణజన్య సంయోగక్రియ అంటారు.',
      },
    ],
    practiceQuestion: {
      question: 'Which part of the plant makes food?',
      questionHi: 'पौधे का कौन सा भाग भोजन बनाता है?',
      questionTe: 'మొక్క యొక్క ఏ భాగం ఆహారం తయారు చేస్తుంది?',
      options: ['Root', 'Stem', 'Leaf', 'Flower'],
      optionsHi: ['जड़', 'तना', 'पत्ती', 'फूल'],
      optionsTe: ['వేరు', 'కాండం', 'ఆకు', 'పువ్వు'],
      correctAnswer: 2,
    },
  },

  // 8. Body Movements
  {
    id: 'science-body-movements',
    subjectId: 'science',
    title: 'Body Movements',
    titleHi: 'शरीर की गतियाँ',
    titleTe: 'శరీర కదలికలు',
    content: 'Bones and muscles help movement.\n\nSkeleton gives shape and support.\n\nJoints connect bones and allow movement.',
    contentHi: 'हड्डियाँ और मांसपेशियाँ गति में मदद करती हैं।\n\nकंकाल आकार और सहारा देता है।\n\nजोड़ हड्डियों को जोड़ते हैं और गति देते हैं।',
    contentTe: 'ఎముకలు మరియు కండరాలు కదలికలో సహాయపడతాయి.\n\nఅస్థిపంజరం ఆకారం మరియు మద్దతు ఇస్తుంది.\n\nకీళ్ళు ఎముకలను కలుపుతాయి మరియు కదలికను అనుమతిస్తాయి.',
    examples: [
      {
        title: 'Hinge Joint',
        titleHi: 'कब्जा जोड़',
        titleTe: 'కీలు కీలు',
        emoji: '🦵',
        content: 'Knee and elbow are hinge joints.\n\nThey move in one direction only.\n\nLike a door hinge!',
        contentHi: 'घुटना और कोहनी कब्जा जोड़ हैं।\n\nये केवल एक दिशा में चलते हैं।\n\nदरवाजे की कब्जा की तरह!',
        contentTe: 'మోకాలు మరియు మోచేయి హింజ్ జాయింట్లు.\n\nఇవి ఒక దిశలో మాత్రమే కదులుతాయి.\n\nతలుపు హింజ్ లాగా!',
      },
      {
        title: 'Ball & Socket Joint',
        titleHi: 'गेंद और सॉकेट जोड़',
        titleTe: 'బాల్ & సాకెట్ కీలు',
        emoji: '💪',
        content: 'Shoulder and hip are ball & socket joints.\n\nThey can move in all directions.\n\nGives more freedom of movement!',
        contentHi: 'कंधा और कूल्हा गेंद और सॉकेट जोड़ हैं।\n\nये सभी दिशाओं में चल सकते हैं।\n\nज्यादा गति की स्वतंत्रता देते हैं!',
        contentTe: 'భుజం మరియు తుంటి బాల్ & సాకెట్ కీళ్ళు.\n\nఇవి అన్ని దిశలలో కదులుతాయి.\n\nఎక్కువ కదలిక స్వేచ్ఛను ఇస్తాయి!',
      },
    ],
    practiceQuestion: {
      question: 'Which joint allows movement in all directions?',
      questionHi: 'कौन सा जोड़ सभी दिशाओं में गति देता है?',
      questionTe: 'ఏ కీలు అన్ని దిశలలో కదలికను అనుమతిస్తుంది?',
      options: ['Hinge joint', 'Ball and socket joint', 'Fixed joint', 'Pivot joint'],
      optionsHi: ['कब्जा जोड़', 'गेंद और सॉकेट जोड़', 'स्थिर जोड़', 'धुरी जोड़'],
      optionsTe: ['హింజ్ కీలు', 'బాల్ అండ్ సాకెట్ కీలు', 'స్థిర కీలు', 'పివట్ కీలు'],
      correctAnswer: 1,
    },
  },

  // 9. Living and Non-Living Things
  {
    id: 'science-living-nonliving',
    subjectId: 'science',
    title: 'Living and Non-Living Things',
    titleHi: 'सजीव और निर्जीव वस्तुएं',
    titleTe: 'జీవులు మరియు నిర్జీవులు',
    content: 'Living things grow, breathe, reproduce.\n\nNon-living things do not have life.\n\nAll living things need food, water, and air.',
    contentHi: 'सजीव चीज़ें बढ़ती हैं, साँस लेती हैं, प्रजनन करती हैं।\n\nनिर्जीव चीज़ों में जीवन नहीं होता।\n\nसभी सजीवों को भोजन, पानी और हवा की ज़रूरत होती है।',
    contentTe: 'జీవులు పెరుగుతాయి, శ్వాసిస్తాయి, పునరుత్పత్తి చేస్తాయి.\n\nనిర్జీవులకు జీవం ఉండదు.\n\nఅన్ని జీవులకు ఆహారం, నీరు మరియు గాలి అవసరం.',
    examples: [
      {
        title: 'Living Things',
        titleHi: 'सजीव',
        titleTe: 'జీవులు',
        emoji: '🌳',
        content: 'Plants, animals, humans, birds, insects.\n\nThey eat, grow, move (or not), and reproduce.',
        contentHi: 'पौधे, जानवर, मनुष्य, पक्षी, कीड़े।\n\nये खाते हैं, बढ़ते हैं, चलते हैं (या नहीं), और प्रजनन करते हैं।',
        contentTe: 'మొక్కలు, జంతువులు, మానవులు, పక్షులు, కీటకాలు.\n\nవి తింటాయి, పెరుగుతాయి, కదులుతాయి (లేదా కాదు), మరియు పునరుత్పత్తి చేస్తాయి.',
      },
      {
        title: 'Non-Living Things',
        titleHi: 'निर्जीव',
        titleTe: 'నిర్జీవులు',
        emoji: '🪨',
        content: 'Rocks, water, chair, book, car.\n\nThey do not eat, grow, or breathe.',
        contentHi: 'पत्थर, पानी, कुर्सी, किताब, कार।\n\nये न खाते हैं, न बढ़ते हैं, न साँस लेते हैं।',
        contentTe: 'రాళ్ళు, నీరు, కుర్చీ, పుస్తకం, కారు.\n\nఇవి తినవు, పెరగవు, శ్వాసించవు.',
      },
    ],
    practiceQuestion: {
      question: 'Which is a characteristic of living things?',
      questionHi: 'सजीव वस्तुओं की विशेषता क्या है?',
      questionTe: 'జీవుల లక్షణం ఏమిటి?',
      options: ['They are made of metal', 'They grow and breathe', 'They never change', 'They cannot move'],
      optionsHi: ['ये धातु से बने हैं', 'ये बढ़ते और साँस लेते हैं', 'ये कभी नहीं बदलते', 'ये हिल नहीं सकते'],
      optionsTe: ['ఇవి లోహంతో తయారు', 'ఇవి పెరుగుతాయి మరియు శ్వాసిస్తాయి', 'ఇవి ఎప్పుడూ మారవు', 'ఇవి కదలలేవు'],
      correctAnswer: 1,
    },
  },

  // 10. Motion and Measurement
  {
    id: 'science-motion',
    subjectId: 'science',
    title: 'Motion and Measurement',
    titleHi: 'गति और माप',
    titleTe: 'గమనం మరియు కొలత',
    content: 'Motion means change in position.\n\nUnits: metre (length), kilogram (mass), second (time).\n\nWe measure to compare things.',
    contentHi: 'गति का अर्थ है स्थिति में बदलाव।\n\nइकाइयाँ: मीटर (लंबाई), किलोग्राम (द्रव्यमान), सेकंड (समय)।\n\nहम चीज़ों की तुलना के लिए मापते हैं।',
    contentTe: 'గమనం అంటే స్థానంలో మార్పు.\n\nయూనిట్లు: మీటర్ (పొడవు), కిలోగ్రామ్ (ద్రవ్యరాశి), సెకను (సమయం).\n\nవస్తువులను పోల్చడానికి మేము కొలుస్తాము.',
    examples: [
      {
        title: 'Types of Motion',
        titleHi: 'गति के प्रकार',
        titleTe: 'గమన రకాలు',
        emoji: '🚗',
        content: 'Rectilinear: straight line (car on road)\n\nCircular: round path (merry-go-round)\n\nPeriodic: repeating (swing, pendulum)',
        contentHi: 'रेखीय: सीधी रेखा (सड़क पर कार)\n\nवृत्तीय: गोल पथ (झूला)\n\nआवर्ती: दोहराव (झूला, पेंडुलम)',
        contentTe: 'రేఖీయ: సరళ రేఖ (రోడ్డుపై కారు)\n\nవృత్తాకార: వృత్తాకార మార్గం (మెర్రీ-గో-రౌండ్)\n\nఆవర్తన: పునరావృత్తం (ఊయల, లోలకం)',
      },
      {
        title: 'Standard Units',
        titleHi: 'मानक इकाइयाँ',
        titleTe: 'ప్రామాణిక యూనిట్లు',
        emoji: '📏',
        content: 'Length: metre (m)\n\nMass: kilogram (kg)\n\nTime: second (s)',
        contentHi: 'लंबाई: मीटर (मी)\n\nद्रव्यमान: किलोग्राम (किग्रा)\n\nसमय: सेकंड (से)',
        contentTe: 'పొడవు: మీటర్ (మీ)\n\nద్రవ్యరాశి: కిలోగ్రామ్ (కి.గ్రా)\n\nసమయం: సెకను (సె)',
      },
    ],
    practiceQuestion: {
      question: 'What is the SI unit of length?',
      questionHi: 'लंबाई की SI इकाई क्या है?',
      questionTe: 'పొడవు యొక్క SI యూనిట్ ఏమిటి?',
      options: ['Kilometre', 'Metre', 'Centimetre', 'Foot'],
      optionsHi: ['किलोमीटर', 'मीटर', 'सेंटीमीटर', 'फुट'],
      optionsTe: ['కిలోమీటర్', 'మీటర్', 'సెంటీమీటర్', 'అడుగు'],
      correctAnswer: 1,
    },
  },

  // 11. Light, Shadows and Reflections
  {
    id: 'science-light',
    subjectId: 'science',
    title: 'Light, Shadows and Reflections',
    titleHi: 'प्रकाश, छाया और प्रतिबिंब',
    titleTe: 'కాంతి, నీడలు మరియు ప్రతిబింబాలు',
    content: 'Light helps us see things.\n\nShadow forms when light is blocked.\n\nReflection: light bounces back from surfaces.',
    contentHi: 'प्रकाश हमें चीज़ें देखने में मदद करता है।\n\nजब प्रकाश रुकता है तो छाया बनती है।\n\nप्रतिबिंब: प्रकाश सतहों से वापस उछलता है।',
    contentTe: 'కాంతి వస్తువులను చూడటానికి సహాయపడుతుంది.\n\nకాంతి అడ్డుపడినప్పుడు నీడ ఏర్పడుతుంది.\n\nప్రతిబింబం: కాంతి ఉపరితలాల నుండి తిరిగి బౌన్స్ అవుతుంది.',
    examples: [
      {
        title: 'Shadow',
        titleHi: 'छाया',
        titleTe: 'నీడ',
        emoji: '🌑',
        content: 'Stand in sunlight.\n\nYour body blocks light.\n\nA dark shadow forms behind you!',
        contentHi: 'धूप में खड़े हो जाओ।\n\nआपका शरीर प्रकाश को रोकता है।\n\nआपके पीछे एक अंधेरी छाया बनती है!',
        contentTe: 'సూర్యకాంతిలో నిలబడండి.\n\nమీ శరీరం కాంతిని అడ్డుకుంటుంది.\n\nమీ వెనుక చీకటి నీడ ఏర్పడుతుంది!',
      },
      {
        title: 'Mirror Reflection',
        titleHi: 'दर्पण प्रतिबिंब',
        titleTe: 'అద్దం ప్రతిబింబం',
        emoji: '🪞',
        content: 'When you look in a mirror,\n\nyou see your reflection.\n\nLight bounces back to your eyes.',
        contentHi: 'जब आप दर्पण में देखते हैं,\n\nआप अपना प्रतिबिंब देखते हैं।\n\nप्रकाश आपकी आँखों में वापस आता है।',
        contentTe: 'మీరు అద్దంలో చూసినప్పుడు,\n\nమీరు మీ ప్రతిబింబాన్ని చూస్తారు.\n\nకాంతి మీ కళ్ళకు తిరిగి బౌన్స్ అవుతుంది.',
      },
    ],
    practiceQuestion: {
      question: 'What is needed to form a shadow?',
      questionHi: 'छाया बनने के लिए क्या चाहिए?',
      questionTe: 'నీడ ఏర్పడటానికి ఏమి అవసరం?',
      options: ['Water', 'Light source', 'Only dark room', 'Wind'],
      optionsHi: ['पानी', 'प्रकाश स्रोत', 'केवल अंधेरा कमरा', 'हवा'],
      optionsTe: ['నీరు', 'కాంతి మూలం', 'చీకటి గది మాత్రమే', 'గాలి'],
      correctAnswer: 1,
    },
  },

  // 12. Electricity and Circuits
  {
    id: 'science-electricity',
    subjectId: 'science',
    title: 'Electricity and Circuits',
    titleHi: 'विद्युत और परिपथ',
    titleTe: 'విద్యుత్ మరియు సర్క్యూట్లు',
    content: 'Electric current flows in a closed circuit.\n\nSwitch controls the flow of electricity.\n\nOpen circuit = no current flows.',
    contentHi: 'विद्युत धारा बंद परिपथ में बहती है।\n\nस्विच विद्युत के प्रवाह को नियंत्रित करता है।\n\nखुला परिपथ = धारा नहीं बहती।',
    contentTe: 'విద్యుత్ ప్రవాహం మూసిన సర్క్యూట్‌లో ప్రవహిస్తుంది.\n\nస్విచ్ విద్యుత్ ప్రవాహాన్ని నియంత్రిస్తుంది.\n\nఓపెన్ సర్క్యూట్ = ప్రవాహం లేదు.',
    examples: [
      {
        title: 'Simple Circuit',
        titleHi: 'सरल परिपथ',
        titleTe: 'సరళ సర్క్యూట్',
        emoji: '💡',
        content: 'Battery + Wire + Bulb = Simple circuit.\n\nWhen connected, bulb glows!\n\nBreak the wire, bulb stops.',
        contentHi: 'बैटरी + तार + बल्ब = सरल परिपथ।\n\nजुड़ने पर बल्ब जलता है!\n\nतार तोड़ो, बल्ब बंद।',
        contentTe: 'బ్యాటరీ + వైర్ + బల్బ్ = సరళ సర్క్యూట్.\n\nకనెక్ట్ చేసినప్పుడు, బల్బ్ వెలుగుతుంది!\n\nవైర్ తెంచండి, బల్బ్ ఆగిపోతుంది.',
      },
      {
        title: 'Conductors & Insulators',
        titleHi: 'चालक और कुचालक',
        titleTe: 'వాహకాలు & అవాహకాలు',
        emoji: '🔌',
        content: 'Conductors: allow current (metal, water).\n\nInsulators: block current (rubber, plastic).',
        contentHi: 'चालक: धारा को जाने देते हैं (धातु, पानी)।\n\nकुचालक: धारा को रोकते हैं (रबड़, प्लास्टिक)।',
        contentTe: 'వాహకాలు: ప్రవాహాన్ని అనుమతిస్తాయి (లోహం, నీరు).\n\nఅవాహకాలు: ప్రవాహాన్ని అడ్డుకుంటాయి (రబ్బరు, ప్లాస్టిక్).',
      },
    ],
    practiceQuestion: {
      question: 'In which circuit does the bulb glow?',
      questionHi: 'किस परिपथ में बल्ब जलता है?',
      questionTe: 'ఏ సర్క్యూట్‌లో బల్బ్ వెలుగుతుంది?',
      options: ['Open circuit', 'Closed circuit', 'No battery', 'Broken wire'],
      optionsHi: ['खुला परिपथ', 'बंद परिपथ', 'बिना बैटरी', 'टूटा तार'],
      optionsTe: ['ఓపెన్ సర్క్యూట్', 'క్లోజ్డ్ సర్క్యూట్', 'బ్యాటరీ లేకుండా', 'తెగిన వైర్'],
      correctAnswer: 1,
    },
  },

  // 13. Fun with Magnets
  {
    id: 'science-magnets',
    subjectId: 'science',
    title: 'Fun with Magnets',
    titleHi: 'चुंबकों के साथ मज़ा',
    titleTe: 'అయస్కాంతాలతో సరదా',
    content: 'Magnets attract iron and steel.\n\nEvery magnet has two poles: North and South.\n\nLike poles repel, unlike poles attract.',
    contentHi: 'चुंबक लोहे और इस्पात को आकर्षित करते हैं।\n\nहर चुंबक के दो ध्रुव होते हैं: उत्तर और दक्षिण।\n\nसमान ध्रुव प्रतिकर्षित, असमान आकर्षित।',
    contentTe: 'అయస్కాంతాలు ఇనుము మరియు స్టీల్‌ను ఆకర్షిస్తాయి.\n\nప్రతి అయస్కాంతానికి రెండు ధ్రువాలు: ఉత్తర మరియు దక్షిణ.\n\nసమాన ధ్రువాలు వికర్షిస్తాయి, అసమాన ధ్రువాలు ఆకర్షిస్తాయి.',
    examples: [
      {
        title: 'Magnetic Materials',
        titleHi: 'चुंबकीय पदार्थ',
        titleTe: 'అయస్కాంత పదార్థాలు',
        emoji: '🧲',
        content: 'Iron, nickel, cobalt are magnetic.\n\nWood, plastic, paper are non-magnetic.',
        contentHi: 'लोहा, निकल, कोबाल्ट चुंबकीय हैं।\n\nलकड़ी, प्लास्टिक, कागज गैर-चुंबकीय हैं।',
        contentTe: 'ఇనుము, నికెల్, కోబాల్ట్ అయస్కాంతకాలు.\n\nకలప, ప్లాస్టిక్, కాగితం అయస్కాంతేతరాలు.',
      },
      {
        title: 'Compass',
        titleHi: 'कम्पास',
        titleTe: 'కంపాస్',
        emoji: '🧭',
        content: 'A compass needle is a small magnet.\n\nIt always points North-South.\n\nHelps us find direction!',
        contentHi: 'कम्पास की सुई एक छोटा चुंबक है।\n\nयह हमेशा उत्तर-दक्षिण दिखाती है।\n\nदिशा खोजने में मदद करता है!',
        contentTe: 'కంపాస్ సూది చిన్న అయస్కాంతం.\n\nఇది ఎల్లప్పుడూ ఉత్తర-దక్షిణాన్ని చూపిస్తుంది.\n\nదిశను కనుగొనడంలో సహాయపడుతుంది!',
      },
    ],
    practiceQuestion: {
      question: 'What happens when two North poles come close?',
      questionHi: 'जब दो उत्तर ध्रुव पास आते हैं तो क्या होता है?',
      questionTe: 'రెండు ఉత్తర ధ్రువాలు దగ్గరికి వచ్చినప్పుడు ఏమి జరుగుతుంది?',
      options: ['They attract', 'They repel', 'Nothing happens', 'They stick together'],
      optionsHi: ['वे आकर्षित होते हैं', 'वे प्रतिकर्षित होते हैं', 'कुछ नहीं होता', 'वे चिपक जाते हैं'],
      optionsTe: ['అవి ఆకర్షిస్తాయి', 'అవి వికర్షిస్తాయి', 'ఏమీ జరగదు', 'అవి అతుక్కుంటాయి'],
      correctAnswer: 1,
    },
  },

  // 14. Water
  {
    id: 'science-water',
    subjectId: 'science',
    title: 'Water',
    titleHi: 'पानी',
    titleTe: 'నీరు',
    content: 'Water is essential for all life.\n\nWater cycle: evaporation → condensation → rain.\n\nWe must save water!',
    contentHi: 'पानी सभी जीवन के लिए आवश्यक है।\n\nजल चक्र: वाष्पीकरण → संघनन → बारिश।\n\nहमें पानी बचाना चाहिए!',
    contentTe: 'నీరు అన్ని జీవులకు అవసరం.\n\nజల చక్రం: బాష్పీభవనం → సంఘనీభవనం → వర్షం.\n\nమనం నీటిని ఆదా చేయాలి!',
    examples: [
      {
        title: 'Water Cycle',
        titleHi: 'जल चक्र',
        titleTe: 'జల చక్రం',
        emoji: '🌧️',
        content: 'Sun heats water → Water evaporates.\n\nVapor rises → Forms clouds.\n\nClouds cool → Rain falls!',
        contentHi: 'सूर्य पानी गर्म करता है → पानी भाप बनता है।\n\nभाप ऊपर जाती है → बादल बनते हैं।\n\nबादल ठंडे होते हैं → बारिश गिरती है!',
        contentTe: 'సూర్యుడు నీటిని వేడి చేస్తాడు → నీరు ఆవిరవుతుంది.\n\nఆవిరి పైకి వెళ్తుంది → మేఘాలు ఏర్పడతాయి.\n\nమేఘాలు చల్లబడతాయి → వర్షం పడుతుంది!',
      },
      {
        title: 'Save Water',
        titleHi: 'पानी बचाओ',
        titleTe: 'నీటిని ఆదా చేయండి',
        emoji: '💧',
        content: 'Turn off taps when not needed.\n\nFix leaky pipes.\n\nUse bucket instead of shower.',
        contentHi: 'जब जरूरत न हो तो नल बंद करें।\n\nटपकते पाइप ठीक करें।\n\nशावर की जगह बाल्टी उपयोग करें।',
        contentTe: 'అవసరం లేనప్పుడు కుళాయిలు మూసివేయండి.\n\nలీక్ అయ్యే పైపులను సరిచేయండి.\n\nషవర్ బదులు బకెట్ ఉపయోగించండి.',
      },
    ],
    practiceQuestion: {
      question: 'What is the process when water changes to vapor?',
      questionHi: 'जब पानी भाप में बदलता है तो इस प्रक्रिया को क्या कहते हैं?',
      questionTe: 'నీరు ఆవిరిగా మారినప్పుడు ఈ ప్రక్రియను ఏమంటారు?',
      options: ['Condensation', 'Evaporation', 'Freezing', 'Melting'],
      optionsHi: ['संघनन', 'वाष्पीकरण', 'जमना', 'पिघलना'],
      optionsTe: ['సంఘనీభవనం', 'బాష్పీభవనం', 'గడ్డకట్టడం', 'కరగడం'],
      correctAnswer: 1,
    },
  },

  // 15. Air Around Us
  {
    id: 'science-air',
    subjectId: 'science',
    title: 'Air Around Us',
    titleHi: 'हमारे आसपास की हवा',
    titleTe: 'మన చుట్టూ గాలి',
    content: 'Air contains oxygen, nitrogen, carbon dioxide.\n\nOxygen supports life and burning.\n\nAir is everywhere around us.',
    contentHi: 'हवा में ऑक्सीजन, नाइट्रोजन, कार्बन डाइऑक्साइड होते हैं।\n\nऑक्सीजन जीवन और जलने में मदद करती है।\n\nहवा हमारे चारों ओर है।',
    contentTe: 'గాలిలో ఆక్సిజన్, నైట్రోజన్, కార్బన్ డయాక్సైడ్ ఉంటాయి.\n\nఆక్సిజన్ జీవం మరియు కాల్చడానికి సహాయపడుతుంది.\n\nగాలి మన చుట్టూ ఎక్కడైనా ఉంటుంది.',
    examples: [
      {
        title: 'Composition of Air',
        titleHi: 'हवा की संरचना',
        titleTe: 'గాలి కూర్పు',
        emoji: '🌬️',
        content: 'Nitrogen: 78%\n\nOxygen: 21%\n\nOther gases (CO2, etc.): 1%',
        contentHi: 'नाइट्रोजन: 78%\n\nऑक्सीजन: 21%\n\nअन्य गैसें (CO2, आदि): 1%',
        contentTe: 'నైట్రోజన్: 78%\n\nఆక్సిజన్: 21%\n\nఇతర వాయువులు (CO2, మొదలైనవి): 1%',
      },
      {
        title: 'Oxygen Test',
        titleHi: 'ऑक्सीजन परीक्षण',
        titleTe: 'ఆక్సిజన్ పరీక్ష',
        emoji: '🕯️',
        content: 'A candle needs oxygen to burn.\n\nCover with glass → candle goes out.\n\nNo oxygen = no burning!',
        contentHi: 'मोमबत्ती को जलने के लिए ऑक्सीजन चाहिए।\n\nकांच से ढको → मोमबत्ती बुझ जाती है।\n\nऑक्सीजन नहीं = जलना नहीं!',
        contentTe: 'కొవ్వొత్తికి కాల్చడానికి ఆక్సిజన్ అవసరం.\n\nగాజుతో కప్పండి → కొవ్వొత్తి ఆరిపోతుంది.\n\nఆక్సిజన్ లేదు = కాల్చడం లేదు!',
      },
    ],
    practiceQuestion: {
      question: 'Which gas is most abundant in air?',
      questionHi: 'हवा में कौन सी गैस सबसे अधिक है?',
      questionTe: 'గాలిలో ఏ వాయువు అత్యధికంగా ఉంటుంది?',
      options: ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Hydrogen'],
      optionsHi: ['ऑक्सीजन', 'नाइट्रोजन', 'कार्बन डाइऑक्साइड', 'हाइड्रोजन'],
      optionsTe: ['ఆక్సిజన్', 'నైట్రోజన్', 'కార్బన్ డయాక్సైడ్', 'హైడ్రోజన్'],
      correctAnswer: 1,
    },
  },

  // 16. Garbage In, Garbage Out
  {
    id: 'science-garbage',
    subjectId: 'science',
    title: 'Garbage In, Garbage Out',
    titleHi: 'कचरा अंदर, कचरा बाहर',
    titleTe: 'చెత్త లోపల, చెత్త బయట',
    content: 'Waste should be managed properly.\n\nReduce, Reuse, Recycle (3Rs).\n\nBiodegradable waste can decompose naturally.',
    contentHi: 'कचरे का उचित प्रबंधन होना चाहिए।\n\nकम करो, पुन: उपयोग करो, पुनर्चक्रण करो (3Rs)।\n\nजैव-अपघटनीय कचरा प्राकृतिक रूप से सड़ सकता है।',
    contentTe: 'వ్యర్థాలను సరిగ్గా నిర్వహించాలి.\n\nతగ్గించండి, తిరిగి ఉపయోగించండి, రీసైకిల్ చేయండి (3Rs).\n\nజీవ-వియోజ్య వ్యర్థాలు సహజంగా కుళ్ళిపోతాయి.',
    examples: [
      {
        title: 'Biodegradable',
        titleHi: 'जैव-अपघटनीय',
        titleTe: 'జీవ-వియోజ్యం',
        emoji: '🥬',
        content: 'Vegetable peels, paper, leaves.\n\nThese rot and mix with soil.\n\nGood for making compost!',
        contentHi: 'सब्जियों के छिलके, कागज, पत्तियां।\n\nये सड़कर मिट्टी में मिल जाते हैं।\n\nखाद बनाने के लिए अच्छे!',
        contentTe: 'కూరగాయల తొక్కలు, కాగితం, ఆకులు.\n\nఇవి కుళ్ళి మట్టిలో కలుస్తాయి.\n\nకంపోస్ట్ తయారు చేయడానికి మంచివి!',
      },
      {
        title: 'Non-Biodegradable',
        titleHi: 'गैर-जैव-अपघटनीय',
        titleTe: 'జీవ-వియోజ్యం కాదు',
        emoji: '🥤',
        content: 'Plastic, glass, metal.\n\nThese do not rot easily.\n\nMust be recycled properly!',
        contentHi: 'प्लास्टिक, कांच, धातु।\n\nये आसानी से नहीं सड़ते।\n\nइनका पुनर्चक्रण ज़रूरी!',
        contentTe: 'ప్లాస్టిక్, గాజు, లోహం.\n\nఇవి సులభంగా కుళ్ళవు.\n\nసరిగ్గా రీసైకిల్ చేయాలి!',
      },
    ],
    practiceQuestion: {
      question: 'Which is biodegradable waste?',
      questionHi: 'कौन सा जैव-अपघटनीय कचरा है?',
      questionTe: 'ఏది జీవ-వియోజ్య వ్యర్థం?',
      options: ['Plastic bottle', 'Vegetable peels', 'Glass jar', 'Metal can'],
      optionsHi: ['प्लास्टिक बोतल', 'सब्जी के छिलके', 'कांच का जार', 'धातु का डब्बा'],
      optionsTe: ['ప్లాస్టిక్ సీసా', 'కూరగాయల తొక్కలు', 'గాజు జాడీ', 'లోహపు డబ్బా'],
      correctAnswer: 1,
    },
  },

  // ========================
  // SOCIAL STUDIES - AP SCERT Class 6
  // ========================

  // History - What is History
  {
    id: 'social-what-is-history',
    subjectId: 'social',
    title: 'What is History?',
    titleHi: 'इतिहास क्या है?',
    titleTe: 'చరిత్ర అంటే ఏమిటి?',
    content: 'History is the study of the past.\n\nWe learn about people, events, and changes.\n\nSources: books, monuments, coins, inscriptions.',
    contentHi: 'इतिहास अतीत का अध्ययन है।\n\nहम लोगों, घटनाओं और बदलावों के बारे में सीखते हैं।\n\nस्रोत: किताबें, स्मारक, सिक्के, शिलालेख।',
    contentTe: 'చరిత్ర అంటే గతం గురించి అధ్యయనం.\n\nమేము వ్యక్తులు, సంఘటనలు మరియు మార్పుల గురించి తెలుసుకుంటాము.\n\nమూలాలు: పుస్తకాలు, స్మారక చిహ్నాలు, నాణేలు, శిలాశాసనాలు.',
    examples: [
      {
        title: 'Sources of History',
        titleHi: 'इतिहास के स्रोत',
        titleTe: 'చరిత్ర మూలాలు',
        emoji: '📜',
        content: 'Written: Books, letters, inscriptions.\n\nArchaeological: Coins, pottery, monuments.\n\nOral: Stories passed down.',
        contentHi: 'लिखित: किताबें, पत्र, शिलालेख।\n\nपुरातात्विक: सिक्के, मिट्टी के बर्तन, स्मारक।\n\nमौखिक: पीढ़ियों से चली आ रही कहानियां।',
        contentTe: 'వ్రాతపూర్వక: పుస్తకాలు, ఉత్తరాలు, శిలాశాసనాలు.\n\nపురావస్తు: నాణేలు, కుండలు, స్మారక చిహ్నాలు.\n\nమౌఖిక: తరతరాలుగా వచ్చిన కథలు.',
      },
      {
        title: 'Why Study History?',
        titleHi: 'इतिहास क्यों पढ़ें?',
        titleTe: 'చరిత్ర ఎందుకు చదవాలి?',
        emoji: '🤔',
        content: 'Learn from the past.\n\nUnderstand our culture.\n\nKnow how our country developed.',
        contentHi: 'अतीत से सीखो।\n\nहमारी संस्कृति को समझो।\n\nजानो कैसे हमारा देश विकसित हुआ।',
        contentTe: 'గతం నుండి నేర్చుకోండి.\n\nమన సంస్కృతిని అర్థం చేసుకోండి.\n\nమన దేశం ఎలా అభివృద్ధి చెందిందో తెలుసుకోండి.',
      },
    ],
    practiceQuestion: {
      question: 'What is an archaeological source of history?',
      questionHi: 'इतिहास का पुरातात्विक स्रोत क्या है?',
      questionTe: 'చరిత్ర యొక్క పురావస్తు మూలం ఏమిటి?',
      options: ['Storybooks', 'Coins and monuments', 'Newspapers', 'Television'],
      optionsHi: ['कहानी की किताबें', 'सिक्के और स्मारक', 'समाचार पत्र', 'टेलीविजन'],
      optionsTe: ['కథల పుస్తకాలు', 'నాణేలు మరియు స్మారక చిహ్నాలు', 'వార్తాపత్రికలు', 'టెలివిజన్'],
      correctAnswer: 1,
    },
  },

  // Geography - Globe and Maps
  {
    id: 'social-globe-maps',
    subjectId: 'social',
    title: 'Globe and Maps',
    titleHi: 'ग्लोब और मानचित्र',
    titleTe: 'భూగోళం మరియు మ్యాప్‌లు',
    content: 'Globe is a model of Earth.\n\nMaps show Earth on flat paper.\n\nLatitude and longitude help locate places.',
    contentHi: 'ग्लोब पृथ्वी का एक मॉडल है।\n\nमानचित्र पृथ्वी को समतल कागज पर दिखाते हैं।\n\nअक्षांश और देशांतर स्थानों को खोजने में मदद करते हैं।',
    contentTe: 'భూగోళం భూమి యొక్క నమూనా.\n\nమ్యాప్‌లు భూమిని చదునైన కాగితంపై చూపిస్తాయి.\n\nఅక్షాంశం మరియు రేఖాంశం ప్రదేశాలను గుర్తించడంలో సహాయపడతాయి.',
    examples: [
      {
        title: 'Globe',
        titleHi: 'ग्लोब',
        titleTe: 'భూగోళం',
        emoji: '🌍',
        content: 'Globe is round like Earth.\n\nIt shows continents and oceans.\n\nWe can spin it to see all sides.',
        contentHi: 'ग्लोब पृथ्वी की तरह गोल है।\n\nयह महाद्वीप और महासागर दिखाता है।\n\nहम इसे घुमाकर सभी तरफ देख सकते हैं।',
        contentTe: 'భూగోళం భూమి లాగా గుండ్రంగా ఉంటుంది.\n\nఇది ఖండాలు మరియు మహాసముద్రాలను చూపిస్తుంది.\n\nమేము దానిని తిప్పి అన్ని వైపులా చూడవచ్చు.',
      },
      {
        title: 'Types of Maps',
        titleHi: 'मानचित्रों के प्रकार',
        titleTe: 'మ్యాప్ రకాలు',
        emoji: '🗺️',
        content: 'Political map: shows countries, states.\n\nPhysical map: shows mountains, rivers.\n\nRoad map: shows roads and cities.',
        contentHi: 'राजनीतिक मानचित्र: देश, राज्य दिखाता है।\n\nभौतिक मानचित्र: पहाड़, नदियां दिखाता है।\n\nसड़क मानचित्र: सड़कें और शहर दिखाता है।',
        contentTe: 'రాజకీయ మ్యాప్: దేశాలు, రాష్ట్రాలను చూపిస్తుంది.\n\nభౌతిక మ్యాప్: పర్వతాలు, నదులను చూపిస్తుంది.\n\nరోడ్ మ్యాప్: రోడ్లు మరియు నగరాలను చూపిస్తుంది.',
      },
    ],
    practiceQuestion: {
      question: 'What does a political map show?',
      questionHi: 'राजनीतिक मानचित्र क्या दिखाता है?',
      questionTe: 'రాజకీయ మ్యాప్ ఏమి చూపిస్తుంది?',
      options: ['Mountains and rivers', 'Countries and states', 'Weather', 'Roads only'],
      optionsHi: ['पहाड़ और नदियां', 'देश और राज्य', 'मौसम', 'केवल सड़कें'],
      optionsTe: ['పర్వతాలు మరియు నదులు', 'దేశాలు మరియు రాష్ట్రాలు', 'వాతావరణం', 'రోడ్లు మాత్రమే'],
      correctAnswer: 1,
    },
  },

  // Civics - Diversity
  {
    id: 'social-diversity',
    subjectId: 'social',
    title: 'Diversity of India',
    titleHi: 'भारत की विविधता',
    titleTe: 'భారతదేశ వైవిధ్యం',
    content: 'India has many languages, religions, and cultures.\n\nDiversity makes India unique and beautiful.\n\nUnity in diversity is our strength.',
    contentHi: 'भारत में कई भाषाएं, धर्म और संस्कृतियां हैं।\n\nविविधता भारत को अनोखा और सुंदर बनाती है।\n\nविविधता में एकता हमारी ताकत है।',
    contentTe: 'భారతదేశంలో అనేక భాషలు, మతాలు మరియు సంస్కృతులు ఉన్నాయి.\n\nవైవిధ్యం భారతదేశాన్ని ప్రత్యేకంగా మరియు అందంగా చేస్తుంది.\n\nవైవిధ్యంలో ఐక్యత మన బలం.',
    examples: [
      {
        title: 'Languages',
        titleHi: 'भाषाएं',
        titleTe: 'భాషలు',
        emoji: '🗣️',
        content: 'India has 22 official languages!\n\nHindi, Telugu, Tamil, Bengali...\n\nEach state has its own language.',
        contentHi: 'भारत में 22 आधिकारिक भाषाएं हैं!\n\nहिंदी, तेलुगु, तमिल, बंगाली...\n\nहर राज्य की अपनी भाषा है।',
        contentTe: 'భారతదేశంలో 22 అధికారిక భాషలు ఉన్నాయి!\n\nహిందీ, తెలుగు, తమిళం, బెంగాలీ...\n\nప్రతి రాష్ట్రానికి దాని స్వంత భాష ఉంది.',
      },
      {
        title: 'Festivals',
        titleHi: 'त्योहार',
        titleTe: 'పండుగలు',
        emoji: '🎉',
        content: 'Diwali, Eid, Christmas, Pongal, Holi...\n\nDifferent religions, same happiness!\n\nWe celebrate together.',
        contentHi: 'दिवाली, ईद, क्रिसमस, पोंगल, होली...\n\nअलग-अलग धर्म, एक जैसी खुशी!\n\nहम साथ मिलकर मनाते हैं।',
        contentTe: 'దీపావళి, ఈద్, క్రిస్మస్, పొంగల్, హోలీ...\n\nవేర్వేరు మతాలు, ఒకే సంతోషం!\n\nమేము కలిసి జరుపుకుంటాము.',
      },
    ],
    practiceQuestion: {
      question: 'How many official languages does India have?',
      questionHi: 'भारत में कितनी आधिकारिक भाषाएं हैं?',
      questionTe: 'భారతదేశంలో ఎన్ని అధికారిక భాషలు ఉన్నాయి?',
      options: ['10', '15', '22', '30'],
      optionsHi: ['10', '15', '22', '30'],
      optionsTe: ['10', '15', '22', '30'],
      correctAnswer: 2,
    },
  },

  // ========================
  // ENGLISH - Grammar Lessons
  // ========================

  {
    id: 'english-grammar-1',
    subjectId: 'english',
    title: 'What is a Noun?',
    titleHi: 'संज्ञा क्या है?',
    titleTe: 'నామవాచకం అంటే ఏమిటి?',
    content: 'A noun is a naming word.\n\nIt is the name of a person, place, animal, or thing.',
    contentHi: 'संज्ञा एक नाम बताने वाला शब्द है।\n\nयह किसी व्यक्ति, स्थान, जानवर या वस्तु का नाम होता है।',
    contentTe: 'నామవాచకం అంటే పేరు చెప్పే పదం.\n\nఇది వ్యక్తి, ప్రదేశం, జంతువు లేదా వస్తువు పేరు.',
    examples: [
      {
        title: 'Person Names',
        titleHi: 'व्यक्ति के नाम',
        titleTe: 'వ్యక్తుల పేర్లు',
        emoji: '👦',
        content: 'Rahul, Priya, Teacher, Doctor\n\nThese are all nouns because they name people.',
        contentHi: 'राहुल, प्रिया, शिक्षक, डॉक्टर\n\nये सब संज्ञा हैं क्योंकि ये लोगों के नाम हैं।',
        contentTe: 'రాహుల్, ప్రియ, టీచర్, డాక్టర్\n\nఇవన్నీ నామవాచకాలు ఎందుకంటే ఇవి వ్యక్తుల పేర్లు.',
      },
      {
        title: 'Things & Places',
        titleHi: 'वस्तुएं और स्थान',
        titleTe: 'వస్తువులు & ప్రదేశాలు',
        emoji: '🏫',
        content: 'Book, School, Village, River\n\nThese are nouns too!',
        contentHi: 'किताब, स्कूल, गाँव, नदी\n\nये भी संज्ञा हैं!',
        contentTe: 'పుస్తకం, పాఠశాల, గ్రామం, నది\n\nఇవి కూడా నామవాచకాలే!',
      },
    ],
    practiceQuestion: {
      question: 'Which of these is a noun?',
      questionHi: 'इनमें से कौन सी संज्ञा है?',
      questionTe: 'వీటిలో నామవాచకం ఏది?',
      options: ['Run', 'Beautiful', 'Mango', 'Quickly'],
      optionsHi: ['दौड़ना', 'सुंदर', 'आम', 'जल्दी से'],
      optionsTe: ['పరుగెత్తడం', 'అందమైన', 'మామిడి', 'త్వరగా'],
      correctAnswer: 2,
    },
  },

  {
    id: 'english-grammar-2',
    subjectId: 'english',
    title: 'What is a Verb?',
    titleHi: 'क्रिया क्या है?',
    titleTe: 'క్రియ అంటే ఏమిటి?',
    content: 'A verb is an action word.\n\nIt tells us what someone or something is doing.',
    contentHi: 'क्रिया एक काम बताने वाला शब्द है।\n\nयह बताता है कि कोई क्या कर रहा है।',
    contentTe: 'క్రియ అంటే చర్య చెప్పే పదం.\n\nఇది ఎవరైనా లేదా ఏదైనా ఏమి చేస్తుందో చెబుతుంది.',
    examples: [
      {
        title: 'Action Verbs',
        titleHi: 'क्रिया शब्द',
        titleTe: 'క్రియ పదాలు',
        emoji: '🏃',
        content: 'Run, Jump, Eat, Sleep, Read, Write\n\nThese are all verbs!',
        contentHi: 'दौड़ना, कूदना, खाना, सोना, पढ़ना, लिखना\n\nये सब क्रिया हैं!',
        contentTe: 'పరుగెత్తడం, దూకడం, తినడం, నిద్రపోవడం, చదవడం, వ్రాయడం\n\nఇవన్నీ క్రియలు!',
      },
      {
        title: 'Examples in Sentences',
        titleHi: 'वाक्यों में उदाहरण',
        titleTe: 'వాక్యాలలో ఉదాహరణలు',
        emoji: '✍️',
        content: 'The bird flies.\n\nRahul reads a book.\n\nThe dog runs fast.',
        contentHi: 'पक्षी उड़ता है।\n\nराहुल किताब पढ़ता है।\n\nकुत्ता तेज़ दौड़ता है।',
        contentTe: 'పక్షి ఎగురుతుంది.\n\nరాహుల్ పుస్తకం చదువుతాడు.\n\nకుక్క వేగంగా పరుగెత్తుతుంది.',
      },
    ],
    practiceQuestion: {
      question: 'Which of these is a verb?',
      questionHi: 'इनमें से कौन सी क्रिया है?',
      questionTe: 'వీటిలో క్రియ ఏది?',
      options: ['Table', 'Beautiful', 'Write', 'Happy'],
      optionsHi: ['मेज़', 'सुंदर', 'लिखना', 'खुश'],
      optionsTe: ['బల్ల', 'అందమైన', 'వ్రాయడం', 'సంతోషం'],
      correctAnswer: 2,
    },
  },

  // ========================
  // HINDI - Language Lessons
  // ========================

  {
    id: 'hindi-varnamala',
    subjectId: 'hindi',
    title: 'हिंदी वर्णमाला',
    titleHi: 'हिंदी वर्णमाला',
    titleTe: 'హిందీ వర్ణమాల',
    content: 'हिंदी वर्णमाला में स्वर और व्यंजन होते हैं।\n\nस्वर: अ, आ, इ, ई...\n\nव्यंजन: क, ख, ग, घ...',
    contentHi: 'हिंदी वर्णमाला में स्वर और व्यंजन होते हैं।\n\nस्वर: अ, आ, इ, ई...\n\nव्यंजन: क, ख, ग, घ...',
    contentTe: 'హిందీ వర్ణమాలలో అచ్చులు మరియు హల్లులు ఉంటాయి.\n\nఅచ్చులు: అ, ఆ, ఇ, ఈ...\n\nహల్లులు: క, ఖ, గ, ఘ...',
    examples: [
      {
        title: 'स्वर (Vowels)',
        titleHi: 'स्वर',
        titleTe: 'అచ్చులు',
        emoji: '🔤',
        content: 'अ आ इ ई उ ऊ ए ऐ ओ औ अं अः\n\nTotal: 13 स्वर',
        contentHi: 'अ आ इ ई उ ऊ ए ऐ ओ औ अं अः\n\nकुल: 13 स्वर',
        contentTe: 'అ ఆ ఇ ఈ ఉ ఊ ఏ ఐ ఓ ఔ అం అః\n\nమొత్తం: 13 అచ్చులు',
      },
      {
        title: 'व्यंजन (Consonants)',
        titleHi: 'व्यंजन',
        titleTe: 'హల్లులు',
        emoji: '📝',
        content: 'क ख ग घ ङ\n\nच छ ज झ ञ\n\nAnd many more!',
        contentHi: 'क ख ग घ ङ\n\nच छ ज झ ञ\n\nऔर भी बहुत!',
        contentTe: 'క ఖ గ ఘ ఙ\n\nచ ఛ జ ఝ ఞ\n\nమరియు చాలా ఇంకా!',
      },
    ],
    practiceQuestion: {
      question: 'हिंदी वर्णमाला में कितने स्वर हैं?',
      questionHi: 'हिंदी वर्णमाला में कितने स्वर हैं?',
      questionTe: 'హిందీ వర్ణమాలలో ఎన్ని అచ్చులు ఉన్నాయి?',
      options: ['10', '11', '13', '15'],
      optionsHi: ['10', '11', '13', '15'],
      optionsTe: ['10', '11', '13', '15'],
      correctAnswer: 2,
    },
  },

  {
    id: 'hindi-paryayvachi',
    subjectId: 'hindi',
    title: 'पर्यायवाची शब्द',
    titleHi: 'पर्यायवाची शब्द',
    titleTe: 'పర్యాయపదాలు',
    content: 'पर्यायवाची शब्द वे शब्द हैं जिनका अर्थ समान होता है।\n\nइन्हें समानार्थी शब्द भी कहते हैं।',
    contentHi: 'पर्यायवाची शब्द वे शब्द हैं जिनका अर्थ समान होता है।\n\nइन्हें समानार्थी शब्द भी कहते हैं।',
    contentTe: 'పర్యాయపదాలు అంటే ఒకే అర్థం ఉన్న పదాలు.\n\nవీటిని సమానార్థక పదాలు అని కూడా అంటారు.',
    examples: [
      {
        title: 'सूर्य के पर्यायवाची',
        titleHi: 'सूर्य के पर्यायवाची',
        titleTe: 'సూర్య పర్యాయపదాలు',
        emoji: '☀️',
        content: 'सूर्य = रवि, भानु, दिनकर, आदित्य\n\nAll mean Sun!',
        contentHi: 'सूर्य = रवि, भानु, दिनकर, आदित्य\n\nसब का अर्थ सूरज है!',
        contentTe: 'సూర్య = రవి, భాను, దినకర్, ఆదిత్య\n\nఅన్నీ సూర్యుడు అని అర్థం!',
      },
      {
        title: 'जल के पर्यायवाची',
        titleHi: 'जल के पर्यायवाची',
        titleTe: 'నీటి పర్యాయపదాలు',
        emoji: '💧',
        content: 'जल = पानी, नीर, वारि, तोय\n\nAll mean Water!',
        contentHi: 'जल = पानी, नीर, वारि, तोय\n\nसब का अर्थ पानी है!',
        contentTe: 'జల = పానీ, నీర్, వారి, తోయ\n\nఅన్నీ నీరు అని అర్థం!',
      },
    ],
    practiceQuestion: {
      question: '"सूर्य" का पर्यायवाची शब्द क्या है?',
      questionHi: '"सूर्य" का पर्यायवाची शब्द क्या है?',
      questionTe: '"సూర్య" యొక్క పర్యాయపదం ఏమిటి?',
      options: ['चंद्र', 'रवि', 'तारा', 'आकाश'],
      optionsHi: ['चंद्र', 'रवि', 'तारा', 'आकाश'],
      optionsTe: ['చంద్ర', 'రవి', 'తార', 'ఆకాశ'],
      correctAnswer: 1,
    },
  },
];

export const getLessonsBySubject = (subjectId: string): Lesson[] => {
  return lessons.filter(lesson => lesson.subjectId === subjectId);
};

export const getLesson = (lessonId: string): Lesson | undefined => {
  return lessons.find(lesson => lesson.id === lessonId);
};
