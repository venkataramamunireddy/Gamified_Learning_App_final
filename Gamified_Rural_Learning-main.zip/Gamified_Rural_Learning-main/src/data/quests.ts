export interface Quest {
  id: string;
  title: string;
  titleHi: string;
  titleTe: string;
  description: string;
  descriptionHi: string;
  descriptionTe: string;
  icon: string;
  xpReward: number;
  target: number;
  type: 'daily' | 'weekly';
  category: 'lessons' | 'quizzes' | 'streak' | 'battles' | 'practice';
}

export const quests: Quest[] = [
  // Daily Quests
  {
    id: 'daily-lessons',
    title: 'Complete 2 Training Sessions',
    titleHi: '2 ट्रेनिंग सेशन पूरे करें',
    titleTe: '2 శిక్షణ సెషన్లు పూర్తి చేయండి',
    description: 'A Hunter must train every day!',
    descriptionHi: 'एक हंटर को हर दिन ट्रेनिंग करनी चाहिए!',
    descriptionTe: 'హంటర్ ప్రతిరోజూ శిక్షణ పొందాలి!',
    icon: '⚔️',
    xpReward: 30,
    target: 2,
    type: 'daily',
    category: 'lessons'
  },
  {
    id: 'daily-quiz',
    title: 'Clear 1 Dungeon',
    titleHi: '1 डंजन क्लियर करें',
    titleTe: '1 డంజియన్ క్లియర్ చేయండి',
    description: 'Test your power in the dungeon!',
    descriptionHi: 'डंजन में अपनी शक्ति परखें!',
    descriptionTe: 'డంజియన్‌లో మీ శక్తిని పరీక్షించండి!',
    icon: '🏰',
    xpReward: 20,
    target: 1,
    type: 'daily',
    category: 'quizzes'
  },
  {
    id: 'daily-practice',
    title: 'Practice 5 Skills',
    titleHi: '5 स्किल्स का अभ्यास करें',
    titleTe: '5 నైపుణ్యాలు ప్రాక్టీస్ చేయండి',
    description: 'Sharpen your abilities!',
    descriptionHi: 'अपनी क्षमताओं को तेज़ करें!',
    descriptionTe: 'మీ సామర్థ్యాలను పదును పెట్టండి!',
    icon: '✨',
    xpReward: 15,
    target: 5,
    type: 'daily',
    category: 'practice'
  },
  // Weekly Quests
  {
    id: 'weekly-lessons',
    title: 'Complete 10 Training Sessions',
    titleHi: '10 ट्रेनिंग सेशन पूरे करें',
    titleTe: '10 శిక్షణ సెషన్లు పూర్తి చేయండి',
    description: 'Become a training champion!',
    descriptionHi: 'ट्रेनिंग चैंपियन बनें!',
    descriptionTe: 'శిక్షణ ఛాంపియన్ అవ్వండి!',
    icon: '🏆',
    xpReward: 100,
    target: 10,
    type: 'weekly',
    category: 'lessons'
  },
  {
    id: 'weekly-streak',
    title: '7 Day Training Streak',
    titleHi: '7 दिन की ट्रेनिंग स्ट्रीक',
    titleTe: '7 రోజుల శిక్షణ స్ట్రీక్',
    description: 'Train every day for a week!',
    descriptionHi: 'एक हफ्ते तक रोज़ ट्रेनिंग करें!',
    descriptionTe: 'వారం రోజులు ప్రతిరోజూ శిక్షణ పొందండి!',
    icon: '🔥',
    xpReward: 150,
    target: 7,
    type: 'weekly',
    category: 'streak'
  },
  {
    id: 'weekly-battles',
    title: 'Win 3 Battles',
    titleHi: '3 बैटल जीतें',
    titleTe: '3 యుద్ధాలు గెలవండి',
    description: 'Prove your strength!',
    descriptionHi: 'अपनी ताकत साबित करें!',
    descriptionTe: 'మీ బలాన్ని నిరూపించండి!',
    icon: '⚔️',
    xpReward: 120,
    target: 3,
    type: 'weekly',
    category: 'battles'
  },
  {
    id: 'weekly-mastery',
    title: 'Score 80%+ in 5 Dungeons',
    titleHi: '5 डंजन में 80%+ स्कोर करें',
    titleTe: '5 డంజియన్లలో 80%+ స్కోర్ చేయండి',
    description: 'Show your mastery!',
    descriptionHi: 'अपनी महारत दिखाएं!',
    descriptionTe: 'మీ నైపుణ్యం చూపించండి!',
    icon: '🎯',
    xpReward: 80,
    target: 5,
    type: 'weekly',
    category: 'quizzes'
  }
];

export const battleModes = [
  {
    id: 'solo',
    title: 'Solo Hunt',
    titleHi: 'सोलो हंट',
    titleTe: 'సోలో హంట్',
    subtitle: '1 vs Monster',
    subtitleHi: '1 vs राक्षस',
    subtitleTe: '1 vs రాక్షసుడు',
    description: 'Face the dungeon alone!',
    descriptionHi: 'अकेले डंजन का सामना करें!',
    descriptionTe: 'ఒంటరిగా డంజియన్‌ను ఎదుర్కోండి!',
    icon: '⚔️',
    xpReward: 50,
    duration: '2 min',
    color: 'bg-blue-600'
  },
  {
    id: 'team',
    title: 'Raid Party',
    titleHi: 'रेड पार्टी',
    titleTe: 'రైడ్ పార్టీ',
    subtitle: 'Team up',
    subtitleHi: 'टीम बनाएं',
    subtitleTe: 'జట్టుగా',
    description: 'Team up with other Hunters!',
    descriptionHi: 'दूसरे हंटर्स के साथ टीम बनाएं!',
    descriptionTe: 'ఇతర హంటర్లతో జట్టు కట్టండి!',
    icon: '👥',
    xpReward: 100,
    duration: '5 min',
    color: 'bg-green-600'
  },
  {
    id: 'boss',
    title: 'Boss Raid',
    titleHi: 'बॉस रेड',
    titleTe: 'బాస్ రైడ్',
    subtitle: 'S-Rank Dungeon',
    subtitleHi: 'एस-रैंक डंजन',
    subtitleTe: 'S-ర్యాంక్ డంజియన్',
    description: 'Challenge the dungeon boss for massive rewards!',
    descriptionHi: 'बड़े इनाम के लिए डंजन बॉस को चुनौती दें!',
    descriptionTe: 'భారీ బహుమతుల కోసం డంజియన్ బాస్‌ను సవాలు చేయండి!',
    icon: '👑',
    xpReward: 200,
    duration: '5-10 min',
    color: 'bg-purple-600'
  }
];
