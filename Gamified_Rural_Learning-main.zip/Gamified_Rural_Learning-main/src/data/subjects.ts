export interface Subject {
  id: string;
  name: string;
  nameHi: string;
  nameTe: string;
  icon: string;
  gradient: string;
  progress: number;
  lessons: number;
}

export const subjects: Subject[] = [
  {
    id: 'math',
    name: 'Mathematics',
    nameHi: 'गणित',
    nameTe: 'గణితం',
    icon: '🔢',
    gradient: 'gradient-math',
    progress: 65,
    lessons: 24,
  },
  {
    id: 'science',
    name: 'Science',
    nameHi: 'विज्ञान',
    nameTe: 'విజ్ఞానం',
    icon: '🔬',
    gradient: 'gradient-science',
    progress: 42,
    lessons: 18,
  },
  {
    id: 'english',
    name: 'English',
    nameHi: 'अंग्रेज़ी',
    nameTe: 'ఆంగ్లం',
    icon: '📖',
    gradient: 'gradient-english',
    progress: 78,
    lessons: 20,
  },
  {
    id: 'social',
    name: 'Social Studies',
    nameHi: 'सामाजिक विज्ञान',
    nameTe: 'సామాజిక శాస్త్రం',
    icon: '🌍',
    gradient: 'gradient-social',
    progress: 35,
    lessons: 16,
  },
  {
    id: 'hindi',
    name: 'Hindi',
    nameHi: 'हिंदी',
    nameTe: 'హిందీ',
    icon: '📝',
    gradient: 'gradient-hindi',
    progress: 55,
    lessons: 22,
  },
];
