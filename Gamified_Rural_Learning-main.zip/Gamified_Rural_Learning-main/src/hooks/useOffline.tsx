import { useState, useEffect, useCallback } from 'react';

interface SyncStatus {
  lastSynced: Date | null;
  isSyncing: boolean;
  pendingChanges: number;
}

export const useOffline = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    lastSynced: null,
    isSyncing: false,
    pendingChanges: 0,
  });

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // Trigger sync when coming back online
      syncData();
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const syncData = useCallback(async () => {
    if (!navigator.onLine) return;

    setSyncStatus(prev => ({ ...prev, isSyncing: true }));

    try {
      // Simulate sync delay (replace with actual sync logic when backend is connected)
      await new Promise(resolve => setTimeout(resolve, 1000));

      setSyncStatus({
        lastSynced: new Date(),
        isSyncing: false,
        pendingChanges: 0,
      });

      // Store sync timestamp
      localStorage.setItem('rurallearn-last-sync', new Date().toISOString());
    } catch (error) {
      console.error('Sync failed:', error);
      setSyncStatus(prev => ({ ...prev, isSyncing: false }));
    }
  }, []);

  const addPendingChange = useCallback(() => {
    setSyncStatus(prev => ({
      ...prev,
      pendingChanges: prev.pendingChanges + 1,
    }));
  }, []);

  return {
    isOnline,
    syncStatus,
    syncData,
    addPendingChange,
  };
};
