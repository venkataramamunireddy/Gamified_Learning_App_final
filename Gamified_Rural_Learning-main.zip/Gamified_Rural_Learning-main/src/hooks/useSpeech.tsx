import { useState, useCallback, useEffect, useRef } from 'react';
import { useLang } from '../context/LanguageContext';
import { toast } from 'sonner';

interface UseSpeechReturn {
  speak: (text: string) => void;
  stop: () => void;
  isSpeaking: boolean;
  isSupported: boolean;
  hasVoiceForLanguage: boolean;
}

export const useSpeech = (): UseSpeechReturn => {
  const { lang } = useLang();
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [hasVoiceForLanguage, setHasVoiceForLanguage] = useState(true);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Get the appropriate language code for Web Speech API
  const getLanguageCode = useCallback(() => {
    switch (lang) {
      case 'hi':
        return 'hi-IN';
      case 'te':
        return 'te-IN';
      default:
        return 'en-IN';
    }
  }, [lang]);

  // Check if voice is available for the current language
  const checkVoiceAvailability = useCallback(() => {
    if (!('speechSynthesis' in window)) return false;
    
    const voices = window.speechSynthesis.getVoices();
    const langCode = getLanguageCode();
    const langPrefix = lang === 'te' ? 'te' : lang === 'hi' ? 'hi' : 'en';
    
    // Check for exact match or language prefix match
    const hasVoice = voices.some(voice => 
      voice.lang === langCode || 
      voice.lang.startsWith(langPrefix)
    );
    
    return hasVoice;
  }, [getLanguageCode, lang]);

  useEffect(() => {
    const supported = 'speechSynthesis' in window;
    setIsSupported(supported);
    
    if (supported) {
      // Voices may load asynchronously
      const updateVoices = () => {
        const hasVoice = checkVoiceAvailability();
        setHasVoiceForLanguage(hasVoice);
      };
      
      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
      
      return () => {
        window.speechSynthesis.onvoiceschanged = null;
      };
    }
  }, [checkVoiceAvailability]);

  // Re-check voice availability when language changes
  useEffect(() => {
    if (isSupported) {
      const hasVoice = checkVoiceAvailability();
      setHasVoiceForLanguage(hasVoice);
    }
  }, [lang, isSupported, checkVoiceAvailability]);

  const speak = useCallback((text: string) => {
    if (!isSupported) return;

    // Check voice availability before speaking
    const hasVoice = checkVoiceAvailability();
    if (!hasVoice) {
      const langName = lang === 'te' ? 'Telugu' : lang === 'hi' ? 'Hindi' : 'English';
      toast.error(`${langName} voice not available on this device. Try using Chrome or install language packs.`);
      return;
    }

    // Stop any current speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    const langCode = getLanguageCode();
    
    // Try to find a specific voice for the language
    const voices = window.speechSynthesis.getVoices();
    const langPrefix = lang === 'te' ? 'te' : lang === 'hi' ? 'hi' : 'en';
    const preferredVoice = voices.find(voice => 
      voice.lang === langCode || voice.lang.startsWith(langPrefix)
    );
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    utterance.lang = langCode;
    utterance.rate = 0.85;
    utterance.pitch = 1.1;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = (event) => {
      setIsSpeaking(false);
      if (event.error !== 'canceled') {
        toast.error('Speech playback failed. Please try again.');
      }
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [isSupported, getLanguageCode, lang, checkVoiceAvailability]);

  const stop = useCallback(() => {
    if (!isSupported) return;
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, [isSupported]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  return { speak, stop, isSpeaking, isSupported, hasVoiceForLanguage };
};
