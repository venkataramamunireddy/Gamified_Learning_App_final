import { useState, useEffect, useCallback } from "react";
import { subjects, Subject } from "../data/subjects";
import { getLessonsBySubject } from "../data/lessons";

const STORAGE_KEY = 'rurallearn-completed-lessons';

export interface SubjectWithProgress extends Subject {
  progress: number;
  completedCount: number;
  totalLessons: number;
}

export const useSubjectProgress = () => {
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? new Set(JSON.parse(saved)) : new Set();
  });

  // Listen for storage changes (cross-component sync)
  useEffect(() => {
    const handleStorage = () => {
      const saved = localStorage.getItem(STORAGE_KEY);
      setCompletedLessons(saved ? new Set(JSON.parse(saved)) : new Set());
    };

    window.addEventListener('storage', handleStorage);
    
    // Also poll for same-tab changes
    const interval = setInterval(handleStorage, 1000);
    
    return () => {
      window.removeEventListener('storage', handleStorage);
      clearInterval(interval);
    };
  }, []);

  const subjectsWithProgress: SubjectWithProgress[] = subjects.map(subject => {
    const lessons = getLessonsBySubject(subject.id);
    const totalLessons = lessons.length;
    const completedCount = lessons.filter(l => completedLessons.has(l.id)).length;
    const progress = totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;
    
    return {
      ...subject,
      progress,
      completedCount,
      totalLessons,
    };
  });

  const markLessonComplete = useCallback((lessonId: string) => {
    setCompletedLessons(prev => {
      const next = new Set([...prev, lessonId]);
      localStorage.setItem(STORAGE_KEY, JSON.stringify([...next]));
      return next;
    });
  }, []);

  const isLessonCompleted = useCallback((lessonId: string) => {
    return completedLessons.has(lessonId);
  }, [completedLessons]);

  return { subjectsWithProgress, completedLessons, markLessonComplete, isLessonCompleted };
};
