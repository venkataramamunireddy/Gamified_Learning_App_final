import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { badges } from "../data/badges";
import { Lock } from "lucide-react";

export const BadgesPage = () => {
  const { t, lang } = useLang();
  const { student } = useStudent();
  
  // Dynamically unlock badges based on student progress
  const unlockedBadges = badges.map(badge => {
    let isUnlocked = badge.unlocked;
    
    // Rank badges
    if (badge.id === 'rank_d') isUnlocked = student.level >= 10;
    if (badge.id === 'rank_c') isUnlocked = student.level >= 20;
    if (badge.id === 'rank_b') isUnlocked = student.level >= 30;
    if (badge.id === 'rank_a') isUnlocked = student.level >= 40;
    if (badge.id === 'rank_s') isUnlocked = student.level >= 50;
    
    // Streak badges
    if (badge.id === 'streak3') isUnlocked = student.streak >= 3;
    if (badge.id === 'streak7') isUnlocked = student.streak >= 7;
    if (badge.id === 'streak30') isUnlocked = student.streak >= 30;
    
    // Battle badges
    if (badge.id === 'first_battle') isUnlocked = student.battlesWon >= 1;
    if (badge.id === 'battle_10') isUnlocked = student.battlesWon >= 10;
    
    return { ...badge, unlocked: isUnlocked };
  });

  const unlockedCount = unlockedBadges.filter(b => b.unlocked).length;
  
  const categories = [
    { id: 'rank', label: t('Rank Badges', 'रैंक बैज', 'ర్యాంక్ బ్యాడ్జ్‌లు'), icon: '👑' },
    { id: 'streak', label: t('Streak Badges', 'स्ट्रीक बैज', 'స్ట్రీక్ బ్యాడ్జ్‌లు'), icon: '🔥' },
    { id: 'battle', label: t('Battle Badges', 'बैटल बैज', 'యుద్ధ బ్యాడ్జ్‌లు'), icon: '⚔️' },
    { id: 'quest', label: t('Quest Badges', 'क्वेस्ट बैज', 'క్వెస్ట్ బ్యాడ్జ్‌లు'), icon: '📜' },
    { id: 'special', label: t('Special Badges', 'विशेष बैज', 'ప్రత్యేక బ్యాడ్జ్‌లు'), icon: '✨' },
  ];

  return (
    <div className="pb-24 px-4 pt-4">
      <div className="mb-6">
        <h2 className="text-2xl font-extrabold text-foreground mb-2">
          {t('Hunter Badges', 'हंटर बैज', 'హంటర్ బ్యాడ్జ్‌లు')} 🏆
        </h2>
        <p className="text-muted-foreground">
          {unlockedCount}/{unlockedBadges.length} {t('unlocked', 'अनलॉक', 'అన్‌లాక్')}
        </p>
      </div>

      {categories.map(category => {
        const categoryBadges = unlockedBadges.filter(b => b.category === category.id);
        if (categoryBadges.length === 0) return null;

        return (
          <div key={category.id} className="mb-6">
            <h3 className="font-bold text-foreground mb-3 flex items-center gap-2">
              {category.icon} {category.label}
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {categoryBadges.map((badge, index) => (
                <div
                  key={badge.id}
                  className={`relative p-4 rounded-2xl text-center transition-all animate-slide-up ${
                    badge.unlocked ? 'bg-card shadow-card border-2 border-primary/20' : 'bg-muted/50 opacity-70'
                  }`}
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  {!badge.unlocked && (
                    <div className="absolute inset-0 flex items-center justify-center bg-background/50 rounded-2xl backdrop-blur-[1px]">
                      <Lock className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                  <div className={`text-3xl mb-2 ${badge.unlocked ? 'animate-bounce-gentle' : ''}`}>
                    {badge.icon}
                  </div>
                  <h3 className="font-bold text-foreground text-sm mb-1">
                    {lang === 'te' ? badge.titleTe : lang === 'hi' ? badge.titleHi : badge.title}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {lang === 'te' ? badge.descriptionTe : lang === 'hi' ? badge.descriptionHi : badge.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      <div className="gradient-hero text-primary-foreground p-6 rounded-3xl text-center">
        <div className="text-4xl mb-3">⚔️</div>
        <h3 className="font-bold text-lg mb-2">
          {t('Rise, Hunter!', 'उठो, हंटर!', 'లేవండి, హంటర్!')}
        </h3>
        <p className="text-primary-foreground/80 text-sm">
          {t(
            'Complete quests and win battles to unlock all badges',
            'सभी बैज अनलॉक करने के लिए क्वेस्ट पूरे करें और लड़ाई जीतें',
            'అన్ని బ్యాడ్జ్‌లను అన్‌లాక్ చేయడానికి క్వెస్ట్‌లు పూర్తి చేసి యుద్ధాలు గెలవండి'
          )}
        </p>
      </div>
    </div>
  );
};
