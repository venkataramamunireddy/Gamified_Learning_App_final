import { useState, useEffect, useCallback, useRef } from "react";
import { ArrowLeft, Clock, Zap, Crown, Users, Skull, Bot } from "lucide-react";
import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { battleModes } from "../data/quests";
import { getQuestionsBySubject } from "../data/questions";
import { subjects } from "../data/subjects";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import confetti from "canvas-confetti";

interface BattlePageProps {
  onBack: () => void;
}

type BattleView = 'menu' | 'subject-select' | 'battle' | 'result';

interface BattleState {
  mode: typeof battleModes[0] | null;
  subjectId: string | null;
  currentQuestion: number;
  playerScore: number;
  opponentScore: number;
  timeLeft: number;
  answered: boolean;
  selectedAnswer: number | null;
  isCorrect: boolean | null;
}

const AI_OPPONENTS = [
  { name: 'Shadow Monarch', nameHi: 'शैडो मोनार्क', nameTe: 'షాడో మోనార్క్', emoji: '👹', rank: 'A' },
  { name: 'Iron Golem', nameHi: 'आयरन गोलेम', nameTe: 'ఐరన్ గోలెమ్', emoji: '🗿', rank: 'B' },
  { name: 'Ice Elf', nameHi: 'आइस एल्फ', nameTe: 'ఐస్ ఎల్ఫ్', emoji: '🧝', rank: 'C' },
  { name: 'Flame Orc', nameHi: 'फ्लेम ऑर्क', nameTe: 'ఫ్లేమ్ ఆర్క్', emoji: '👺', rank: 'B' },
  { name: 'Cerberus', nameHi: 'सर्बेरस', nameTe: 'సెర్బెరస్', emoji: '🐺', rank: 'S' },
];

export const BattlePage = ({ onBack }: BattlePageProps) => {
  const { t, lang } = useLang();
  const { addXP, winBattle } = useStudent();
  const [view, setView] = useState<BattleView>('menu');
  const [selectedMode, setSelectedMode] = useState<typeof battleModes[0] | null>(null);
  const [aiOpponent, setAiOpponent] = useState(AI_OPPONENTS[0]);
  const [aiTaunt, setAiTaunt] = useState('');
  const [battle, setBattle] = useState<BattleState>({
    mode: null,
    subjectId: null,
    currentQuestion: 0,
    playerScore: 0,
    opponentScore: 0,
    timeLeft: 15,
    answered: false,
    selectedAnswer: null,
    isCorrect: null,
  });

  // Memoize questions so they don't reshuffle on every render
  const questionsRef = useRef<ReturnType<typeof getQuestionsBySubject>>([]);
  const [questions, setQuestions] = useState<ReturnType<typeof getQuestionsBySubject>>([]);
  const currentQ = questions[battle.currentQuestion];

  // Fetch AI taunt
  const fetchAiTaunt = useCallback(async () => {
    try {
      const subject = battle.subjectId ? subjects.find(s => s.id === battle.subjectId)?.name : 'General';
      const { data } = await supabase.functions.invoke('battle-ai', {
        body: {
          subject,
          difficulty: selectedMode?.id || 'solo',
          questionNumber: battle.currentQuestion + 1,
          totalQuestions: questions.length,
          playerScore: battle.playerScore,
          opponentScore: battle.opponentScore,
        },
      });
      if (data?.taunt) setAiTaunt(data.taunt);
    } catch {
      // Fallback taunts
      const fallbacks = [
        t("You dare challenge me, Hunter?", "तुम मुझे चुनौती देते हो, हंटर?", "నన్ను సవాలు చేస్తావా, హంటర్?"),
        t("I'll crush you!", "मैं तुम्हें कुचल दूंगा!", "నిన్ను నాశనం చేస్తా!"),
        t("Not bad... for a human.", "बुरा नहीं... एक इंसान के लिए।", "చెడ్డది కాదు... మానవుడికి."),
      ];
      setAiTaunt(fallbacks[Math.floor(Math.random() * fallbacks.length)]);
    }
  }, [battle.subjectId, battle.currentQuestion, battle.playerScore, battle.opponentScore, selectedMode, questions.length, t]);

  // Timer effect
  useEffect(() => {
    if (view !== 'battle' || battle.answered || battle.timeLeft <= 0) return;
    
    const timer = setInterval(() => {
      setBattle(prev => {
        if (prev.timeLeft <= 1) {
          const opponentScores = Math.random() > 0.5;
          return {
            ...prev,
            timeLeft: 0,
            answered: true,
            isCorrect: false,
            opponentScore: opponentScores ? prev.opponentScore + 1 : prev.opponentScore,
          };
        }
        return { ...prev, timeLeft: prev.timeLeft - 1 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [view, battle.answered, battle.timeLeft]);

  // Fetch taunt when battle starts or question changes
  useEffect(() => {
    if (view === 'battle' && currentQ) {
      fetchAiTaunt();
    }
  }, [view, battle.currentQuestion]);

  const handleModeSelect = (mode: typeof battleModes[0]) => {
    setSelectedMode(mode);
    setView('subject-select');
  };

  const handleSubjectSelect = (subjectId: string) => {
    const opponent = AI_OPPONENTS[Math.floor(Math.random() * AI_OPPONENTS.length)];
    setAiOpponent(opponent);
    const generatedQuestions = getQuestionsBySubject(subjectId, 5);
    questionsRef.current = generatedQuestions;
    setQuestions(generatedQuestions);
    setBattle({
      mode: selectedMode,
      subjectId,
      currentQuestion: 0,
      playerScore: 0,
      opponentScore: 0,
      timeLeft: 15,
      answered: false,
      selectedAnswer: null,
      isCorrect: null,
    });
    setView('battle');
  };

  const handleAnswer = useCallback((answerIndex: number) => {
    if (battle.answered) return;

    const isCorrect = answerIndex === currentQ?.correctAnswer;
    // AI opponent difficulty: harder modes = smarter AI
    const aiAccuracy = selectedMode?.id === 'boss' ? 0.7 : selectedMode?.id === 'team' ? 0.5 : 0.4;
    const opponentScores = !isCorrect && Math.random() < aiAccuracy;

    setBattle(prev => ({
      ...prev,
      answered: true,
      selectedAnswer: answerIndex,
      isCorrect,
      playerScore: isCorrect ? prev.playerScore + 1 : prev.playerScore,
      opponentScore: opponentScores ? prev.opponentScore + 1 : prev.opponentScore,
    }));

    setTimeout(() => {
      if (battle.currentQuestion >= questions.length - 1) {
        const won = battle.playerScore + (isCorrect ? 1 : 0) > battle.opponentScore + (opponentScores ? 1 : 0);
        if (won) {
          confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
          addXP(selectedMode?.xpReward || 50);
          winBattle();
        }
        setView('result');
      } else {
        setBattle(prev => ({
          ...prev,
          currentQuestion: prev.currentQuestion + 1,
          timeLeft: 15,
          answered: false,
          selectedAnswer: null,
          isCorrect: null,
        }));
      }
    }, 1500);
  }, [battle, currentQ, questions.length, selectedMode, addXP, winBattle]);

  const getOpponentName = () => {
    if (lang === 'hi') return aiOpponent.nameHi;
    if (lang === 'te') return aiOpponent.nameTe;
    return aiOpponent.name;
  };

  const getModeTitle = (mode: typeof battleModes[0]) => {
    if (lang === 'te') return mode.titleTe;
    if (lang === 'hi') return mode.titleHi;
    return mode.title;
  };

  const getModeSubtitle = (mode: typeof battleModes[0]) => {
    if (lang === 'te') return mode.subtitleTe;
    if (lang === 'hi') return mode.subtitleHi;
    return mode.subtitle;
  };

  const getModeDescription = (mode: typeof battleModes[0]) => {
    if (lang === 'te') return mode.descriptionTe;
    if (lang === 'hi') return mode.descriptionHi;
    return mode.description;
  };

  const getModeIcon = (id: string) => {
    switch (id) {
      case 'solo': return <Skull className="w-6 h-6" />;
      case 'team': return <Users className="w-6 h-6" />;
      case 'boss': return <Crown className="w-6 h-6" />;
      default: return <Zap className="w-6 h-6" />;
    }
  };

  // Subject Selection
  if (view === 'subject-select') {
    return (
      <div className="pb-24">
        <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
          <div className="flex items-center gap-3 px-4 py-3">
            <button onClick={() => setView('menu')} className="p-2 rounded-xl hover:bg-muted transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h2 className="font-bold text-lg">{t('Choose Dungeon', 'डंजन चुनें', 'డంజియన్ ఎంచుకోండి')}</h2>
          </div>
        </div>
        <div className="p-4 space-y-3">
          {subjects.map(subject => (
            <button
              key={subject.id}
              onClick={() => handleSubjectSelect(subject.id)}
              className="w-full flex items-center gap-4 p-4 system-window neon-border hover:border-primary/60 transition-all"
            >
              <span className="text-3xl">{subject.icon}</span>
              <span className="font-bold text-foreground">
                {lang === 'te' ? subject.nameTe : lang === 'hi' ? subject.nameHi : subject.name}
              </span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Battle Screen
  if (view === 'battle' && currentQ) {
    const questionText = lang === 'te' ? currentQ.questionTe : lang === 'hi' ? currentQ.questionHi : currentQ.question;

    return (
      <div className="min-h-screen bg-background">
        {/* VS Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-card/50">
          <div className="flex items-center gap-2">
            <span className="text-2xl">⚔️</span>
            <div>
              <p className="text-xs text-muted-foreground">{t('You', 'आप', 'మీరు')}</p>
              <p className="text-lg font-bold text-accent">{battle.playerScore}</p>
            </div>
          </div>
          <div className="text-center">
            <p className="text-xs text-primary font-bold uppercase neon-text">VS</p>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span className={`font-bold ${battle.timeLeft <= 5 ? 'text-destructive animate-pulse' : ''}`}>{battle.timeLeft}s</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-right">
              <p className="text-xs text-muted-foreground flex items-center gap-1 justify-end">
                <Bot className="w-3 h-3" /> {getOpponentName()}
              </p>
              <p className="text-lg font-bold text-destructive">{battle.opponentScore}</p>
            </div>
            <span className="text-2xl">{aiOpponent.emoji}</span>
          </div>
        </div>

        {/* AI Taunt */}
        {aiTaunt && (
          <div className="mx-4 mt-3 p-3 bg-destructive/10 border border-destructive/30 rounded-lg">
            <p className="text-sm text-foreground italic flex items-center gap-2">
              <span>{aiOpponent.emoji}</span>
              <span>"{aiTaunt}"</span>
            </p>
          </div>
        )}

        {/* Progress */}
        <div className="px-4 py-3">
          <p className="text-sm text-muted-foreground mb-2">
            {t('Question', 'प्रश्न', 'ప్రశ్న')} {battle.currentQuestion + 1}/{questions.length}
          </p>
          <Progress value={((battle.currentQuestion + 1) / questions.length) * 100} className="h-2" />
        </div>

        {/* Question */}
        <div className="p-4">
          <div className="system-window neon-border p-6 mb-6">
            <p className="text-xl font-bold text-foreground text-center">{questionText}</p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQ.options.map((option, index) => {
              const optionText = lang === 'te' ? currentQ.optionsTe[index] : 
                                lang === 'hi' ? currentQ.optionsHi[index] : option;
              const isSelected = battle.selectedAnswer === index;
              const isCorrectAnswer = index === currentQ.correctAnswer;
              
              let bgClass = 'system-window neon-border hover:border-primary/60';
              if (battle.answered) {
                if (isCorrectAnswer) bgClass = 'bg-accent/20 border-2 border-accent';
                else if (isSelected && !battle.isCorrect) bgClass = 'bg-destructive/20 border-2 border-destructive';
              }

              return (
                <button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  disabled={battle.answered}
                  className={`w-full p-4 rounded-lg text-left font-medium transition-all ${bgClass}`}
                >
                  {optionText}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Result Screen
  if (view === 'result') {
    const won = battle.playerScore > battle.opponentScore;
    const tied = battle.playerScore === battle.opponentScore;

    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
        <div className="text-center system-window neon-border p-8 max-w-sm w-full">
          <div className="text-6xl mb-4">{won ? '🏆' : tied ? '🤝' : '💀'}</div>
          <h2 className="text-3xl font-extrabold text-foreground mb-2 neon-text">
            {won ? t('Victory!', 'जीत!', 'విజయం!') : 
             tied ? t('Draw!', 'ड्रॉ!', 'డ్రా!') : 
             t('Defeat', 'हार', 'ఓటమి')}
          </h2>
          <p className="text-muted-foreground mb-1">
            vs {getOpponentName()} {aiOpponent.emoji}
          </p>
          <p className="text-lg text-foreground font-bold mb-4">
            {battle.playerScore} - {battle.opponentScore}
          </p>
          {won && (
            <p className="text-accent font-bold text-lg mb-6">
              +{selectedMode?.xpReward || 50} XP ⚡
            </p>
          )}
          <button
            onClick={() => {
              setView('menu');
              setSelectedMode(null);
              setAiTaunt('');
            }}
            className="w-full px-8 py-3 bg-primary text-primary-foreground rounded-lg font-bold shadow-button hover:opacity-90 transition-all"
          >
            {t('Back to Arena', 'अखाड़े में वापस', 'అరీనాకు తిరిగి')}
          </button>
        </div>
      </div>
    );
  }

  // Menu
  return (
    <div className="pb-24">
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={onBack} className="p-2 rounded-xl hover:bg-muted transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-destructive/20 border border-destructive/40 flex items-center justify-center">
              <span className="text-xl">⚔️</span>
            </div>
            <div>
              <h2 className="font-bold text-lg text-foreground neon-text">
                {t('Battle Arena', 'बैटल अखाड़ा', 'బ్యాటిల్ అరీనా')}
              </h2>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Bot className="w-3 h-3" />
                {t('AI opponents ready!', 'AI प्रतिद्वंद्वी तैयार!', 'AI ప్రత్యర్థులు సిద్ధం!')}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Info Banner */}
        <div className="system-window neon-border p-4">
          <p className="text-sm text-foreground font-medium text-center">
            🤖 {t(
              'No other players? Our AI monsters will challenge you! Answer quickly for bonus points!',
              'कोई और खिलाड़ी नहीं? हमारे AI राक्षस आपको चुनौती देंगे! बोनस अंकों के लिए जल्दी उत्तर दें!',
              'ఇతర ఆటగాళ్లు లేరా? మా AI రాక్షసులు మిమ్మల్ని సవాలు చేస్తారు! బోనస్ పాయింట్ల కోసం త్వరగా జవాబివ్వండి!'
            )}
          </p>
        </div>

        {/* Battle Modes */}
        {battleModes.map((mode) => (
          <button
            key={mode.id}
            onClick={() => handleModeSelect(mode)}
            className="w-full rounded-lg overflow-hidden system-window hover:border-primary/60 hover:shadow-neon transition-all"
          >
            {/* Colored Header */}
            <div className={`${mode.color} text-white p-4 flex items-center justify-between`}>
              <div className="flex items-center gap-3">
                {getModeIcon(mode.id)}
                <div className="text-left">
                  <h3 className="font-bold">{getModeTitle(mode)}</h3>
                  <p className="text-sm opacity-90">{getModeSubtitle(mode)}</p>
                </div>
              </div>
              <Crown className="w-6 h-6 opacity-70" />
            </div>
            
            {/* Description */}
            <div className="bg-card p-4">
              <p className="text-muted-foreground text-sm mb-3">{getModeDescription(mode)}</p>
              <div className="flex items-center gap-4 text-sm">
                <span className="flex items-center gap-1 text-primary font-bold">
                  <Zap className="w-4 h-4" />
                  +{mode.xpReward} XP
                </span>
                <span className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  {mode.duration}
                </span>
                <span className="flex items-center gap-1 text-muted-foreground">
                  <Bot className="w-4 h-4" />
                  AI
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
