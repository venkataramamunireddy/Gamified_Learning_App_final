import { WelcomeHero } from "../components/WelcomeHero";
import { DailyGoal } from "../components/DailyGoal";
import { SubjectCard } from "../components/SubjectCard";
import { QuickActions } from "../components/QuickActions";
import { useSubjectProgress } from "../hooks/useSubjectProgress";
import { useLang } from "../context/LanguageContext";

interface HomePageProps {
  onSubjectSelect: (subjectId: string) => void;
  onNavigate: (tab: string) => void;
}

export const HomePage = ({ onSubjectSelect, onNavigate }: HomePageProps) => {
  const { t } = useLang();
  const { subjectsWithProgress } = useSubjectProgress();

  return (
    <div className="pb-24">
      <WelcomeHero />
      <DailyGoal />
      <QuickActions onNavigate={onNavigate} />
      
      <div className="px-4 mt-6">
        <h2 className="text-sm font-bold text-primary mb-4 uppercase tracking-widest flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse-glow" />
          {t('Select Dungeon', 'डंजन चुनें', 'డంజన్ ఎంచుకోండి')} 📚
        </h2>
        <div className="space-y-4">
          {subjectsWithProgress.map((subject, index) => (
            <SubjectCard 
              key={subject.id} 
              subject={subject} 
              onClick={() => onSubjectSelect(subject.id)}
              delay={index * 100}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
