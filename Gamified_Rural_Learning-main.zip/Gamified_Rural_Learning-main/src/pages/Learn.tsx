import { useState, useMemo } from "react";
import { ArrowLeft, BookOpen, Lock, CheckCircle2 } from "lucide-react";
import { useLang } from "../context/LanguageContext";
import { subjects, Subject } from "../data/subjects";
import { getQuestionsBySubject } from "../data/questions";
import { getLessonsBySubject, Lesson } from "../data/lessons";
import { QuizGame } from "../components/QuizGame";
import { LessonViewer } from "../components/LessonViewer";
import { SubjectCard } from "../components/SubjectCard";
import { useSubjectProgress } from "../hooks/useSubjectProgress";

interface LearnPageProps {
  initialSubjectId?: string | null;
  onBack: () => void;
}

type LearningStage = 'subject-select' | 'lesson-list' | 'lesson-view' | 'quiz';

export const LearnPage = ({ initialSubjectId, onBack }: LearnPageProps) => {
  const { t, lang } = useLang();
  const { subjectsWithProgress, markLessonComplete, isLessonCompleted } = useSubjectProgress();
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(
    initialSubjectId ? subjects.find(s => s.id === initialSubjectId) || null : null
  );
  const [stage, setStage] = useState<LearningStage>(initialSubjectId ? 'lesson-list' : 'subject-select');
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);

  // Memoize quiz questions so they don't reshuffle on re-render
  const quizQuestions = useMemo(() => {
    if (stage === 'quiz' && selectedSubject) {
      return getQuestionsBySubject(selectedSubject.id);
    }
    return [];
  }, [stage, selectedSubject]);

  const handleSubjectSelect = (subject: Subject) => {
    setSelectedSubject(subject);
    setStage('lesson-list');
  };

  const handleLessonSelect = (lesson: Lesson) => {
    setCurrentLesson(lesson);
    setStage('lesson-view');
  };

  const handleLessonComplete = () => {
    if (currentLesson) {
      markLessonComplete(currentLesson.id);
    }
    setCurrentLesson(null);
    setStage('lesson-list');
  };

  const handleQuizComplete = () => {
    setStage('subject-select');
    setSelectedSubject(null);
    onBack();
  };

  const handleBack = () => {
    if (stage === 'lesson-list') {
      setSelectedSubject(null);
      setStage('subject-select');
    } else if (stage === 'lesson-view') {
      setCurrentLesson(null);
      setStage('lesson-list');
    } else if (stage === 'quiz') {
      setStage('lesson-list');
    }
  };

  // Subject Selection Stage
  if (stage === 'subject-select') {
    return (
      <div className="pb-24">
        <div className="px-4 pt-4">
          <h2 className="text-2xl font-extrabold text-foreground mb-2">
            {t('Choose a Subject', 'विषय चुनें', 'విషయం ఎంచుకోండి')} 📖
          </h2>
          <p className="text-muted-foreground mb-6">
            {t('Select a subject to start learning', 'पढ़ाई शुरू करने के लिए विषय चुनें', 'నేర్చుకోవడం ప్రారంభించడానికి విషయం ఎంచుకోండి')}
          </p>
          
          <div className="space-y-4">
            {subjectsWithProgress.map((subject, index) => (
              <SubjectCard 
                key={subject.id} 
                subject={subject} 
                onClick={() => handleSubjectSelect(subject)}
                delay={index * 100}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Header for other stages
  const renderHeader = () => (
    <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="flex items-center gap-3 px-4 py-3">
        <button
          onClick={handleBack}
          className="p-2 rounded-xl hover:bg-muted transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        {selectedSubject && (
          <div className="flex items-center gap-2">
            <span className="text-2xl">{selectedSubject.icon}</span>
            <h2 className="font-bold text-lg">
              {lang === 'te' ? selectedSubject.nameTe : 
               lang === 'hi' ? selectedSubject.nameHi : selectedSubject.name}
            </h2>
          </div>
        )}
      </div>
    </div>
  );

  // Lesson List Stage
  if (stage === 'lesson-list' && selectedSubject) {
    const lessons = getLessonsBySubject(selectedSubject.id);
    const allLessonsComplete = lessons.length > 0 && lessons.every(l => isLessonCompleted(l.id));
    const hasLessons = lessons.length > 0;

    return (
      <div className="pb-24">
        {renderHeader()}
        
        <div className="p-4">
          {/* Learning Flow Banner */}
          <div className="bg-secondary/10 border-2 border-secondary/30 rounded-2xl p-4 mb-6">
            <p className="text-sm text-secondary font-medium text-center">
              📘 {t(
                'Learn → Practice → Quiz → Reward',
                'सीखें → अभ्यास → क्विज़ → इनाम',
                'నేర్చుకో → అభ్యాసం → క్విజ్ → బహుమతి'
              )}
            </p>
          </div>

          {/* Lessons */}
          {hasLessons && (
            <div className="mb-6">
              <h3 className="font-bold text-lg text-foreground mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-secondary" />
                {t('Lessons', 'पाठ', 'పాఠాలు')}
              </h3>
              <div className="space-y-3">
                {lessons.map((lesson, index) => {
                  const completed = isLessonCompleted(lesson.id);
                  const lessonTitle = lang === 'te' ? lesson.titleTe : 
                                     lang === 'hi' ? lesson.titleHi : lesson.title;

                  return (
                    <button
                      key={lesson.id}
                      onClick={() => handleLessonSelect(lesson)}
                      className={`w-full p-4 rounded-2xl border-2 text-left transition-all ${
                        completed 
                          ? 'bg-secondary/10 border-secondary' 
                          : 'bg-card border-border hover:border-primary hover:bg-primary/5'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          completed ? 'bg-secondary text-white' : 'bg-muted'
                        }`}>
                          {completed ? (
                            <CheckCircle2 className="w-5 h-5" />
                          ) : (
                            <span className="font-bold">{index + 1}</span>
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-bold text-foreground">{lessonTitle}</p>
                          <p className="text-sm text-muted-foreground">
                            {completed 
                              ? t('Completed ✓', 'पूरा हुआ ✓', 'పూర్తయింది ✓')
                              : t('Tap to learn', 'सीखने के लिए टैप करें', 'నేర్చుకోవడానికి నొక్కండి')
                            }
                          </p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quiz Section */}
          <div className="mt-6">
            <h3 className="font-bold text-lg text-foreground mb-4 flex items-center gap-2">
              🎯 {t('Quiz', 'क्विज़', 'క్విజ్')}
            </h3>
            
            {hasLessons && !allLessonsComplete ? (
              <div className="bg-muted rounded-2xl p-6 text-center border-2 border-dashed border-border">
                <Lock className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-bold text-foreground mb-2">
                  {t('Quiz Locked', 'क्विज़ लॉक है', 'క్విజ్ లాక్ చేయబడింది')}
                </p>
                <p className="text-sm text-muted-foreground">
                  {t(
                    'Complete all lessons first to unlock the quiz',
                    'क्विज़ अनलॉक करने के लिए पहले सभी पाठ पूरे करें',
                    'క్విజ్ అన్‌లాక్ చేయడానికి ముందు అన్ని పాఠాలు పూర్తి చేయండి'
                  )}
                </p>
              </div>
            ) : (
              <button
                onClick={() => setStage('quiz')}
                className="w-full gradient-header text-primary-foreground p-4 rounded-2xl font-bold text-lg shadow-button hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                {t('Start Quiz', 'क्विज़ शुरू करें', 'క్విజ్ ప్రారంభించండి')} 🚀
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Lesson View Stage
  if (stage === 'lesson-view' && currentLesson) {
    return (
      <div className="pb-24">
        {renderHeader()}
        <LessonViewer lesson={currentLesson} onComplete={handleLessonComplete} />
      </div>
    );
  }

  // Quiz Stage

  if (stage === 'quiz' && selectedSubject && quizQuestions.length > 0) {
    return (
      <div className="pb-24">
        {renderHeader()}
        <QuizGame 
          questions={quizQuestions}
          onComplete={handleQuizComplete}
          subjectName={selectedSubject.name}
          subjectNameHi={selectedSubject.nameHi}
          subjectNameTe={selectedSubject.nameTe}
        />
      </div>
    );
  }

  return null;
};
