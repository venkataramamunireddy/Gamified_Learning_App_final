import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const AVATARS = ["🗡️", "🛡️", "⚔️", "🏹", "🔮", "🧙", "🐉", "👑", "💎", "🦅"];

interface OnboardingProps {
  userId: string;
  onComplete: () => void;
}

export const OnboardingPage = ({ userId, onComplete }: OnboardingProps) => {
  const [hunterName, setHunterName] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState("⚔️");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    const trimmed = hunterName.trim();
    if (!trimmed) {
      toast({ title: "Enter a Hunter name", variant: "destructive" });
      return;
    }
    if (trimmed.length < 3) {
      toast({ title: "Name must be at least 3 characters", variant: "destructive" });
      return;
    }

    setSaving(true);

    const { error } = await supabase
      .from("profiles")
      .update({ hunter_name: trimmed, avatar_url: selectedAvatar })
      .eq("user_id", userId);

    if (error) {
      const isDuplicate = error.message?.includes("duplicate") || error.code === "23505";
      toast({
        title: isDuplicate ? "Name already taken" : "Error saving profile",
        description: isDuplicate ? "Choose a different Hunter name." : error.message,
        variant: "destructive",
      });
      setSaving(false);
      return;
    }

    onComplete();
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8 text-center">
        <div className="space-y-3">
          <div className="text-7xl animate-bounce-gentle">{selectedAvatar}</div>
          <h1 className="text-3xl font-extrabold neon-text tracking-tight">Create Your Hunter</h1>
          <p className="text-muted-foreground text-sm">Choose a unique name and avatar to begin your quest.</p>
        </div>

        <Card className="system-window border-primary/30">
          <CardContent className="pt-6 pb-6 space-y-6">
            {/* Avatar Selection */}
            <div>
              <p className="text-sm font-semibold text-foreground mb-3">Choose Avatar</p>
              <div className="flex flex-wrap justify-center gap-3">
                {AVATARS.map((avatar) => (
                  <button
                    key={avatar}
                    onClick={() => setSelectedAvatar(avatar)}
                    className={`text-3xl w-12 h-12 rounded-lg flex items-center justify-center transition-all border ${
                      selectedAvatar === avatar
                        ? "border-primary bg-primary/20 scale-110"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    {avatar}
                  </button>
                ))}
              </div>
            </div>

            {/* Hunter Name */}
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">Hunter Name</p>
              <Input
                placeholder="Enter a unique name..."
                value={hunterName}
                onChange={(e) => setHunterName(e.target.value)}
                maxLength={20}
                className="text-center text-lg border-primary/30"
              />
            </div>

            <Button
              className="w-full h-12 text-base font-bold"
              onClick={handleSubmit}
              disabled={saving || !hunterName.trim()}
            >
              {saving ? "Creating..." : "Begin Quest ⚔️"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
