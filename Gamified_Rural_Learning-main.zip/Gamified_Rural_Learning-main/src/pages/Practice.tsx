import { useState, useMemo } from "react";
import { ArrowLeft, TrendingUp, RefreshCw, Trophy, ChevronRight } from "lucide-react";
import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { subjects } from "../data/subjects";
import { getQuestionsBySubject } from "../data/questions";
import { QuizGame } from "../components/QuizGame";

interface PracticePageProps {
  onBack: () => void;
}

type PracticeView = 'menu' | 'practice' | 'leaderboard';

export const PracticePage = ({ onBack }: PracticePageProps) => {
  const { t, lang } = useLang();
  const { student: _student } = useStudent();
  const [view, setView] = useState<PracticeView>('menu');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);

  // Mock practice stats (in real app, would be stored/calculated)
  const practiceStats = {
    questions: 87,
    accuracy: 72,
    streak: 5
  };

  const handleSubjectSelect = (subjectId: string) => {
    setSelectedSubjectId(subjectId);
    setView('practice');
  };

  const handlePracticeComplete = () => {
    setView('menu');
    setSelectedSubjectId(null);
  };

  // Memoize practice questions so they don't reshuffle on re-render
  const practiceQuestions = useMemo(() => {
    if (view === 'practice' && selectedSubjectId) {
      return getQuestionsBySubject(selectedSubjectId);
    }
    return [];
  }, [view, selectedSubjectId]);

  if (view === 'practice' && selectedSubjectId && practiceQuestions.length > 0) {
    const subject = subjects.find(s => s.id === selectedSubjectId);
    
    return (
      <div className="pb-24">
        <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
          <div className="flex items-center gap-3 px-4 py-3">
            <button
              onClick={() => setView('menu')}
              className="p-2 rounded-xl hover:bg-muted transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{subject?.icon}</span>
              <h2 className="font-bold text-lg">
                {t('Practice Mode', 'अभ्यास मोड', 'ప్రాక్టీస్ మోడ్')}
              </h2>
            </div>
          </div>
        </div>
        <QuizGame 
          questions={practiceQuestions}
          onComplete={handlePracticeComplete}
          subjectName={subject?.name || ''}
          subjectNameHi={subject?.nameHi || ''}
          subjectNameTe={subject?.nameTe || ''}
          isPracticeMode={true}
        />
      </div>
    );
  }

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
              <span className="text-xl">🎯</span>
            </div>
            <div>
              <h2 className="font-bold text-lg text-foreground">
                {t('Practice Zone', 'अभ्यास क्षेत्र', 'ప్రాక్టీస్ జోన్')}
              </h2>
              <p className="text-sm text-muted-foreground">
                {t('No XP, no pressure - just learn!', 'कोई XP नहीं, कोई दबाव नहीं - बस सीखो!', 'XP లేదు, ఒత్తిడి లేదు - కేవలం నేర్చుకోండి!')}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Info Banner */}
        <div className="bg-secondary/10 border-2 border-secondary/30 rounded-2xl p-4">
          <p className="text-sm text-secondary font-medium text-center">
            ✨ {t(
              'Practice is separate from your main progress. Make mistakes freely and learn from them!',
              'अभ्यास आपकी मुख्य प्रगति से अलग है। स्वतंत्र रूप से गलतियाँ करें और उनसे सीखें!',
              'ప్రాక్టీస్ మీ ప్రధాన పురోగతి నుండి వేరు. స్వేచ్ఛగా తప్పులు చేసి వాటి నుండి నేర్చుకోండి!'
            )}
          </p>
        </div>

        {/* Practice Stats */}
        <div className="bg-card rounded-2xl border border-border p-4">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-secondary" />
            <h3 className="font-bold text-foreground">
              {t('Your Practice Stats', 'आपके अभ्यास आंकड़े', 'మీ ప్రాక్టీస్ స్టాట్స్')}
            </h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-muted rounded-xl p-4 text-center">
              <p className="text-2xl font-extrabold text-foreground">{practiceStats.questions}</p>
              <p className="text-xs text-muted-foreground">{t('Questions', 'प्रश्न', 'ప్రశ్నలు')}</p>
            </div>
            <div className="bg-muted rounded-xl p-4 text-center">
              <p className="text-2xl font-extrabold text-secondary">{practiceStats.accuracy}%</p>
              <p className="text-xs text-muted-foreground">{t('Accuracy', 'सटीकता', 'ఖచ్చితత్వం')}</p>
            </div>
            <div className="bg-muted rounded-xl p-4 text-center">
              <p className="text-2xl font-extrabold text-accent">{practiceStats.streak}</p>
              <p className="text-xs text-muted-foreground">{t('Streak', 'लकीर', 'స్ట్రీక్')}</p>
            </div>
          </div>
        </div>

        {/* Toggle Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setView('menu')}
            className={`flex items-center justify-center gap-2 p-4 rounded-2xl font-bold transition-all ${
              view === 'menu' 
                ? 'bg-secondary text-secondary-foreground' 
                : 'bg-card border-2 border-secondary text-secondary'
            }`}
          >
            <RefreshCw className="w-5 h-5" />
            {t('Practice', 'अभ्यास', 'ప్రాక్టీస్')}
          </button>
          <button
            onClick={() => setView('leaderboard')}
            className={`flex items-center justify-center gap-2 p-4 rounded-2xl font-bold transition-all ${
              view === 'leaderboard' 
                ? 'bg-secondary text-secondary-foreground' 
                : 'bg-card border-2 border-secondary text-secondary'
            }`}
          >
            <Trophy className="w-5 h-5" />
            {t('Leaderboard', 'लीडरबोर्ड', 'లీడర్‌బోర్డ్')}
          </button>
        </div>

        {/* Subject Selection or Leaderboard */}
        {view === 'menu' && (
          <div>
            <h3 className="font-bold text-foreground mb-4">
              {t('Choose Subject to Practice', 'अभ्यास के लिए विषय चुनें', 'ప్రాక్టీస్ కోసం సబ్జెక్ట్ ఎంచుకోండి')}
            </h3>
            <div className="space-y-3">
              {subjects.map(subject => (
                <button
                  key={subject.id}
                  onClick={() => handleSubjectSelect(subject.id)}
                  className="w-full flex items-center gap-4 p-4 bg-card rounded-2xl border border-border hover:border-primary transition-all"
                >
                  <span className="text-3xl">{subject.icon}</span>
                  <div className="flex-1 text-left">
                    <h4 className="font-bold text-foreground">
                      {lang === 'te' ? subject.nameTe : lang === 'hi' ? subject.nameHi : subject.name}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {t('Unlimited practice questions', 'असीमित अभ्यास प्रश्न', 'అపరిమిత ప్రాక్టీస్ ప్రశ్నలు')}
                    </p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </button>
              ))}
            </div>
          </div>
        )}

        {view === 'leaderboard' && (
          <div className="bg-card rounded-2xl border border-border p-6 text-center">
            <Trophy className="w-12 h-12 text-primary mx-auto mb-3" />
            <h3 className="font-bold text-foreground mb-2">
              {t('Leaderboard Coming Soon!', 'लीडरबोर्ड जल्द आ रहा है!', 'లీడర్‌బోర్డ్ త్వరలో వస్తుంది!')}
            </h3>
            <p className="text-sm text-muted-foreground">
              {t('Compete with other ants in your school!', 'अपने स्कूल की दूसरी चींटियों से प्रतिस्पर्धा करें!', 'మీ స్కూల్‌లోని ఇతర చీమలతో పోటీ పడండి!')}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
