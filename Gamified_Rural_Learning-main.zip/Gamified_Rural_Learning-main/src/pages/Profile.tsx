import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { useAuth } from "../hooks/useAuth";
import { Flame, BookOpen, Swords, Brain, Heart, Zap, Eye, Trophy, LogOut } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export const ProfilePage = () => {
  const { t, lang } = useLang();
  const { student } = useStudent();
  const { signOut } = useAuth();

  const getHunterName = () => {
    if (lang === 'te') return student.hunterNameTe;
    if (lang === 'hi') return student.hunterNameHi;
    return student.hunterName;
  };

  const getRankColor = (rank: string) => {
    switch (rank) {
      case 'S': return 'text-yellow-400 border-yellow-500/40 bg-yellow-500/10';
      case 'A': return 'text-red-400 border-red-500/40 bg-red-500/10';
      case 'B': return 'text-orange-400 border-orange-500/40 bg-orange-500/10';
      case 'C': return 'text-yellow-300 border-yellow-400/40 bg-yellow-400/10';
      case 'D': return 'text-blue-300 border-blue-400/40 bg-blue-400/10';
      default: return 'text-green-400 border-green-500/40 bg-green-500/10';
    }
  };

  const stats = [
    { icon: Flame, label: t('Streak', 'स्ट्रीक', 'స్ట్రీక్'), value: student.streak, color: 'text-primary' },
    { icon: BookOpen, label: t('Lessons', 'पाठ', 'పాఠాలు'), value: student.lessonsCompleted, color: 'text-secondary' },
    { icon: Trophy, label: t('Quizzes', 'क्विज़', 'క్విజ్‌లు'), value: student.quizzesCompleted, color: 'text-accent' },
    { icon: Swords, label: t('Battles', 'लड़ाइयां', 'యుద్ధాలు'), value: student.battlesWon, color: 'text-destructive' },
  ];

  const hunterStats = [
    { icon: Swords, label: 'STR', value: student.stats.strength, color: 'text-red-400' },
    { icon: Brain, label: 'INT', value: student.stats.intelligence, color: 'text-blue-400' },
    { icon: Heart, label: 'VIT', value: student.stats.vitality, color: 'text-green-400' },
    { icon: Zap, label: 'AGI', value: student.stats.agility, color: 'text-yellow-400' },
    { icon: Eye, label: 'SEN', value: student.stats.sense, color: 'text-purple-400' },
  ];

  const xpPercentage = (student.xp / student.xpToNextLevel) * 100;

  return (
    <div className="pb-24 px-4 pt-4">
      {/* Hunter Card */}
      <div className="system-window neon-border p-6 text-center animate-scale-in relative">
        {/* Rank Badge */}
        <div className={`absolute top-4 right-4 px-3 py-1.5 rounded border font-extrabold text-xl ${getRankColor(student.rank)}`}>
          {student.rank}-{t('Rank', 'रैंक', 'ర్యాంక్')}
        </div>
        
        <div className="text-7xl mb-4 animate-bounce-gentle">{student.avatar}</div>
        <h2 className="text-2xl font-extrabold mb-1 text-foreground neon-text">{getHunterName()}</h2>
        <p className="text-muted-foreground font-medium">
          {t('Level', 'लेवल', 'లెవల్')} {student.level} {t('Hunter', 'हंटर', 'హంటర్')}
        </p>
        
        {/* XP Bar */}
        <div className="mt-4 bg-muted rounded h-4 overflow-hidden border border-border">
          <div 
            className="bg-gradient-to-r from-primary to-accent h-4 transition-all duration-500 flex items-center justify-end pr-2"
            style={{ width: `${xpPercentage}%` }}
          >
            {xpPercentage > 20 && (
              <span className="text-xs font-bold text-background">{Math.round(xpPercentage)}%</span>
            )}
          </div>
        </div>
        <p className="text-sm mt-2 text-muted-foreground">
          {student.xp} / {student.xpToNextLevel} XP {t('to Level', 'लेवल', 'లెవల్')} {student.level + 1}
        </p>
      </div>

      {/* Hunter Stats */}
      <div className="mt-6 system-window neon-border p-5">
        <h3 className="font-bold text-foreground mb-4 flex items-center gap-2 text-lg">
          ⚔️ {t('Hunter Stats', 'हंटर स्टैट्स', 'హంటర్ స్టాట్స్')}
        </h3>
        <div className="space-y-4">
          {hunterStats.map((stat) => {
            const Icon = stat.icon;
            const percentage = Math.min((stat.value / 100) * 100, 100);
            return (
              <div key={stat.label} className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded flex items-center justify-center bg-muted border border-border ${stat.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-sm text-foreground">{stat.label}</span>
                    <span className={`font-extrabold ${stat.color}`}>{stat.value}</span>
                  </div>
                  <Progress value={percentage} className="h-2" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Activity Stats */}
      <div className="grid grid-cols-2 gap-4 mt-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="system-window neon-border p-5 animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
              <Icon className={`w-6 h-6 ${stat.color} mb-2`} />
              <p className="text-2xl font-extrabold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground font-medium">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Motivational Quote */}
      <div className="mt-6 system-window neon-border p-5 text-center">
        <p className="text-foreground font-semibold italic neon-text">
          "{t('I alone level up', 'मैं अकेला लेवल अप करता हूं', 'నేను ఒంటరిగా లెవల్ అప్ అవుతాను')}" ⚔️
        </p>
      </div>

      {/* Sign Out */}
      <button
        onClick={signOut}
        className="mt-6 w-full flex items-center justify-center gap-2 p-4 rounded-lg border border-destructive/30 text-destructive hover:bg-destructive/10 transition-colors font-bold"
      >
        <LogOut className="w-5 h-5" />
        {t('Sign Out', 'साइन आउट', 'సైన్ అవుట్')}
      </button>
    </div>
  );
};
