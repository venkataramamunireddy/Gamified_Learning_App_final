import { ArrowLeft, Calendar, CalendarDays } from "lucide-react";
import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { quests, Quest } from "../data/quests";
import { Progress } from "@/components/ui/progress";

interface QuestsPageProps {
  onBack: () => void;
}

export const QuestsPage = ({ onBack }: QuestsPageProps) => {
  const { t, lang } = useLang();
  const { student } = useStudent();

  // Calculate progress for each quest based on student data
  const getQuestProgress = (quest: Quest): number => {
    switch (quest.category) {
      case 'lessons':
        return Math.min(student.lessonsCompleted, quest.target);
      case 'streak':
        return Math.min(student.streak, quest.target);
      case 'quizzes':
        return 0; // Would need to track quiz completions
      case 'battles':
        return 0; // Would need to track battle wins
      case 'practice':
        return 0; // Would need to track practice questions
      default:
        return 0;
    }
  };

  const dailyQuests = quests.filter(q => q.type === 'daily');
  const weeklyQuests = quests.filter(q => q.type === 'weekly');

  const getQuestTitle = (quest: Quest) => {
    if (lang === 'te') return quest.titleTe;
    if (lang === 'hi') return quest.titleHi;
    return quest.title;
  };

  const getQuestDescription = (quest: Quest) => {
    if (lang === 'te') return quest.descriptionTe;
    if (lang === 'hi') return quest.descriptionHi;
    return quest.description;
  };

  const QuestCard = ({ quest }: { quest: Quest }) => {
    const progress = getQuestProgress(quest);
    const progressPercent = Math.round((progress / quest.target) * 100);
    const isComplete = progress >= quest.target;

    return (
      <div className={`bg-card rounded-2xl border-2 ${isComplete ? 'border-secondary' : 'border-border'} p-4 transition-all`}>
        <div className="flex items-start gap-3">
          <span className="text-3xl">{quest.icon}</span>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-foreground">{getQuestTitle(quest)}</h3>
              <span className="text-sm font-bold text-primary">+{quest.xpReward} XP</span>
            </div>
            <p className="text-sm text-secondary mt-1">{getQuestDescription(quest)}</p>
            <div className="flex items-center justify-between mt-3">
              <span className="text-sm text-muted-foreground">{progress}/{quest.target}</span>
              <span className="text-sm text-muted-foreground">{progressPercent}%</span>
            </div>
            <Progress 
              value={progressPercent} 
              className="h-2 mt-2 bg-muted" 
            />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
              <span className="text-xl">🎯</span>
            </div>
            <div>
              <h2 className="font-bold text-lg text-foreground">
                {t('Quest Board', 'क्वेस्ट बोर्ड', 'క్వెస్ట్ బోర్డ్')}
              </h2>
              <p className="text-sm text-muted-foreground">
                {t('Complete quests to earn XP', 'XP कमाने के लिए क्वेस्ट पूरे करें', 'XP సంపాదించడానికి క్వెస్ట్‌లు పూర్తి చేయండి')}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Daily Quests */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-foreground" />
            <h3 className="font-bold text-lg text-foreground">
              {t('Daily Quests', 'दैनिक क्वेस्ट', 'రోజువారీ క్వెస్ట్స్')}
            </h3>
            <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs font-bold rounded-full">
              {t('Resets at midnight', 'आधी रात को रीसेट', 'అర్ధరాత్రి రీసెట్')}
            </span>
          </div>
          <div className="space-y-3">
            {dailyQuests.map(quest => (
              <QuestCard key={quest.id} quest={quest} />
            ))}
          </div>
        </div>

        {/* Weekly Quests */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <CalendarDays className="w-5 h-5 text-foreground" />
            <h3 className="font-bold text-lg text-foreground">
              {t('Weekly Quests', 'साप्ताहिक क्वेस्ट', 'వారపు క్వెస్ట్స్')}
            </h3>
            <span className="px-3 py-1 bg-accent text-accent-foreground text-xs font-bold rounded-full">
              {t('Resets Monday', 'सोमवार को रीसेट', 'సోమవారం రీసెట్')}
            </span>
          </div>
          <div className="space-y-3">
            {weeklyQuests.map(quest => (
              <QuestCard key={quest.id} quest={quest} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
