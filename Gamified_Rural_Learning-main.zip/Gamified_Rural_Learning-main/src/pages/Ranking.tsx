import { useState, useEffect } from "react";
import { useLang } from "../context/LanguageContext";
import { useStudent } from "../context/StudentContext";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Trophy, Crown, Medal, Flame } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface LeaderboardEntry {
  id: string;
  hunter_name: string;
  avatar_url: string | null;
  level: number | null;
  xp: number | null;
  rank: string | null;
}

const getRankStyle = (rank: string | null) => {
  switch (rank) {
    case 'S': return { bg: 'bg-amber-500/20 border-amber-500/50', text: 'text-amber-400', glow: 'shadow-[0_0_15px_rgba(245,158,11,0.3)]' };
    case 'A': return { bg: 'bg-red-500/20 border-red-500/50', text: 'text-red-400', glow: '' };
    case 'B': return { bg: 'bg-orange-500/20 border-orange-500/50', text: 'text-orange-400', glow: '' };
    case 'C': return { bg: 'bg-yellow-500/20 border-yellow-500/50', text: 'text-yellow-400', glow: '' };
    case 'D': return { bg: 'bg-blue-500/20 border-blue-500/50', text: 'text-blue-400', glow: '' };
    default: return { bg: 'bg-green-500/20 border-green-500/50', text: 'text-green-400', glow: '' };
  }
};

const getPositionIcon = (pos: number) => {
  if (pos === 1) return <Crown className="w-5 h-5 text-amber-400" />;
  if (pos === 2) return <Medal className="w-5 h-5 text-gray-300" />;
  if (pos === 3) return <Medal className="w-5 h-5 text-amber-600" />;
  return <span className="text-sm font-bold text-muted-foreground w-5 text-center">{pos}</span>;
};

interface RankingPageProps {
  onBack: () => void;
}

export const RankingPage = ({ onBack }: RankingPageProps) => {
  const { t } = useLang();
  const { student } = useStudent();
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      const { data, error } = await supabase.rpc("get_leaderboard");

      if (!error && data) {
        setEntries(data as LeaderboardEntry[]);
      }
      setLoading(false);
    };
    fetchLeaderboard();
  }, []);

  const myRank = entries.findIndex(e => e.hunter_name === student.hunterName) + 1;

  return (
    <div className="pb-24 pt-2">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border px-4 py-3">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg border border-border hover:border-primary/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-extrabold neon-text">
              {t('Hunter Rankings', 'हंटर रैंकिंग', 'హంటర్ ర్యాంకింగ్')}
            </h1>
          </div>
        </div>
      </div>

      {/* My Position Card */}
      {myRank > 0 && (
        <div className="px-4 mt-4">
          <div className="system-window border-primary/40 p-4 flex items-center gap-4">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/20 border border-primary/40">
              <Flame className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">
                {t('Your Rank', 'आपकी रैंक', 'మీ ర్యాంక్')}
              </p>
              <p className="text-2xl font-black text-primary">#{myRank}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold">{student.hunterName}</p>
              <p className="text-xs text-muted-foreground">Lv. {student.level}</p>
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard */}
      <div className="px-4 mt-5 space-y-2">
        <h2 className="text-sm font-bold text-primary mb-3 uppercase tracking-widest flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
          {t('Top Hunters', 'टॉप हंटर्स', 'టాప్ హంటర్స్')}
        </h2>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="h-16 rounded-xl bg-muted/50 animate-pulse" />
            ))}
          </div>
        ) : entries.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Trophy className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>{t('No hunters yet', 'अभी कोई हंटर नहीं', 'ఇంకా హంటర్లు లేరు')}</p>
          </div>
        ) : (
          entries.map((entry, idx) => {
            const pos = idx + 1;
            const rankStyle = getRankStyle(entry.rank);
            const isMe = entry.hunter_name === student.hunterName;
            const isTop3 = pos <= 3;

            return (
              <div
                key={entry.id}
                className={`flex items-center gap-3 p-3 rounded-xl border transition-all animate-slide-up ${
                  isMe
                    ? 'border-primary/50 bg-primary/10 shadow-neon'
                    : isTop3
                    ? `${rankStyle.glow} border-border/50 bg-card`
                    : 'border-border/30 bg-card/50'
                }`}
                style={{ animationDelay: `${idx * 30}ms` }}
              >
                {/* Position */}
                <div className="w-8 flex items-center justify-center">
                  {getPositionIcon(pos)}
                </div>

                {/* Avatar */}
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl border ${rankStyle.bg}`}>
                  {entry.avatar_url || '⚔️'}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className={`font-bold text-sm truncate ${isMe ? 'text-primary' : 'text-foreground'}`}>
                      {entry.hunter_name}
                      {isMe && <span className="text-xs ml-1 opacity-60">({t('You', 'आप', 'మీరు')})</span>}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-muted-foreground">Lv. {entry.level || 1}</span>
                    <Progress value={((entry.xp || 0) % 100)} className="h-1 flex-1 max-w-[80px]" />
                  </div>
                </div>

                {/* Rank Badge */}
                <div className={`px-2 py-1 rounded-md text-xs font-black border ${rankStyle.bg} ${rankStyle.text}`}>
                  {entry.rank || 'E'}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
