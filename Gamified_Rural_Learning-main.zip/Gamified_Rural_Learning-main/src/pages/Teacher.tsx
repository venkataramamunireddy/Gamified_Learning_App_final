import { TeacherDashboard } from "../components/TeacherDashboard";

export const TeacherPage = () => {
  return <TeacherDashboard />;
};
