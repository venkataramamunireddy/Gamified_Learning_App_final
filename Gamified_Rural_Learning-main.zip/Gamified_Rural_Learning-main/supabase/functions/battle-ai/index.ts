import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // --- Authentication ---
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ taunt: "⚔️ Unauthorized Hunter!" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ taunt: "⚔️ Unauthorized Hunter!" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- Input Validation ---
    const body = await req.json();
    const { subject, difficulty, questionNumber, totalQuestions, playerScore, opponentScore } = body;

    if (subject !== undefined && (typeof subject !== "string" || subject.length > 100)) {
      return new Response(JSON.stringify({ taunt: "🔥 Invalid challenge!" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (difficulty !== undefined && (typeof difficulty !== "string" || difficulty.length > 50)) {
      return new Response(JSON.stringify({ taunt: "🔥 Invalid challenge!" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (questionNumber !== undefined && (typeof questionNumber !== "number" || questionNumber < 0 || questionNumber > 100)) {
      return new Response(JSON.stringify({ taunt: "🔥 Invalid challenge!" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (totalQuestions !== undefined && (typeof totalQuestions !== "number" || totalQuestions < 0 || totalQuestions > 100)) {
      return new Response(JSON.stringify({ taunt: "🔥 Invalid challenge!" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("Service configuration error");
      return new Response(JSON.stringify({ taunt: "🔥 Prepare yourself, Hunter!" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const systemPrompt = `You are an AI battle opponent in a Solo Leveling themed learning game. You roleplay as a dungeon monster/boss.
Your job is to generate a short battle taunt or reaction (1-2 sentences max) based on the battle situation.
Keep it fun, dramatic, and Solo Leveling themed. Use emojis occasionally.
Respond in the same language context provided. Keep responses SHORT.`;

    const userPrompt = `Battle situation:
- Subject: ${subject || 'General'}
- Difficulty: ${difficulty || 'Normal'}
- Question ${questionNumber || 1}/${totalQuestions || 5}
- Player score: ${playerScore || 0}, Opponent score: ${opponentScore || 0}
- Generate a SHORT dramatic taunt (1-2 sentences). Be a dungeon monster!`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-lite",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      console.error("External service error");
      return new Response(JSON.stringify({ taunt: "🔥 Prepare yourself, Hunter!" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const taunt = data.choices?.[0]?.message?.content || "⚔️ Come, Hunter!";

    return new Response(JSON.stringify({ taunt }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Battle AI error:", error);
    return new Response(JSON.stringify({ taunt: "👹 The monster awaits..." }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
