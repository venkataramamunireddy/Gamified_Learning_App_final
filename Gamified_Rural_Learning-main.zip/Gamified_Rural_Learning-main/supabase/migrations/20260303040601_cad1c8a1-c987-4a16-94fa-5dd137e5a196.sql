-- Ensure hunter names are unique across all accounts (case-insensitive)
CREATE UNIQUE INDEX IF NOT EXISTS profiles_hunter_name_unique_idx
ON public.profiles (lower(hunter_name))
WHERE hunter_name IS NOT NULL;