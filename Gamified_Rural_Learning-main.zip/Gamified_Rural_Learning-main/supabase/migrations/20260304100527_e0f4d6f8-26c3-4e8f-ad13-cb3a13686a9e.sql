-- Allow all authenticated users to see public leaderboard data (hunter_name, avatar_url, level, xp, rank)
-- We use a VIEW to expose only non-sensitive fields

CREATE VIEW public.leaderboard
WITH (security_invoker = on) AS
SELECT 
  id,
  hunter_name,
  avatar_url,
  level,
  xp,
  rank
FROM public.profiles
WHERE hunter_name IS NOT NULL;

-- Allow all authenticated users to read the leaderboard
CREATE POLICY "Anyone can view leaderboard profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (hunter_name IS NOT NULL);
