
-- Drop and recreate leaderboard view WITHOUT security_invoker so it bypasses profiles RLS
DROP VIEW IF EXISTS public.leaderboard;

CREATE VIEW public.leaderboard AS
  SELECT id, hunter_name, avatar_url, level, xp, rank
  FROM profiles
  WHERE hunter_name IS NOT NULL;

-- Grant access to authenticated and anon
GRANT SELECT ON public.leaderboard TO authenticated;
GRANT SELECT ON public.leaderboard TO anon;
