
-- Fix 1: Replace the SECURITY DEFINER leaderboard view with SECURITY INVOKER
DROP VIEW IF EXISTS public.leaderboard;

CREATE VIEW public.leaderboard
WITH (security_invoker = true)
AS
  SELECT id, hunter_name, avatar_url, level, xp, rank
  FROM profiles
  WHERE hunter_name IS NOT NULL;

GRANT SELECT ON public.leaderboard TO authenticated, anon;

-- Fix 2: Add a public read policy on profiles so the leaderboard view works with security_invoker
-- Non-sensitive fields only (hunter_name, avatar_url, level, xp, rank) - RLS can't filter columns
-- but the view already restricts which columns are exposed
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;

-- Allow all authenticated users to read profiles (needed for leaderboard/ranking)
CREATE POLICY "Authenticated users can view all profiles"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);

-- Users can still only update their own profile (existing policy unchanged)
