
-- Fix 1: Recreate leaderboard as SECURITY DEFINER (intentional for public game data)
-- but revoke all write access so it's read-only
DROP VIEW IF EXISTS public.leaderboard;

CREATE VIEW public.leaderboard AS
  SELECT id, hunter_name, avatar_url, level, xp, rank
  FROM profiles
  WHERE hunter_name IS NOT NULL;

-- Only allow SELECT, revoke any write operations
GRANT SELECT ON public.leaderboard TO authenticated, anon;
REVOKE INSERT, UPDATE, DELETE ON public.leaderboard FROM authenticated, anon;

-- Fix 2: Revert profiles to owner-only SELECT (leaderboard view handles public reads)
DROP POLICY IF EXISTS "Authenticated users can view all profiles" ON public.profiles;

CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Fix 3: Prevent privilege escalation on user_roles
-- Add explicit INSERT policy restricting to admins only
CREATE POLICY "Only admins can insert roles"
  ON public.user_roles FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- Add explicit UPDATE policy restricting to admins only
CREATE POLICY "Only admins can update roles"
  ON public.user_roles FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- Add explicit DELETE policy restricting to admins only  
CREATE POLICY "Only admins can delete roles"
  ON public.user_roles FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));
