
-- Drop the problematic view
DROP VIEW IF EXISTS public.leaderboard;

-- Create a secure RPC function instead
CREATE OR REPLACE FUNCTION public.get_leaderboard()
RETURNS TABLE (
  id uuid,
  hunter_name text,
  avatar_url text,
  level integer,
  xp integer,
  rank text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.hunter_name, p.avatar_url, p.level, p.xp, p.rank
  FROM public.profiles p
  WHERE p.hunter_name IS NOT NULL
  ORDER BY p.level DESC NULLS LAST, p.xp DESC NULLS LAST
  LIMIT 50;
$$;

-- Grant execute to authenticated users only
GRANT EXECUTE ON FUNCTION public.get_leaderboard() TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_leaderboard() FROM anon;
